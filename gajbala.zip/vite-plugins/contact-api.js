import fs from 'node:fs'
import path from 'node:path'

const DATA_DIR = path.resolve(process.cwd(), 'data')
const DATA_FILE = path.join(DATA_DIR, 'contact-submissions.json')

function readSubmissions() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'))
  } catch {
    return []
  }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = ''
    req.on('data', (chunk) => { body += chunk })
    req.on('end', () => resolve(body))
    req.on('error', reject)
  })
}

/**
 * Dev-only Vite middleware that saves Contact page form submissions to a
 * local JSON file (data/contact-submissions.json) instead of only logging
 * them — lets the form be tested end-to-end without a real backend/email
 * service. Only runs while `npm run dev` is active; the production build
 * has no server, so this route doesn't exist there.
 */
export default function contactApiPlugin() {
  return {
    name: 'contact-api',
    configureServer(server) {
      server.middlewares.use('/api/contact', async (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405
          res.end('Method Not Allowed')
          return
        }
        try {
          const raw = await readBody(req)
          const data = raw ? JSON.parse(raw) : {}

          if (!data.name || !data.email || !data.message) {
            res.statusCode = 400
            res.setHeader('Content-Type', 'application/json')
            res.end(JSON.stringify({ ok: false, error: 'Missing required fields' }))
            return
          }

          fs.mkdirSync(DATA_DIR, { recursive: true })
          const submissions = readSubmissions()
          submissions.push({
            ...data,
            submittedAt: new Date().toISOString(),
          })
          fs.writeFileSync(DATA_FILE, JSON.stringify(submissions, null, 2))

          res.statusCode = 200
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify({ ok: true }))
        } catch (err) {
          res.statusCode = 500
          res.setHeader('Content-Type', 'application/json')
          res.end(JSON.stringify({ ok: false, error: err.message }))
        }
      })
    },
  }
}
