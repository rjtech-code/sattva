// Shared data for the Applications list page and the Application Detail page.
export const applications = [
  {
    slug: 'luxury-villas',
    number: '01',
    title: 'Luxury Villas',
    desc: 'Elevate private residences with lightweight natural stone veneer facades that bring timeless texture and architectural drama to every elevation.',
    longDesc:
      'Our flexible stone veneer lets villa facades carry the weight and depth of natural stone without the structural load of solid slabs — ideal for feature elevations, boundary walls, and entrance porticos.',
    image: '/Images/applications/villa-facade.jpg',
    highlights: [
      'Lightweight veneer — no extra structural load on the facade',
      'Weather-ready finish for long-term outdoor exposure',
      'Large-format panels reduce visible joints across elevations',
    ],
    recommended: ['slatera', 'bookmatch', 'jumboera'],
  },
  {
    slug: 'luxury-living-rooms',
    number: '02',
    title: 'Luxury Living Rooms',
    desc: 'Backlit onyx and natural stone feature walls that turn everyday living spaces into striking design statements.',
    longDesc:
      'A single feature wall in a richly veined, backlit stone finish becomes the anchor of the entire living room — the first thing guests notice and the last thing they forget.',
    image: '/Images/applications/luxury-living-onyx.jpg',
    highlights: [
      'Translucent finishes designed for LED backlighting',
      'Bookmatched veining for a symmetrical, gallery-like effect',
      'Ultra-thin panels fit flush over TV units and joinery',
    ],
    recommended: ['slate-translucent', 'bookmatch', 'sand-translucent'],
  },
  {
    slug: 'master-bedrooms',
    number: '03',
    title: 'Master Bedrooms',
    desc: 'Warm, veined stone headboards and accent walls that bring five-star hospitality comfort into private residences.',
    longDesc:
      'Behind-the-bed stone panelling with soft backlighting brings a hotel-suite calm to master bedrooms, pairing warm sandstone or onyx tones with upholstered headboards.',
    image: '/Images/applications/bedroom-onyx.jpg',
    highlights: [
      'Warm, calming tones suited to rest spaces',
      'Backlit variants soften ambient bedroom lighting',
      'Custom panel sizing to match headboard widths',
    ],
    recommended: ['sandera', 'slate-translucent', 'flexartoera'],
  },
  {
    slug: 'restaurants-bars',
    number: '04',
    title: 'Restaurants & Bars',
    desc: 'Backlit stone bar counters and feature walls that set the mood for unforgettable dining and hospitality experiences.',
    longDesc:
      'Bar fronts and back-bar walls finished in backlit natural stone create the moody, photograph-ready atmosphere that keeps guests ordering another round.',
    image: '/Images/applications/bar-counter.jpg',
    highlights: [
      'Backlit panels for signature bar-front lighting',
      'Durable, easy-clean surface for high-traffic hospitality use',
      'Rich veining photographs beautifully for social media',
    ],
    recommended: ['slate-translucent', 'sand-translucent', 'rockoera-decor'],
  },
  {
    slug: 'resorts-rooftop-lounges',
    number: '05',
    title: 'Resorts & Rooftop Lounges',
    desc: 'Durable, weather-ready stone cladding for poolsides, rooftops, and outdoor pavilions that welcome guests in style.',
    longDesc:
      'Rooftop lounges and poolside pavilions need finishes that hold up to sun, rain, and heavy foot traffic without losing their premium look — our veneer is built for exactly that.',
    image: '/Images/applications/rooftop-lounge.jpg',
    highlights: [
      'UV and weather-resistant outdoor-grade finish',
      'Slip-safe textured options for poolside flooring',
      'Consistent tone across large outdoor cladding runs',
    ],
    recommended: ['slatera', 'jumboera', 'rockoera-louver'],
  },
  {
    slug: 'hospitality-lounges',
    number: '06',
    title: 'Hospitality Lounges',
    desc: 'Elegant marble bar counters and lounge surfaces designed for premium hotel and hospitality interiors.',
    longDesc:
      'From hotel lobby lounges to members\' clubs, a marble-finish bar counter and matching feature wall set the tone for the entire guest experience.',
    image: '/Images/applications/lounge-marble-bar.jpg',
    highlights: [
      'Premium marble-look finish at a fraction of the weight',
      'Matched panels for counters, walls, and columns',
      'Consistent large-format supply for big hospitality projects',
    ],
    recommended: ['bookmatch', 'jumboera', 'slatera'],
  },
  {
    slug: 'retail-fb-spaces',
    number: '07',
    title: 'Retail & F&B Spaces',
    desc: 'Photograph-ready marble counters and surfaces that elevate retail storefronts, bakeries, and cafes.',
    longDesc:
      'Storefronts, bakery counters, and cafe fronts finished in natural stone veneer signal quality the moment a customer walks in — and hold up to daily retail wear.',
    image: '/Images/applications/retail-counter.jpg',
    highlights: [
      'Premium first impression for storefronts and counters',
      'Easy to install over existing counter structures',
      'Durable finish for high-footfall retail environments',
    ],
    recommended: ['sandera', 'bookmatch', 'flexartoera'],
  },
  {
    slug: 'staircases-lobbies',
    number: '08',
    title: 'Staircases & Lobbies',
    desc: 'Seamless natural stone flooring and cladding that make grand entrances and staircases truly grand.',
    longDesc:
      'Lobby floors and staircases are the first and last thing every visitor touches — our large-format panels keep veining continuous across steps, walls, and landings.',
    image: '/Images/applications/staircase-hallway.jpg',
    highlights: [
      'Continuous veining across large lobby footprints',
      'Large-format jumbo sheets minimise visible joints',
      'Consistent finish from flooring to wall cladding',
    ],
    recommended: ['jumboera', 'slatera', 'bookmatch'],
  },
  {
    slug: 'corporate-offices',
    number: '09',
    title: 'Corporate Offices',
    desc: 'Executive-grade stone wall finishes that communicate stability, permanence, and premium brand identity.',
    longDesc:
      'Reception walls, boardrooms, and executive cabins finished in natural stone veneer project the stability and permanence that corporate brands want to be associated with.',
    image: '/Images/applications/office-wall.jpg',
    highlights: [
      'Executive-grade finish for reception and boardroom walls',
      'Consistent supply for multi-floor corporate rollouts',
      'Low-maintenance surface for busy office environments',
    ],
    recommended: ['slatera', 'rockoera-louver', 'bookmatch'],
  },
  {
    slug: 'living-dining-spaces',
    number: '10',
    title: 'Living & Dining Spaces',
    desc: 'Statement marble TV and feature walls that anchor open-plan living and dining interiors.',
    longDesc:
      'Open-plan living and dining areas need one strong anchor point — a marble-finish TV or feature wall ties the whole space together without a full renovation.',
    image: '/Images/applications/dining-lounge.jpg',
    highlights: [
      'Statement feature walls for open-plan interiors',
      'Pairs well with wood and cane furnishing tones',
      'Lightweight panels install directly over drywall',
    ],
    recommended: ['bookmatch', 'sandera', 'slatera'],
  },
]
