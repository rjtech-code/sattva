// Real-life photos (installations/projects) should show full context, not a
// tight material zoom — every other collection is a swatch/texture shot.
export const NO_ZOOM_KEYS = new Set(['application-images', 'real-projects'])
