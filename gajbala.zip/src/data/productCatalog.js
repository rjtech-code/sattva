// Auto-generated from the GajBala Group Drive catalog.
// Each key is a collection; each item is { code, src }.
export const productCatalog = {
  "flexoera": [
    {
      "code": "ERA-SL-101",
      "src": "/Images/catalog/flexoera/ERA-SL-101.jpg"
    },
    {
      "code": "ERA-SL-102",
      "src": "/Images/catalog/flexoera/ERA-SL-102.jpg"
    },
    {
      "code": "ERA-SL-103",
      "src": "/Images/catalog/flexoera/ERA-SL-103.jpg"
    },
    {
      "code": "ERA-SL-104",
      "src": "/Images/catalog/flexoera/ERA-SL-104.jpg"
    },
    {
      "code": "ERA-SL-105",
      "src": "/Images/catalog/flexoera/ERA-SL-105.jpg"
    },
    {
      "code": "ERA-SL-107",
      "src": "/Images/catalog/flexoera/ERA-SL-107.jpg"
    },
    {
      "code": "ERA-SL-108",
      "src": "/Images/catalog/flexoera/ERA-SL-108.jpg"
    },
    {
      "code": "ERA-SL-109",
      "src": "/Images/catalog/flexoera/ERA-SL-109.jpg"
    },
    {
      "code": "ERA-SL-110",
      "src": "/Images/catalog/flexoera/ERA-SL-110.jpg"
    },
    {
      "code": "ERA-SL-111",
      "src": "/Images/catalog/flexoera/ERA-SL-111.jpg"
    },
    {
      "code": "ERA-SL-112",
      "src": "/Images/catalog/flexoera/ERA-SL-112.jpg"
    },
    {
      "code": "ERA-SL-114",
      "src": "/Images/catalog/flexoera/ERA-SL-114.jpg"
    },
    {
      "code": "ERA-SL-115",
      "src": "/Images/catalog/flexoera/ERA-SL-115.jpg"
    },
    {
      "code": "ERA-SL-116",
      "src": "/Images/catalog/flexoera/ERA-SL-116.jpg"
    },
    {
      "code": "ERA-SL-117",
      "src": "/Images/catalog/flexoera/ERA-SL-117.jpg"
    },
    {
      "code": "ERA-SL-118",
      "src": "/Images/catalog/flexoera/ERA-SL-118.jpg"
    },
    {
      "code": "ERA-SL-119",
      "src": "/Images/catalog/flexoera/ERA-SL-119.jpg"
    },
    {
      "code": "ERA-SL-120",
      "src": "/Images/catalog/flexoera/ERA-SL-120.jpg"
    },
    {
      "code": "ERA-SL-121",
      "src": "/Images/catalog/flexoera/ERA-SL-121.jpg"
    },
    {
      "code": "ERA-SL-122",
      "src": "/Images/catalog/flexoera/ERA-SL-122.jpg"
    },
    {
      "code": "ERA-SL-123",
      "src": "/Images/catalog/flexoera/ERA-SL-123.jpg"
    },
    {
      "code": "ERA-SL-124",
      "src": "/Images/catalog/flexoera/ERA-SL-124.jpg"
    },
    {
      "code": "ERA-SD-101",
      "src": "/Images/catalog/flexoera/ERA-SD-101.jpg"
    },
    {
      "code": "ERA-SD-102",
      "src": "/Images/catalog/flexoera/ERA-SD-102.jpg"
    },
    {
      "code": "ERA-SD-103",
      "src": "/Images/catalog/flexoera/ERA-SD-103.jpg"
    },
    {
      "code": "ERA-SD-104",
      "src": "/Images/catalog/flexoera/ERA-SD-104.jpg"
    },
    {
      "code": "ERA-SD-105",
      "src": "/Images/catalog/flexoera/ERA-SD-105.jpg"
    },
    {
      "code": "ERA-SD-106",
      "src": "/Images/catalog/flexoera/ERA-SD-106.jpg"
    },
    {
      "code": "ERA-SD-108",
      "src": "/Images/catalog/flexoera/ERA-SD-108.jpg"
    },
    {
      "code": "ERA-SD-110",
      "src": "/Images/catalog/flexoera/ERA-SD-110.jpg"
    },
    {
      "code": "ERA-SD-111",
      "src": "/Images/catalog/flexoera/ERA-SD-111.jpg"
    },
    {
      "code": "ERA-SD-112",
      "src": "/Images/catalog/flexoera/ERA-SD-112.jpg"
    },
    {
      "code": "ERA-SD-113",
      "src": "/Images/catalog/flexoera/ERA-SD-113.jpg"
    },
    {
      "code": "ERA-SD-114",
      "src": "/Images/catalog/flexoera/ERA-SD-114.jpg"
    },
    {
      "code": "ERA-SD-115",
      "src": "/Images/catalog/flexoera/ERA-SD-115.jpg"
    },
    {
      "code": "ERA-SD-118",
      "src": "/Images/catalog/flexoera/ERA-SD-118.jpg"
    },
    {
      "code": "ERA-SD-120",
      "src": "/Images/catalog/flexoera/ERA-SD-120.jpg"
    },
    {
      "code": "ERA-SD-122",
      "src": "/Images/catalog/flexoera/ERA-SD-122.jpg"
    },
    {
      "code": "ERA-SD-124",
      "src": "/Images/catalog/flexoera/ERA-SD-124.jpg"
    },
    {
      "code": "ERA-SD-127",
      "src": "/Images/catalog/flexoera/ERA-SD-127.jpg"
    },
    {
      "code": "ERA-SD-128",
      "src": "/Images/catalog/flexoera/ERA-SD-128.jpg"
    },
    {
      "code": "ERA-SD-129",
      "src": "/Images/catalog/flexoera/ERA-SD-129.jpg"
    },
    {
      "code": "ERA-SD-130",
      "src": "/Images/catalog/flexoera/ERA-SD-130.jpg"
    },
    {
      "code": "ERA-SD-131",
      "src": "/Images/catalog/flexoera/ERA-SD-131.jpg"
    },
    {
      "code": "ERA-SD-132",
      "src": "/Images/catalog/flexoera/ERA-SD-132.jpg"
    },
    {
      "code": "ERA-SD-107",
      "src": "/Images/catalog/flexoera/ERA-SD-107.jpg"
    },
    {
      "code": "ERA-SD-109",
      "src": "/Images/catalog/flexoera/ERA-SD-109.jpg"
    },
    {
      "code": "ERA-SD-116",
      "src": "/Images/catalog/flexoera/ERA-SD-116.jpg"
    },
    {
      "code": "ERA-SD-117",
      "src": "/Images/catalog/flexoera/ERA-SD-117.jpg"
    },
    {
      "code": "ERA-SD-119",
      "src": "/Images/catalog/flexoera/ERA-SD-119.jpg"
    },
    {
      "code": "ERA-SD-121-1",
      "src": "/Images/catalog/flexoera/ERA-SD-121-1.jpg"
    },
    {
      "code": "ERA-SD-121-2",
      "src": "/Images/catalog/flexoera/ERA-SD-121-2.jpg"
    },
    {
      "code": "ERA-SD-123",
      "src": "/Images/catalog/flexoera/ERA-SD-123.jpg"
    },
    {
      "code": "ERA-SD-125",
      "src": "/Images/catalog/flexoera/ERA-SD-125.jpg"
    },
    {
      "code": "ERA-SD-126",
      "src": "/Images/catalog/flexoera/ERA-SD-126.jpg"
    },
  ],
  "onyxoera": [
    {
      "code": "ERA-SL-101_1",
      "src": "/Images/catalog/onyxoera/ERA-SL-101_1.jpg"
    },
    {
      "code": "ERA-SL-101_2",
      "src": "/Images/catalog/onyxoera/ERA-SL-101_2.jpg"
    },
    {
      "code": "ERA-SL-101_3",
      "src": "/Images/catalog/onyxoera/ERA-SL-101_3.jpg"
    },
    {
      "code": "ERA-SL-101_4",
      "src": "/Images/catalog/onyxoera/ERA-SL-101_4.jpg"
    },
    {
      "code": "ERA-SL-101_5",
      "src": "/Images/catalog/onyxoera/ERA-SL-101_5.jpg"
    },
    {
      "code": "ERA-SL-102",
      "src": "/Images/catalog/onyxoera/ERA-SL-102.jpg"
    },
    {
      "code": "ERA-SL-103",
      "src": "/Images/catalog/onyxoera/ERA-SL-103.jpg"
    },
    {
      "code": "ERA-SL-105",
      "src": "/Images/catalog/onyxoera/ERA-SL-105.jpg"
    },
    {
      "code": "ERA-SL-107",
      "src": "/Images/catalog/onyxoera/ERA-SL-107.jpg"
    },
    {
      "code": "ERA-SL-108",
      "src": "/Images/catalog/onyxoera/ERA-SL-108.jpg"
    },
    {
      "code": "ERA-SL-114",
      "src": "/Images/catalog/onyxoera/ERA-SL-114.jpg"
    },
    {
      "code": "ERA-SL-115_1",
      "src": "/Images/catalog/onyxoera/ERA-SL-115_1.jpg"
    },
    {
      "code": "ERA-SL-115_2",
      "src": "/Images/catalog/onyxoera/ERA-SL-115_2.jpg"
    },
    {
      "code": "ERA-SL-117_1",
      "src": "/Images/catalog/onyxoera/ERA-SL-117_1.jpg"
    },
    {
      "code": "ERA-SL-117_2",
      "src": "/Images/catalog/onyxoera/ERA-SL-117_2.jpg"
    },
    {
      "code": "ERA-SL-117_3",
      "src": "/Images/catalog/onyxoera/ERA-SL-117_3.jpg"
    },
    {
      "code": "ERA-SL-118_1",
      "src": "/Images/catalog/onyxoera/ERA-SL-118_1.jpg"
    },
    {
      "code": "ERA-SL-118_2",
      "src": "/Images/catalog/onyxoera/ERA-SL-118_2.jpg"
    },
    {
      "code": "ERA-SL-118_3",
      "src": "/Images/catalog/onyxoera/ERA-SL-118_3.jpg"
    },
    {
      "code": "ERA-SL-118_4",
      "src": "/Images/catalog/onyxoera/ERA-SL-118_4.jpg"
    },
    {
      "code": "ERA-SL-119",
      "src": "/Images/catalog/onyxoera/ERA-SL-119.jpg"
    },
    {
      "code": "ERA-SL-120",
      "src": "/Images/catalog/onyxoera/ERA-SL-120.jpg"
    },
    {
      "code": "ERA-SL-121",
      "src": "/Images/catalog/onyxoera/ERA-SL-121.jpg"
    },
    {
      "code": "ERA-SL-122",
      "src": "/Images/catalog/onyxoera/ERA-SL-122.jpg"
    },
  ],
  "decoera": [
    {
      "code": "ERA-SL-11001",
      "src": "/Images/catalog/decoera/ERA-SL-11001.jpg"
    },
    {
      "code": "ERA-SL-11002",
      "src": "/Images/catalog/decoera/ERA-SL-11002.jpg"
    },
    {
      "code": "ERA-SL-11003",
      "src": "/Images/catalog/decoera/ERA-SL-11003.jpg"
    },
    {
      "code": "ERA-SL-11004",
      "src": "/Images/catalog/decoera/ERA-SL-11004.jpg"
    },
    {
      "code": "ERA-SL-11005",
      "src": "/Images/catalog/decoera/ERA-SL-11005.jpg"
    },
    {
      "code": "ERA-SL-11006",
      "src": "/Images/catalog/decoera/ERA-SL-11006.jpg"
    },
    {
      "code": "ERA-SL-11007",
      "src": "/Images/catalog/decoera/ERA-SL-11007.jpg"
    },
    {
      "code": "ERA-SL-11008",
      "src": "/Images/catalog/decoera/ERA-SL-11008.jpg"
    },
    {
      "code": "ERA-SL-11009",
      "src": "/Images/catalog/decoera/ERA-SL-11009.jpg"
    },
    {
      "code": "ERA-SL-11010",
      "src": "/Images/catalog/decoera/ERA-SL-11010.jpg"
    },
    {
      "code": "ERA-SD-21001",
      "src": "/Images/catalog/decoera/ERA-SD-21001.jpg"
    },
    {
      "code": "ERA-SD-21002",
      "src": "/Images/catalog/decoera/ERA-SD-21002.jpg"
    },
    {
      "code": "ERA-SD-21003",
      "src": "/Images/catalog/decoera/ERA-SD-21003.jpg"
    },
    {
      "code": "ERA-SD-21004",
      "src": "/Images/catalog/decoera/ERA-SD-21004.jpg"
    },
    {
      "code": "ERA-SD-21005",
      "src": "/Images/catalog/decoera/ERA-SD-21005.jpg"
    },
    {
      "code": "ERA-SD-21006",
      "src": "/Images/catalog/decoera/ERA-SD-21006.jpg"
    },
    {
      "code": "ERA-SD-21007",
      "src": "/Images/catalog/decoera/ERA-SD-21007.jpg"
    },
    {
      "code": "ERA-SD-21008",
      "src": "/Images/catalog/decoera/ERA-SD-21008.jpg"
    },
    {
      "code": "ERA-SD-21009",
      "src": "/Images/catalog/decoera/ERA-SD-21009.jpg"
    },
    {
      "code": "ERA-SD-21010",
      "src": "/Images/catalog/decoera/ERA-SD-21010.jpg"
    },
    {
      "code": "SSL-1002",
      "src": "/Images/catalog/decoera/SSL-1002.jpg"
    },
    {
      "code": "SSL-1001",
      "src": "/Images/catalog/decoera/SSL-1001.jpg"
    },
    {
      "code": "SSL-1003",
      "src": "/Images/catalog/decoera/SSL-1003.jpg"
    },
    {
      "code": "SSL-1004",
      "src": "/Images/catalog/decoera/SSL-1004.jpg"
    },
    {
      "code": "SSL-1005",
      "src": "/Images/catalog/decoera/SSL-1005.jpg"
    },
    {
      "code": "SSL-1007",
      "src": "/Images/catalog/decoera/SSL-1007.jpg"
    },
    {
      "code": "SSL-1006",
      "src": "/Images/catalog/decoera/SSL-1006.jpg"
    },
    {
      "code": "SSL-1008",
      "src": "/Images/catalog/decoera/SSL-1008.jpg"
    },
    {
      "code": "SSL-1009",
      "src": "/Images/catalog/decoera/SSL-1009.jpg"
    },
    {
      "code": "SSL-1010",
      "src": "/Images/catalog/decoera/SSL-1010.jpg"
    },
    {
      "code": "SSL-1501",
      "src": "/Images/catalog/decoera/SSL-1501.jpg"
    },
    {
      "code": "SSL-1502",
      "src": "/Images/catalog/decoera/SSL-1502.jpg"
    },
    {
      "code": "SSL-1503",
      "src": "/Images/catalog/decoera/SSL-1503.jpg"
    },
    {
      "code": "SSL-1504",
      "src": "/Images/catalog/decoera/SSL-1504.jpg"
    },
    {
      "code": "SDL-2001",
      "src": "/Images/catalog/decoera/SDL-2001.jpg"
    },
    {
      "code": "SDL-2002",
      "src": "/Images/catalog/decoera/SDL-2002.jpg"
    },
    {
      "code": "SDL-2003",
      "src": "/Images/catalog/decoera/SDL-2003.jpg"
    },
    {
      "code": "SDL-2004",
      "src": "/Images/catalog/decoera/SDL-2004.jpg"
    },
  ],
  "artoera": [
    {
      "code": "FAB-01",
      "src": "/Images/catalog/artoera/FAB-01.jpg"
    },
    {
      "code": "FAB-02",
      "src": "/Images/catalog/artoera/FAB-02.jpg"
    },
    {
      "code": "FAB-03",
      "src": "/Images/catalog/artoera/FAB-03.jpg"
    },
    {
      "code": "FAB-04",
      "src": "/Images/catalog/artoera/FAB-04.jpg"
    },
    {
      "code": "FAB-05",
      "src": "/Images/catalog/artoera/FAB-05.jpg"
    },
    {
      "code": "FAB-06",
      "src": "/Images/catalog/artoera/FAB-06.jpg"
    },
    {
      "code": "FAB-07",
      "src": "/Images/catalog/artoera/FAB-07.jpg"
    },
    {
      "code": "FAB-08",
      "src": "/Images/catalog/artoera/FAB-08.jpg"
    },
    {
      "code": "FAB-09",
      "src": "/Images/catalog/artoera/FAB-09.jpg"
    },
    {
      "code": "FAB-10",
      "src": "/Images/catalog/artoera/FAB-10.jpg"
    },
  ],
  "walloera": [
    {
      "code": "ERA-3001",
      "src": "/Images/catalog/walloera/ERA-3001.jpg"
    },
    {
      "code": "ERA-3002",
      "src": "/Images/catalog/walloera/ERA-3002.jpg"
    },
    {
      "code": "ERA-3003",
      "src": "/Images/catalog/walloera/ERA-3003.jpg"
    },
    {
      "code": "ERA-3004",
      "src": "/Images/catalog/walloera/ERA-3004.jpg"
    },
    {
      "code": "ERA-3005",
      "src": "/Images/catalog/walloera/ERA-3005.jpg"
    },
    {
      "code": "ERA-3006",
      "src": "/Images/catalog/walloera/ERA-3006.jpg"
    },
    {
      "code": "ERA-3007",
      "src": "/Images/catalog/walloera/ERA-3007.jpg"
    },
    {
      "code": "ERA-3008",
      "src": "/Images/catalog/walloera/ERA-3008.jpg"
    },
    {
      "code": "ERA-3009",
      "src": "/Images/catalog/walloera/ERA-3009.jpg"
    },
    {
      "code": "ERA-3010",
      "src": "/Images/catalog/walloera/ERA-3010.jpg"
    },
  ],
  "designoera": [
    {
      "code": "DES-01",
      "src": "/Images/catalog/designoera/DES-01.jpg"
    },
    {
      "code": "DES-02",
      "src": "/Images/catalog/designoera/DES-02.jpg"
    },
    {
      "code": "DES-03",
      "src": "/Images/catalog/designoera/DES-03.jpg"
    },
    {
      "code": "DES-04",
      "src": "/Images/catalog/designoera/DES-04.jpg"
    },
  ],
  "rockoera": [
    {
      "code": "BLACK LOUVER",
      "src": "/Images/catalog/rockoera/BLACK-LOUVER.jpg"
    },
    {
      "code": "CARVING 3 FINISH BLACK WHITE",
      "src": "/Images/catalog/rockoera/CARVING-3-FINISH-BLACK-WHITE.jpg"
    },
    {
      "code": "CARVING 3 FINISH YELLOW",
      "src": "/Images/catalog/rockoera/CARVING-3-FINISH-YELLOW.jpg"
    },
    {
      "code": "DEAREST LOUVER",
      "src": "/Images/catalog/rockoera/DEAREST-LOUVER.jpg"
    },
    {
      "code": "FEATHER BLACK GOLD",
      "src": "/Images/catalog/rockoera/FEATHER-BLACK-GOLD.jpg"
    },
    {
      "code": "FISH WAVE BEG GREY",
      "src": "/Images/catalog/rockoera/FISH-WAVE-BEG-GREY.jpg"
    },
    {
      "code": "FLOWER TREE CREAM",
      "src": "/Images/catalog/rockoera/FLOWER-TREE-CREAM.jpg"
    },
    {
      "code": "MAHARAJA BEG",
      "src": "/Images/catalog/rockoera/MAHARAJA-BEG.jpg"
    },
    {
      "code": "MAHARAJA MULTI COLOR",
      "src": "/Images/catalog/rockoera/MAHARAJA-MULTI-COLOR.jpg"
    },
    {
      "code": "MULTI LOUVER",
      "src": "/Images/catalog/rockoera/MULTI-LOUVER.jpg"
    },
    {
      "code": "MULTI PATTA WHITE",
      "src": "/Images/catalog/rockoera/MULTI-PATTA-WHITE.jpg"
    },
    {
      "code": "OFF WHITE LOUVER",
      "src": "/Images/catalog/rockoera/OFF-WHITE-LOUVER.jpg"
    },
    {
      "code": "OZONE TRIANGLE OFF WHITE",
      "src": "/Images/catalog/rockoera/OZONE-TRIANGLE-OFF-WHITE.jpg"
    },
    {
      "code": "SQUARE GREY",
      "src": "/Images/catalog/rockoera/SQUARE-GREY.jpg"
    },
    {
      "code": "SQUARE WHITE BLACK",
      "src": "/Images/catalog/rockoera/SQUARE-WHITE-BLACK.jpg"
    },
    {
      "code": "SQUARE YELLOW",
      "src": "/Images/catalog/rockoera/SQUARE-YELLOW.jpg"
    },
    {
      "code": "STEEL GREY LOUVER",
      "src": "/Images/catalog/rockoera/STEEL-GREY-LOUVER.jpg"
    },
    {
      "code": "TRIANGLE CREAM",
      "src": "/Images/catalog/rockoera/TRIANGLE-CREAM.jpg"
    },
  ],
  "slatera": [
    {
      "code": "ERA SL 101-11",
      "src": "/Images/catalog/slatera/ERA-SL-101-11.jpg"
    },
    {
      "code": "ERA SL 101-12",
      "src": "/Images/catalog/slatera/ERA-SL-101-12.jpg"
    },
    {
      "code": "ERA SL 101-13",
      "src": "/Images/catalog/slatera/ERA-SL-101-13.jpg"
    },
    {
      "code": "ERA SL 101-14",
      "src": "/Images/catalog/slatera/ERA-SL-101-14.jpg"
    },
    {
      "code": "ERA SL 102",
      "src": "/Images/catalog/slatera/ERA-SL-102.jpg"
    },
    {
      "code": "ERA SL 103",
      "src": "/Images/catalog/slatera/ERA-SL-103.jpg"
    },
    {
      "code": "ERA SL 104-1",
      "src": "/Images/catalog/slatera/ERA-SL-104-1.jpg"
    },
    {
      "code": "ERA SL 104-2",
      "src": "/Images/catalog/slatera/ERA-SL-104-2.jpg"
    },
    {
      "code": "ERA SL 105",
      "src": "/Images/catalog/slatera/ERA-SL-105.jpg"
    },
    {
      "code": "ERA SL 107-3",
      "src": "/Images/catalog/slatera/ERA-SL-107-3.jpg"
    },
    {
      "code": "ERA SL 108",
      "src": "/Images/catalog/slatera/ERA-SL-108.jpg"
    },
    {
      "code": "ERA SL 109-1",
      "src": "/Images/catalog/slatera/ERA-SL-109-1.jpg"
    },
    {
      "code": "ERA SL 110-2",
      "src": "/Images/catalog/slatera/ERA-SL-110-2.jpg"
    },
    {
      "code": "ERA SL 111-2",
      "src": "/Images/catalog/slatera/ERA-SL-111-2.jpg"
    },
    {
      "code": "ERA SL 112",
      "src": "/Images/catalog/slatera/ERA-SL-112.jpg"
    },
    {
      "code": "ERA SL 114",
      "src": "/Images/catalog/slatera/ERA-SL-114.jpg"
    },
    {
      "code": "ERA SL 115-03",
      "src": "/Images/catalog/slatera/ERA-SL-115-03.jpg"
    },
    {
      "code": "ERA SL 115-04",
      "src": "/Images/catalog/slatera/ERA-SL-115-04.jpg"
    },
    {
      "code": "ERA SL 115-06",
      "src": "/Images/catalog/slatera/ERA-SL-115-06.jpg"
    },
    {
      "code": "ERA SL 116",
      "src": "/Images/catalog/slatera/ERA-SL-116.jpg"
    },
    {
      "code": "ERA SL 117-07",
      "src": "/Images/catalog/slatera/ERA-SL-117-07.jpg"
    },
    {
      "code": "ERA SL 117-2",
      "src": "/Images/catalog/slatera/ERA-SL-117-2.jpg"
    },
    {
      "code": "ERA SL 117-3",
      "src": "/Images/catalog/slatera/ERA-SL-117-3.jpg"
    },
    {
      "code": "ERA SL 117-5",
      "src": "/Images/catalog/slatera/ERA-SL-117-5.jpg"
    },
    {
      "code": "ERA SL 118-1",
      "src": "/Images/catalog/slatera/ERA-SL-118-1.jpg"
    },
    {
      "code": "ERA SL 118-2",
      "src": "/Images/catalog/slatera/ERA-SL-118-2.jpg"
    },
    {
      "code": "ERA SL 119",
      "src": "/Images/catalog/slatera/ERA-SL-119.jpg"
    },
    {
      "code": "ERA SL 120",
      "src": "/Images/catalog/slatera/ERA-SL-120.jpg"
    },
    {
      "code": "ERA SL 121-3",
      "src": "/Images/catalog/slatera/ERA-SL-121-3.jpg"
    },
    {
      "code": "ERA SL 122",
      "src": "/Images/catalog/slatera/ERA-SL-122.jpg"
    },
    {
      "code": "ERA SL 123-2",
      "src": "/Images/catalog/slatera/ERA-SL-123-2.jpg"
    },
    {
      "code": "ERA SL 124-1",
      "src": "/Images/catalog/slatera/ERA-SL-124-1.jpg"
    },
    {
      "code": "ERA SL 124-3",
      "src": "/Images/catalog/slatera/ERA-SL-124-3.jpg"
    },
    {
      "code": "ERA SL 124-4",
      "src": "/Images/catalog/slatera/ERA-SL-124-4.jpg"
    }
  ],
  "slate-translucent": [
    {
      "code": "ERA ST BISTER",
      "src": "/Images/catalog/slate-translucent/BISTER.jpg"
    },
    {
      "code": "ERA ST EARTH-GREY-1",
      "src": "/Images/catalog/slate-translucent/EARTH-GREY-1.jpg"
    },
    {
      "code": "ERA ST EARTH-GREY-2",
      "src": "/Images/catalog/slate-translucent/EARTH-GREY-2.jpg"
    },
    {
      "code": "ERA ST RAIN-FOREST-1",
      "src": "/Images/catalog/slate-translucent/RAIN-FOREST-1.jpg"
    },
    {
      "code": "ERA ST RAIN-FOREST-2",
      "src": "/Images/catalog/slate-translucent/RAIN-FOREST-2.jpg"
    },
    {
      "code": "ERA ST RAIN-FOREST-3",
      "src": "/Images/catalog/slate-translucent/RAIN-FOREST-3.jpg"
    },
    {
      "code": "ERA ST RAIN-FOREST-4",
      "src": "/Images/catalog/slate-translucent/RAIN-FOREST-4.jpg"
    },
    {
      "code": "ERA ST VERMONT",
      "src": "/Images/catalog/slate-translucent/VERMONT.jpg"
    },
    {
      "code": "ERA ST COP-PRISMA",
      "src": "/Images/catalog/slate-translucent/COP-PRISMA.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-1",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-1.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-2",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-2.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-3",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-3.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-4",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-4.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-5",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-5.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-6",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-6.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-7",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-7.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-8",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-8.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-9",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-9.jpg"
    },
    {
      "code": "ERA ST HIMALAYAN-ASH-10",
      "src": "/Images/catalog/slate-translucent/HIMALAYAN-ASH-10.jpg"
    },
    {
      "code": "ERA ST INK-BLACK",
      "src": "/Images/catalog/slate-translucent/INK-BLACK.jpg"
    },
    {
      "code": "ERA ST BLACK-WAVE",
      "src": "/Images/catalog/slate-translucent/BLACK-WAVE.jpg"
    },
    {
      "code": "ERA ST STONE-MIST",
      "src": "/Images/catalog/slate-translucent/STONE-MIST.jpg"
    },
    {
      "code": "ERA ST GREEN-RIDGE-1",
      "src": "/Images/catalog/slate-translucent/GREEN-RIDGE-1.jpg"
    },
    {
      "code": "ERA ST GREEN-RIDGE-2",
      "src": "/Images/catalog/slate-translucent/GREEN-RIDGE-2.jpg"
    },
    {
      "code": "ERA ST GREEN-RIDGE-3",
      "src": "/Images/catalog/slate-translucent/GREEN-RIDGE-3.jpg"
    },
    {
      "code": "ERA ST GREEN-RIDGE-4",
      "src": "/Images/catalog/slate-translucent/GREEN-RIDGE-4.jpg"
    },
    {
      "code": "ERA ST CANOPY-GREY",
      "src": "/Images/catalog/slate-translucent/CANOPY-GREY.jpg"
    },
    {
      "code": "ERA ST HABITAT-SPARK",
      "src": "/Images/catalog/slate-translucent/HABITAT-SPARK.jpg"
    },
    {
      "code": "ERA ST UMBER-1",
      "src": "/Images/catalog/slate-translucent/UMBER-1.jpg"
    },
    {
      "code": "ERA ST UMBER-2",
      "src": "/Images/catalog/slate-translucent/UMBER-2.jpg"
    },
    {
      "code": "ERA ST MOUNTANA-RED",
      "src": "/Images/catalog/slate-translucent/MOUNTANA-RED.jpg"
    },
    {
      "code": "ERA ST GREENBELT",
      "src": "/Images/catalog/slate-translucent/GREENBELT.jpg"
    }
  ],

  "sandera": [
    {
      "code": "ERA SD 101-2",
      "src": "/Images/catalog/sandera/ERA-SD-101-2.jpg"
    },
    {
      "code": "ERA SD 101-3",
      "src": "/Images/catalog/sandera/ERA-SD-101-3.jpg"
    },
    {
      "code": "ERA SD 103",
      "src": "/Images/catalog/sandera/ERA-SD-103.jpg"
    },
    {
      "code": "ERA SD 104",
      "src": "/Images/catalog/sandera/ERA-SD-104.jpg"
    },
    {
      "code": "ERA SD 105-1",
      "src": "/Images/catalog/sandera/ERA-SD-105-1.jpg"
    },
    {
      "code": "ERA SD 106",
      "src": "/Images/catalog/sandera/ERA-SD-106.jpg"
    },
    {
      "code": "ERA SD 107-3",
      "src": "/Images/catalog/sandera/ERA-SD-107-3.jpg"
    },
    {
      "code": "ERA SD 107-4",
      "src": "/Images/catalog/sandera/ERA-SD-107-4.jpg"
    },
    {
      "code": "ERA SD 108",
      "src": "/Images/catalog/sandera/ERA-SD-108.jpg"
    },
    {
      "code": "ERA SD 109-4",
      "src": "/Images/catalog/sandera/ERA-SD-109-4.jpg"
    },
    {
      "code": "ERA SD 109-6",
      "src": "/Images/catalog/sandera/ERA-SD-109-6.jpg"
    },
    {
      "code": "ERA SD 110",
      "src": "/Images/catalog/sandera/ERA-SD-110.jpg"
    },
    {
      "code": "ERA SD 112",
      "src": "/Images/catalog/sandera/ERA-SD-112.jpg"
    },
    {
      "code": "ERA SD 113-1",
      "src": "/Images/catalog/sandera/ERA-SD-113-1.jpg"
    },
    {
      "code": "ERA SD 113-2",
      "src": "/Images/catalog/sandera/ERA-SD-113-2.jpg"
    },
    {
      "code": "ERA SD 114-1",
      "src": "/Images/catalog/sandera/ERA-SD-114-1.jpg"
    },
    {
      "code": "ERA SD 114-2",
      "src": "/Images/catalog/sandera/ERA-SD-114-2.jpg"
    },
    {
      "code": "ERA SD 115-1",
      "src": "/Images/catalog/sandera/ERA-SD-115-1.jpg"
    },
    {
      "code": "ERA SD 115-2",
      "src": "/Images/catalog/sandera/ERA-SD-115-2.jpg"
    },
    {
      "code": "ERA SD 116",
      "src": "/Images/catalog/sandera/ERA-SD-116.jpg"
    },
    {
      "code": "ERA SD 117",
      "src": "/Images/catalog/sandera/ERA-SD-117.jpg"
    },
    {
      "code": "ERA SD 118-1",
      "src": "/Images/catalog/sandera/ERA-SD-118-1.jpg"
    },
    {
      "code": "ERA SD 118-2",
      "src": "/Images/catalog/sandera/ERA-SD-118-2.jpg"
    },
    {
      "code": "ERA SD 119",
      "src": "/Images/catalog/sandera/ERA-SD-119.jpg"
    },
    {
      "code": "ERA SD 120-1",
      "src": "/Images/catalog/sandera/ERA-SD-120-1.jpg"
    },
    {
      "code": "ERA SD 121-2",
      "src": "/Images/catalog/sandera/ERA-SD-121-2.jpg"
    },
    {
      "code": "ERA SD 122",
      "src": "/Images/catalog/sandera/ERA-SD-122.jpg"
    },
    {
      "code": "ERA SD 123",
      "src": "/Images/catalog/sandera/ERA-SD-123.jpg"
    },
    {
      "code": "ERA SD 124",
      "src": "/Images/catalog/sandera/ERA-SD-124.jpg"
    },
    {
      "code": "ERA SD 125",
      "src": "/Images/catalog/sandera/ERA-SD-125.jpg"
    },
    {
      "code": "ERA SD 126",
      "src": "/Images/catalog/sandera/ERA-SD-126.jpg"
    },
    {
      "code": "ERA SD 127-1",
      "src": "/Images/catalog/sandera/ERA-SD-127-1.jpg"
    },
    {
      "code": "ERA SD 127-2",
      "src": "/Images/catalog/sandera/ERA-SD-127-2.jpg"
    },
    {
      "code": "ERA SD 128",
      "src": "/Images/catalog/sandera/ERA-SD-128.jpg"
    },
    {
      "code": "ERA SD 129-1",
      "src": "/Images/catalog/sandera/ERA-SD-129-1.jpg"
    },
    {
      "code": "ERA SD 130",
      "src": "/Images/catalog/sandera/ERA-SD-130.jpg"
    },
    {
      "code": "ERA SD 131",
      "src": "/Images/catalog/sandera/ERA-SD-131.jpg"
    },
    {
      "code": "ERA SD 132-1",
      "src": "/Images/catalog/sandera/ERA-SD-132-1.jpg"
    }
  ],
  "rockoera-decor": [
    {
      "code": "SQUARE GREY",
      "src": "/Images/catalog/rockoera-decor/SQUARE-GREY.jpg"
    },
    {
      "code": "SQUARE YELLOW",
      "src": "/Images/catalog/rockoera-decor/SQUARE-YELLOW.jpg"
    },
    {
      "code": "CARVING 3 FINISH BLACK WHITE",
      "src": "/Images/catalog/rockoera-decor/CARVING-3-FINISH-BLACK-WHITE.jpg"
    },
    {
      "code": "CARVING 3 FINISH YELLOW",
      "src": "/Images/catalog/rockoera-decor/CARVING-3-FINISH-YELLOW.jpg"
    },
    {
      "code": "FEATHER BLACK GOLD",
      "src": "/Images/catalog/rockoera-decor/FEATHER-BLACK-GOLD.jpg"
    },
    {
      "code": "FISH WAVE BEG GREY",
      "src": "/Images/catalog/rockoera-decor/FISH-WAVE-BEG-GREY.jpg"
    },
    {
      "code": "MAHARAJA BEG",
      "src": "/Images/catalog/rockoera-decor/MAHARAJA-BEG.jpg"
    },
    {
      "code": "MAHARAJA MULTI COLOR",
      "src": "/Images/catalog/rockoera-decor/MAHARAJA-MULTI-COLOR.jpg"
    },
    {
      "code": "MULTI PATTA WHITE",
      "src": "/Images/catalog/rockoera-decor/MULTI-PATTA-WHITE.jpg"
    },
    {
      "code": "OZONE TRIANGLE OFF WHITE",
      "src": "/Images/catalog/rockoera-decor/OZONE-TRIANGLE-OFF-WHITE.jpg"
    },
    {
      "code": "SQUARE WHITE BLACK",
      "src": "/Images/catalog/rockoera-decor/SQUARE-WHITE-BLACK.jpg"
    },
    {
      "code": "TRIANGLE CREAM",
      "src": "/Images/catalog/rockoera-decor/TRIANGLE-CREAM.jpg"
    }
  ],
  "rockoera-leaf": [
    {
      "code": "FLOWER TREE CREAM",
      "src": "/Images/catalog/rockoera-leaf/FLOWER-TREE-CREAM.jpg"
    }
  ],
  "rockoera-louver": [
    {
      "code": "OFF WHITE LOUVER",
      "src": "/Images/catalog/rockoera-louver/OFF-WHITE-LOUVER.jpg"
    },
    {
      "code": "BLACK LOUVER",
      "src": "/Images/catalog/rockoera-louver/BLACK-LOUVER.jpg"
    },
    {
      "code": "DEAREST LOUVER",
      "src": "/Images/catalog/rockoera-louver/DEAREST-LOUVER.jpg"
    },
    {
      "code": "MULTI LOUVER",
      "src": "/Images/catalog/rockoera-louver/MULTI-LOUVER.jpg"
    },
    {
      "code": "STEEL GREY LOUVER",
      "src": "/Images/catalog/rockoera-louver/STEEL-GREY-LOUVER.jpg"
    }
  ],
  "bookmatch": [
    {
      "code": "ERA BM 207",
      "src": "/Images/catalog/bookmatch/ERA-BM-207.jpg"
    },
    {
      "code": "ERA BM 209",
      "src": "/Images/catalog/bookmatch/ERA-BM-209.jpg"
    },
    {
      "code": "ERA BM 210",
      "src": "/Images/catalog/bookmatch/ERA-BM-210.jpg"
    }
  ],
  "flexartoera": [
    {
      "code": "FAB-711044",
      "src": "/Images/catalog/flexartoera/FAB-711044.jpg"
    },
    {
      "code": "FAB-711062",
      "src": "/Images/catalog/flexartoera/FAB-711062.jpg"
    },
    {
      "code": "FAB-711078",
      "src": "/Images/catalog/flexartoera/FAB-711078.jpg"
    },
    {
      "code": "FAB-711096",
      "src": "/Images/catalog/flexartoera/FAB-711096.jpg"
    },
    {
      "code": "FAB-711138",
      "src": "/Images/catalog/flexartoera/FAB-711138.jpg"
    },
    {
      "code": "FAB-711153",
      "src": "/Images/catalog/flexartoera/FAB-711153.jpg"
    },
    {
      "code": "FAB-711188",
      "src": "/Images/catalog/flexartoera/FAB-711188.jpg"
    },
    {
      "code": "FAB-711239",
      "src": "/Images/catalog/flexartoera/FAB-711239.jpg"
    },
    {
      "code": "FAB-711256",
      "src": "/Images/catalog/flexartoera/FAB-711256.jpg"
    }
  ],
  "jumboera": [
    {
      "code": "BOOKMATCH JUMBOERA 074",
      "src": "/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-074.jpg"
    },
    {
      "code": "BOOKMATCH JUMBOERA 095",
      "src": "/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-095.jpg"
    },
    {
      "code": "BOOKMATCH JUMBOERA 113",
      "src": "/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-113.jpg"
    },
    {
      "code": "BOOKMATCH JUMBOERA 135",
      "src": "/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-135.jpg"
    },
    {
      "code": "BOOKMATCH JUMBOERA IMG552",
      "src": "/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-IMG552.jpg"
    },
    {
      "code": "BOOKMATCH JUMBOERA IMG556",
      "src": "/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-IMG556.jpg"
    }
  ],
  "sand-translucent": [
    {
      "code": "SAND TRANSLUCENT 01",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-01.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 02",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-02.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 03",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-03.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 04",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-04.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 05",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-05.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 06",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-06.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 07",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-07.jpg"
    },
    {
      "code": "SAND TRANSLUCENT 08",
      "src": "/Images/catalog/sand-translucent/SAND-TRANSLUCENT-08.jpg"
    }
  ],
  "application-images": [
    {
      "code": "APPLICATION 07",
      "src": "/Images/catalog/application-images/APPLICATION-07.jpg"
    },
    {
      "code": "APPLICATION 08",
      "src": "/Images/catalog/application-images/APPLICATION-08.jpg"
    },
    {
      "code": "APPLICATION 09",
      "src": "/Images/catalog/application-images/APPLICATION-09.jpg"
    },
    {
      "code": "APPLICATION 10",
      "src": "/Images/catalog/application-images/APPLICATION-10.jpg"
    },
    {
      "code": "APPLICATION 11",
      "src": "/Images/catalog/application-images/APPLICATION-11.jpg"
    },
    {
      "code": "APPLICATION 12",
      "src": "/Images/catalog/application-images/APPLICATION-12.jpg"
    }
  ],
  "real-projects": [
    {
      "code": "STONE-VENEER-01",
      "src": "/Images/catalog/real-projects/STONE-VENEER-01.jpg"
    },
    {
      "code": "STONE-VENEER-02",
      "src": "/Images/catalog/real-projects/STONE-VENEER-02.jpg"
    },
    {
      "code": "STONE-VENEER-03",
      "src": "/Images/catalog/real-projects/STONE-VENEER-03.jpg"
    },
    {
      "code": "STONE-VENEER-04",
      "src": "/Images/catalog/real-projects/STONE-VENEER-04.jpg"
    },
    {
      "code": "STONE-VENEER-05",
      "src": "/Images/catalog/real-projects/STONE-VENEER-05.jpg"
    },
    {
      "code": "STONE-VENEER-06",
      "src": "/Images/catalog/real-projects/STONE-VENEER-06.jpg"
    },
    {
      "code": "STONE-VENEER-07",
      "src": "/Images/catalog/real-projects/STONE-VENEER-07.jpg"
    },
    {
      "code": "STONE-VENEER-08",
      "src": "/Images/catalog/real-projects/STONE-VENEER-08.jpg"
    },
    {
      "code": "STONE-VENEER-09",
      "src": "/Images/catalog/real-projects/STONE-VENEER-09.jpg"
    },
    {
      "code": "STONE-VENEER-10",
      "src": "/Images/catalog/real-projects/STONE-VENEER-10.jpg"
    },
    {
      "code": "STONE-VENEER-11",
      "src": "/Images/catalog/real-projects/STONE-VENEER-11.jpg"
    },
    {
      "code": "STONE-VENEER-12",
      "src": "/Images/catalog/real-projects/STONE-VENEER-12.jpg"
    },
    {
      "code": "STONE-VENEER-13",
      "src": "/Images/catalog/real-projects/STONE-VENEER-13.jpg"
    },
    {
      "code": "STONE-VENEER-14",
      "src": "/Images/catalog/real-projects/STONE-VENEER-14.jpg"
    },
    {
      "code": "STONE-VENEER-15",
      "src": "/Images/catalog/real-projects/STONE-VENEER-15.jpg"
    },
    {
      "code": "STONE-VENEER-16",
      "src": "/Images/catalog/real-projects/STONE-VENEER-16.jpg"
    },
    {
      "code": "STONE-VENEER-17",
      "src": "/Images/catalog/real-projects/STONE-VENEER-17.jpg"
    },
    {
      "code": "STONE-VENEER-18",
      "src": "/Images/catalog/real-projects/STONE-VENEER-18.jpg"
    },
    {
      "code": "DEALER-DISPLAY-01",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-01.jpg"
    },
    {
      "code": "DEALER-DISPLAY-02",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-02.jpg"
    },
    {
      "code": "DEALER-DISPLAY-03",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-03.jpg"
    },
    {
      "code": "DEALER-DISPLAY-04",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-04.jpg"
    },
    {
      "code": "DEALER-DISPLAY-05",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-05.jpg"
    },
    {
      "code": "DEALER-DISPLAY-06",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-06.jpg"
    },
    {
      "code": "DEALER-DISPLAY-07",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-07.jpg"
    },
    {
      "code": "DEALER-DISPLAY-08",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-08.jpg"
    },
    {
      "code": "DEALER-DISPLAY-09",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-09.jpg"
    },
    {
      "code": "DEALER-DISPLAY-10",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-10.jpg"
    },
    {
      "code": "DEALER-DISPLAY-11",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-11.jpg"
    },
    {
      "code": "DEALER-DISPLAY-12",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-12.jpg"
    },
    {
      "code": "DEALER-DISPLAY-13",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-13.jpg"
    },
    {
      "code": "DEALER-DISPLAY-14",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-14.jpg"
    },
    {
      "code": "DEALER-DISPLAY-15",
      "src": "/Images/catalog/real-projects/DEALER-DISPLAY-15.jpg"
    }
  ]
}
