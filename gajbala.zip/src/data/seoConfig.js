// Central SEO/site constants — keep in sync with the real production domain,
// business details and social profiles so every page's meta tags and
// structured data agree with each other.
export const SITE_URL = 'https://gajbala.vercel.app'
export const SITE_NAME = 'GajBala Group'
export const SITE_DEFAULT_DESCRIPTION = 'GajBala Group manufactures and exports ultra-thin flexible natural stone veneer and premium architectural surfaces from Jaipur, India.'
export const DEFAULT_OG_IMAGE = '/Images/pdf-assets/flexible-sheets.jpg'
export const DEFAULT_OG_IMAGE_ALT = 'GajBala Group flexible stone veneer collections and natural stone surfaces'
export const TWITTER_HANDLE = '@gajbala_group'

export const ORGANIZATION = {
  legalName: 'GajBala Universe Pvt Ltd',
  brandName: 'GajBala Group',
  url: SITE_URL,
  logo: `${SITE_URL}/Images/logo-icon.png`,
  telephone: '+91-81406-79999',
  email: 'office@gajbalagroup.com',
  addressLocality: 'Jaipur',
  addressRegion: 'Rajasthan',
  addressCountry: 'IN',
  sameAs: [
    'https://www.linkedin.com/company/gajbala-group/',
    'https://facebook.com/gajbalagroup',
    'https://www.instagram.com/gajbala_group',
  ],
}
