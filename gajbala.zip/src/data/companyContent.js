/**
 * Official company & product messaging derived from GajBala Group Introduction PDF.
 * Used across homepage sections and informational pages.
 * Product SKUs / catalog images live elsewhere and must not be changed here.
 */

export const company = {
  name: 'GajBala Group',
  legalName: 'GajBala Universe Pvt Ltd',
  division: 'Global Export Division',
  tagline: 'Delivering flawless performance through operational excellence',
  industryTagline: 'Opening the Future of the Global E-Ston Industry',
  brandStrip: ['Go Global', 'Go Green', 'Go Gajbala'],
  chairman: {
    name: 'Mr. Shyam Somani',
    title: 'Chairman, GajBala Group',
    vision:
      "GajBala Group is led by Mr. Shyam Somani, whose vision is to develop India's quality E-Ston products and supply them to the world with a mission — Reaching Everywhere.",
    image: '/Images/pdf-assets/chairman-somani.jpg',
  },
  contact: {
    phone: '+91 81406 79999',
    phoneTel: '+918140679999',
    email: 'office@gajbalagroup.com',
    website: 'www.gajbalagroup.com',
    websiteUrl: 'https://www.gajbalagroup.com',
  },
  enquiryAudiences: [
    'Importers',
    'Distributors',
    'Architects & Builders',
    'Project Developers',
    'Technology Collaboration',
  ],
}

export const purpose = {
  title: 'Our Purpose',
  statement:
    "To Build the World's Most Open, Innovative and Collaborative E-Ston Industry Ecosystem",
}

export const goals = [
  {
    title: 'Open Innovation',
    desc: 'Continuous research and new ideas.',
  },
  {
    title: 'Open Industry',
    desc: 'Empowering the entire E-Ston ecosystem.',
  },
  {
    title: 'Open Opportunities',
    desc: 'For partners, dealers, architects and builders worldwide.',
  },
  {
    title: 'Open for Everyone',
    desc: 'Building an inclusive ecosystem — open future, sustainable solutions for tomorrow.',
  },
]

export const openPillars = [
  {
    title: 'Open Innovation',
    desc: 'Continuous research and new ideas.',
  },
  {
    title: 'Open Industry',
    desc: 'Empowering the entire E-Ston ecosystem.',
  },
  {
    title: 'Open Opportunities',
    desc: 'For partners, dealers, architects and builders worldwide.',
  },
  {
    title: 'Open Future',
    desc: 'Sustainable solutions for tomorrow.',
  },
]

export const aboutIntro = {
  headline: 'Delivering flawless performance through operational excellence',
  paragraphs: [
    'Over the years, our unrivalled product quality, flawless execution and honest customer service have brought delight after delight to our customers and their projects.',
    'GajBala Group\'s state-of-the-art manufacturing plant is a dedicated area for each stage of the process, reflecting the utmost importance we assign to each step. The plant is equipped with superior machinery, skilled manpower, and clearly defined systems and processes, all of which enhance the capability of producing customer orders with different designs, types, colours and finish of stones.',
    'We pride ourselves on our unmatched quality and craftsmanship, but we also know there are so many more miles to go before we rest.',
  ],
}

export const partnerReasons = [
  {
    title: 'An Industry, Not Just a Product',
    desc: "We think beyond flexible stone veneers. We believe it's not just a product but an industry in itself.",
    image: '/Images/stock/factory-aerial.jpg',
  },
  {
    title: 'Continuous R&D',
    desc: 'Continuous investment in R&D to develop cutting-edge stone technologies and manufacturing processes.',
    image: '/Images/stock/lab-research.jpg',
  },
  {
    title: 'International Quality',
    desc: 'Adhering to international quality benchmarks and compliance standards for global market leadership.',
    image: '/Images/stock/airplane-global.jpg',
  },
  {
    title: 'Transparent Partnerships',
    desc: 'Transparent business practices, ethical sourcing, and honest relationships with clients and partners.',
    image: '/Images/stock/handshake.jpg',
  },
  {
    title: 'Factory Visits Welcome',
    desc: 'Buyers are welcome for factory visits — we encourage visits so you can see our operations first-hand.',
    image: '/Images/stock/shipping-containers.jpg',
  },
  {
    title: 'After-Sales & Installation Support',
    desc: 'Complete after-sales support and installation support for every partnership.',
    image: '/Images/stock/team-collaboration.jpg',
  },
]

export const estonProduct = {
  name: 'E-STONOERA',
  tagline: 'Opening the Future of the Global E-Ston Industry',
  description:
    'Crafted by extracting ultra-thin layers from authentic natural stone, our flexible stone veneer sheets are reinforced with a fiberglass-polymer resin backing. This innovative technology delivers the timeless elegance of real slate, quartzite, or marble with exceptional flexibility, ultra-lightweight handling, complete water resistance, and effortless curved-surface application.',
  features: [
    {
      title: 'Lightweight',
      desc: 'Easy to handle, transport and install.',
    },
    {
      title: 'Flexible',
      desc: 'Can be bent in concave, convex, arched or radial forms.',
    },
    {
      title: 'Weather-Resistant',
      desc: 'Withstands extreme heat and cold.',
    },
    {
      title: 'Easy Application',
      desc: 'Ideal for both internal and external surfaces.',
    },
  ],
}

export const productAdvantages = [
  {
    title: 'Lightweight Material',
    desc: 'Ultra-thin natural stone veneer that is easy to handle, transport and install.',
  },
  {
    title: 'Flexible Surface',
    desc: 'Can be bent in concave, convex, arched or radial forms.',
  },
  {
    title: 'Up to 80% Lighter',
    desc: 'Up to 80% lighter than traditional stone slabs while retaining authentic stone beauty.',
  },
  {
    title: 'Easy Installation',
    desc: 'Simple application that reduces construction time and labour cost.',
  },
  {
    title: 'Cost-Efficient Shipping',
    desc: 'Lightweight sheets enable efficient shipping and lower freight costs.',
  },
  {
    title: 'Faster Construction',
    desc: 'Reduces construction time and labour cost on site.',
  },
  {
    title: 'Natural Stone Beauty',
    desc: 'Real natural stone surface with genuine grain, colour and character.',
  },
  {
    title: 'Authentic Stone Texture',
    desc: 'Natural graininess and textural irregularities enhance every veneer.',
  },
  {
    title: 'Curved Surfaces',
    desc: 'Suitable for curved, arched and radial architectural applications.',
  },
]

export const applicationSurfaces = [
  'Architectural',
  'Interior & Exterior',
  'Furniture',
  'Doors & Cabinets',
  'Signage',
  'Marine & RV',
  'Trim & Backsplashes',
  'Kitchen & Bathrooms',
]

export const productProperties = [
  {
    title: 'Look & Finish',
    desc: 'The natural graininess and textural irregularities of stone further enhance the beauty of these thin, flexible veneers.',
  },
  {
    title: 'Heat & Temperature Resistance',
    desc: 'Endures extremes of climate — withstands extreme heat and cold.',
  },
  {
    title: 'Curvature & Bending',
    desc: 'Can be bent in concave, convex, arched or radial forms, depending on the nature of the curve.',
  },
]

export const backingInfo = {
  finishes: ['Fiber glass', 'Fabric', 'Cellulose backing'],
  substrates: [
    'MDF',
    'HDF boards',
    'Styrofoam sheets',
    'Melamine board',
    'Concrete',
    'Brick',
    'Concrete blocks and slabs',
    'Mortar-plastered walls',
    'Drywall',
    'Plywood',
    'Acrylic and other plastic sheets',
  ],
}

export const collectionBlurbs = {
  slatera:
    'A thin layer of authentic slate applied over another surface creates the illusion of a stunning, thick slate slab — a cost-effective way to charm spaces on a budget. Available in a variety of sizes and relatively simple to cut, this easy-to-install thin stone veneer shares slate’s striking beauty and unmatched durability.',
  sandera:
    'Genuine sandstone surfaces with a solid backing, created with a natural colour palette and the magical ability to produce unpredictable peel effects. Each stone is distinctive, oddly enchanting, and eccentric — ideal for interactive interior design.',
  onyxoera:
    'Translucent stone in stunning colours delivers the inherent aesthetic appeal and texture of genuine stone, with the added wonder of translucency. Flexible enough for curved or flat surfaces.',
}

export const installationSteps = [
  {
    title: 'Surface Preparation',
    points: [
      'Ensure the substrate (plywood, MDF, HDHMR, plastered brick/block, drywall, or concrete) is clean, flat, completely dry, and dust-free.',
      'Apply a suitable bonding primer on porous or powdery surfaces before installation.',
    ],
  },
  {
    title: 'Dry Fitting & Marking',
    points: [
      'Lay out sheets on a flat surface to check natural colour variations, patterns, and alignment.',
      'Measure the target area and mark cut lines on the back of the veneer sheets with a pencil or marker.',
    ],
  },
  {
    title: 'Cutting & Sizing',
    points: [
      'Cut the stone veneer from the back (fiberglass/resin side) using shears, a jigsaw, or a circular saw.',
      'Sand the cut edges lightly with medium-grit sandpaper to remove any burrs or rough fiberglass strands.',
    ],
  },
  {
    title: 'Placing & Rolling',
    points: [
      'Position the sheet against the wall starting from one edge to prevent air entrapment.',
      'Use a rubber hand roller to press firmly across the entire sheet, working from the center outward to ensure complete adhesive contact.',
      'Secure edges temporarily with masking tape if working on vertical drops or curved sections until the initial grab sets.',
    ],
  },
  {
    title: 'Joint Treatment (Optional)',
    points: [
      'Seamless / Butt Joint: Butt edges tightly against each other; wipe away any excess squeezed adhesive immediately using mineral spirits or solvent wipes.',
      'Grout Joint: Leave a 2–3 mm gap between sheets and fill with matching flexible silicone or polyurethane tile grout.',
    ],
  },
  {
    title: 'Sealing & Protection',
    points: [
      'Allow adhesive to cure completely (typically 12–24 hours based on manufacturer specifications).',
      'Apply 1–2 coats of penetrating stone sealer to protect the natural stone surface from moisture, stains, and UV degradation — especially critical for wet areas or exterior claddings.',
    ],
  },
]

export const heroHighlights = [
  { value: '80%', label: 'Lighter than stone slabs' },
  { value: '1–3mm', label: 'Ultra-thin veneer' },
  { value: 'Flexible', label: 'Curves & arches' },
  { value: 'Indoor+', label: 'Exterior ready' },
]
