import { lazy } from 'react'
import { Routes, Route } from 'react-router-dom'
import Layout from './components/layout/Layout'
import Home from './pages/Home'
import ScrollToTop from './components/ScrollToTop'

// Route-level code splitting: Home ships in the main bundle (first paint),
// every other page loads on demand so a visitor never downloads the whole
// site's JS just to view one page.
const About = lazy(() => import('./pages/About'))
const Products = lazy(() => import('./pages/Products'))
const ProductDetail = lazy(() => import('./pages/ProductDetail'))
const Applications = lazy(() => import('./pages/Applications'))
const ApplicationDetail = lazy(() => import('./pages/ApplicationDetail'))
const Contact = lazy(() => import('./pages/Contact'))
const ManufacturingPage = lazy(() => import('./pages/Manufacturing'))
const SustainabilityPage = lazy(() => import('./pages/Sustainability'))
const EstonEra = lazy(() => import('./pages/EstonEra'))
const Partner = lazy(() => import('./pages/Partner'))
const Marmomac = lazy(() => import('./pages/Marmomac'))

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/products" element={<Products />} />
          <Route path="/products/:collection" element={<Products />} />
          <Route path="/products/:collection/:code" element={<ProductDetail />} />
          <Route path="/applications" element={<Applications />} />
          <Route path="/applications/:slug" element={<ApplicationDetail />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/manufacturing" element={<ManufacturingPage />} />
          <Route path="/sustainability" element={<SustainabilityPage />} />
          <Route path="/eston-era" element={<EstonEra />} />
          <Route path="/partner" element={<Partner />} />
          <Route path="/marmomac" element={<Marmomac />} />
        </Route>
      </Routes>
    </>
  )
}
