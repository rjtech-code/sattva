import { useMotionValue, useSpring, useTransform } from 'framer-motion'

/**
 * Adds a subtle 3D tilt + glare-ready pointer position, driven by pointer
 * coordinates relative to an element you own (pass its DOM node into
 * `onMouseMove`). Spread `rotateX`/`rotateY` into a motion.div's `style`.
 */
export default function useTilt(strength = 8) {
  const x = useMotionValue(0)
  const y = useMotionValue(0)

  const springConfig = { stiffness: 220, damping: 22, mass: 0.4 }
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [strength, -strength]), springConfig)
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-strength, strength]), springConfig)
  const glareX = useTransform(x, [-0.5, 0.5], ['0%', '100%'])
  const glareY = useTransform(y, [-0.5, 0.5], ['0%', '100%'])

  const onMouseMove = (e, el) => {
    if (!el) return
    const rect = el.getBoundingClientRect()
    x.set((e.clientX - rect.left) / rect.width - 0.5)
    y.set((e.clientY - rect.top) / rect.height - 0.5)
  }

  const onMouseLeave = () => {
    x.set(0)
    y.set(0)
  }

  return { onMouseMove, onMouseLeave, rotateX, rotateY, glareX, glareY }
}
