import { useState, useEffect, useRef } from 'react'

export default function useCounter(end, duration = 2000, startOnView = true) {
  const [count, setCount] = useState(0)
  // When we don't need to wait for the element to scroll into view, start
  // already-true from the initial render instead of flipping it via an effect.
  const [started, setStarted] = useState(() => !startOnView)
  const ref = useRef(null)

  useEffect(() => {
    if (!startOnView) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true)
          observer.disconnect()
        }
      },
      { threshold: 0.3 }
    )

    if (ref.current) observer.observe(ref.current)

    return () => observer.disconnect()
  }, [startOnView])

  useEffect(() => {
    if (!started) return

    let startTimestamp = null
    const step = (timestamp) => {
      if (!startTimestamp) startTimestamp = timestamp
      const progress = Math.min((timestamp - startTimestamp) / duration, 1)
      // Ease out cubic for smooth deceleration
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.floor(eased * end))
      if (progress < 1) {
        requestAnimationFrame(step)
      }
    }
    requestAnimationFrame(step)
  }, [started, end, duration])

  return { count, ref }
}