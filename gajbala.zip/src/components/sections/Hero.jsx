import { useRef } from 'react'
import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { FiChevronRight, FiArrowUpRight } from 'react-icons/fi'
import { BsMouse } from 'react-icons/bs'
import LuxuryButton from '../ui/LuxuryButton'
import { company, heroHighlights } from '../../data/companyContent'

const headlineLine = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.05 } },
}

const headlineChar = {
  hidden: { y: '110%' },
  visible: { y: '0%', transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
}

function RevealWord({ text, className = '', delayStart = 0 }) {
  return (
    <span className="inline-block overflow-hidden align-bottom">
      <motion.span
        variants={headlineLine}
        initial="hidden"
        animate="visible"
        transition={{ delayChildren: delayStart }}
        className={`inline-block ${className}`}
      >
        {text.split('').map((ch, i) => (
          <motion.span key={i} variants={headlineChar} className="inline-block">
            {ch === ' ' ? '\u00A0' : ch}
          </motion.span>
        ))}
      </motion.span>
    </span>
  )
}

export default function Hero() {
  const sectionRef = useRef(null)
  const navigate = useNavigate()

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen overflow-hidden bg-primary-dark"
      aria-label="Hero section"
    >
      <video
        aria-hidden="true"
        className="absolute inset-0 w-full h-full object-cover"
        autoPlay
        muted
        loop
        playsInline
        preload="metadata"
        poster="/Images/drive/app5.jpg"
      >
        <source src="/hero-bg-video.mp4" type="video/mp4" />
      </video>

      {/* Single full-bleed scrim — soft left-to-right fade, no hard center seam */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'linear-gradient(90deg, rgba(15, 40, 18, 0.88) 0%, rgba(15, 40, 18, 0.72) 38%, rgba(15, 40, 18, 0.35) 62%, rgba(15, 40, 18, 0.18) 100%)',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-primary-dark/50 via-transparent to-primary-dark/25 pointer-events-none" />
      <div className="marble-texture absolute inset-0 opacity-20 pointer-events-none" />

      <div className="relative z-10 min-h-screen flex flex-col justify-center pt-20 pb-6 sm:pt-28 sm:pb-24 lg:pt-32 lg:pb-28 px-6 sm:px-10 lg:px-16 xl:px-20">
        <div className="max-w-xl">
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="flex items-center gap-3 mb-4 sm:mb-8"
          >
            <span className="w-8 h-px bg-primary-light" />
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-accent" />
            </span>
            <span className="text-primary-light text-xs font-semibold tracking-[0.25em] uppercase">
              Flexible Stone Veneer · India
            </span>
          </motion.div>

          <h1 className="font-heading text-white text-[13vw] sm:text-6xl lg:text-7xl xl:text-[5.2rem] font-semibold leading-[0.98] tracking-tight mb-4 sm:mb-8">
            <RevealWord text="GajBala" delayStart={0.3} />
            <br />
            <RevealWord text="Group" className="italic text-primary-light" delayStart={0.42} />
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="text-white/65 text-base sm:text-lg leading-relaxed mb-6 sm:mb-4 max-w-md"
          >
            {company.industryTagline}
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.88 }}
            className="hidden sm:block text-white/55 text-sm sm:text-base leading-relaxed mb-10 max-w-md"
          >
            Ultra-thin flexible stone veneer — real slate, quartzite and marble beauty with lightweight handling,
            water resistance, and effortless curved-surface application.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.95 }}
            className="flex flex-wrap gap-3 sm:gap-4 mb-6 sm:mb-14"
          >
            <LuxuryButton variant="primary" onClick={() => navigate('/products')}>
              Explore Collection
              <FiChevronRight />
            </LuxuryButton>
            <LuxuryButton variant="secondary" onClick={() => navigate('/partner')}>
              Partner With Us
            </LuxuryButton>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1.15 }}
            className="lg:hidden flex flex-wrap gap-x-6 gap-y-3 sm:gap-x-8 sm:gap-y-5 pt-4 sm:pt-8 border-t border-white/10"
          >
            {heroHighlights.map((stat) => (
              <div key={stat.label}>
                <div className="font-heading text-xl sm:text-2xl font-semibold text-white">
                  {stat.value}
                </div>
                <div className="text-white/45 text-[10px] sm:text-[11px] uppercase tracking-widest mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Desktop-only right showcase panel — tagline card + stats grid, replaces the mobile inline stats row */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 1.1 }}
        className="hidden lg:flex lg:flex-col gap-5 absolute right-6 xl:right-16 top-1/2 -translate-y-1/2 z-20 w-[270px] xl:w-[320px]"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          className="bg-white rounded-[20px] shadow-2xl shadow-black/25 p-7"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-semibold uppercase tracking-widest text-primary">
              E-Ston Era
            </span>
            <FiArrowUpRight className="text-primary" />
          </div>
          <p className="font-heading text-xl font-semibold text-dark leading-snug">
            {company.tagline}
          </p>
        </motion.div>

        <div className="grid grid-cols-2 gap-px bg-white/15 rounded-[20px] overflow-hidden border border-white/15 backdrop-blur-xl">
          {heroHighlights.map((stat) => (
            <div key={stat.label} className="bg-white/5 p-5">
              <div className="font-heading text-2xl xl:text-3xl font-semibold text-white">
                {stat.value}
              </div>
              <div className="text-white/50 text-[10px] uppercase tracking-widest mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-8 left-6 sm:left-10 lg:left-16 xl:left-20 z-30 flex items-center gap-3"
      >
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        >
          <BsMouse className="text-white/40 text-xl" />
        </motion.div>
        <span className="text-white/40 text-[11px] font-medium tracking-[0.2em] uppercase">
          Scroll to explore
        </span>
      </motion.div>
    </section>
  )
}
