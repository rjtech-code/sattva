import { motion, AnimatePresence } from 'framer-motion'
import { useEffect, useState } from 'react'
import { FiArrowLeft, FiArrowRight } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'
import TiltCard from '../ui/TiltCard'
import { productCatalog } from '../../data/productCatalog'
import { collectionsInfo } from '../../data/collectionsInfo'

// Kept in sync with the collection tiles on the Products page.
const categoryKeys = ['flexoera', 'onyxoera', 'decoera', 'artoera', 'walloera', 'designoera', 'rockoera']

export default function OurBusinesses() {
  const navigate = useNavigate()
  const [activeIndex, setActiveIndex] = useState(0)
  const [isPaused, setIsPaused] = useState(false)

  const moveSlider = (direction) => {
    setActiveIndex((current) => (current + direction + categoryKeys.length) % categoryKeys.length)
  }

  useEffect(() => {
    if (isPaused) return undefined

    const intervalId = window.setInterval(() => moveSlider(1), 3500)
    return () => window.clearInterval(intervalId)
  }, [isPaused])

  const getOffset = (index) => {
    let offset = index - activeIndex
    const midpoint = categoryKeys.length / 2
    if (offset > midpoint) offset -= categoryKeys.length
    if (offset < -midpoint) offset += categoryKeys.length
    return offset
  }

  return (
    <section id="businesses" className="section-padding bg-white">
      <div className="container-luxury max-w-[1400px]">
        <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="section-subtitle"
          >
            Product Categories
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-title mb-4"
          >
            Our Product Categories
          </motion.h2>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="green-divider mx-auto"
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="text-light text-base sm:text-lg mt-6"
          >
            Ultra-thin stone veneers that elevate the design and aesthetics of any surface and space
          </motion.p>
        </div>

        <div
          className="relative max-w-6xl mx-auto"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onFocus={() => setIsPaused(true)}
          onBlur={() => setIsPaused(false)}
        >
          <div className="relative h-[460px] sm:h-[500px] lg:h-[540px] overflow-hidden [perspective:1400px]">
            <AnimatePresence initial={false}>
              {categoryKeys.map((key) => {
            const info = collectionsInfo[key]
            const thumb = productCatalog[key]?.[0]?.src
            if (!info || !thumb) return null
            const offset = getOffset(categoryKeys.indexOf(key))
            const isActive = offset === 0
            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, scale: 0.7 }}
                animate={{
                  opacity: Math.abs(offset) > 2 ? 0 : isActive ? 1 : 0.5,
                  scale: isActive ? 1 : Math.abs(offset) === 1 ? 0.82 : 0.68,
                  rotateY: offset * -22,
                  rotateZ: offset * (isActive ? 0 : 2.5),
                  y: isActive ? 0 : 22,
                  left: `calc(50% - min(39vw, 195px) + ${offset * 28}%)`,
                }}
                transition={{ duration: 1.15, ease: [0.22, 0.61, 0.36, 1] }}
                drag={isActive ? 'x' : false}
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={0.12}
                onDragEnd={(_, info) => {
                  if (info.offset.x < -45) moveSlider(1)
                  if (info.offset.x > 45) moveSlider(-1)
                }}
                className={`absolute top-4 w-[78vw] max-w-[390px] transform-gpu ${
                  Math.abs(offset) > 2 ? 'pointer-events-none' : 'cursor-pointer'
                }`}
                style={{
                  zIndex: 10 - Math.abs(offset),
                }}
                onClick={() => isActive && navigate('/products')}
              >
                <TiltCard
                  strength={isActive ? 8 : 3}
                  className={`premium-card overflow-hidden flex flex-col border transition-shadow duration-500 ${
                    isActive
                      ? 'border-primary/40 shadow-2xl shadow-primary/20'
                      : 'border-primary/10 shadow-lg shadow-primary/5'
                  }`}
                >
                  <div className="sweep" />
                  <div className="premium-card-glow" />

                  <div className="relative aspect-[4/3] image-zoom overflow-hidden bg-primary/5">
                    <img
                      src={thumb}
                      alt={`${info.title} - GajBala Group ${info.tagline}`}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>

                  <div className="relative z-10 p-5 sm:p-6 text-center bg-white">
                    <h3 className="premium-card-title font-heading text-xl sm:text-2xl font-bold">
                      {info.title}
                    </h3>
                    <p className="text-light text-xs sm:text-sm mt-2">{info.tagline}</p>
                  </div>
                </TiltCard>
              </motion.div>
            )
              })}
            </AnimatePresence>
          </div>

          <div className="absolute left-1/2 bottom-2 z-20 flex -translate-x-1/2 items-center gap-3">
            <button
              type="button"
              onClick={() => moveSlider(-1)}
              aria-label="Previous product category"
              title="Previous category"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-primary/30 bg-white text-primary shadow-lg transition-all hover:bg-primary hover:text-white"
            >
              <FiArrowLeft />
            </button>
            <span className="min-w-16 text-center text-xs font-semibold tracking-[0.2em] text-primary">
              {String(activeIndex + 1).padStart(2, '0')} / {String(categoryKeys.length).padStart(2, '0')}
            </span>
            <button
              type="button"
              onClick={() => moveSlider(1)}
              aria-label="Next product category"
              title="Next category"
              className="flex h-11 w-11 items-center justify-center rounded-full border border-primary/30 bg-white text-primary shadow-lg transition-all hover:bg-primary hover:text-white"
            >
              <FiArrowRight />
            </button>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-12"
        >
          <LuxuryButton
            variant="outline"
            icon={FiArrowRight}
            onClick={() => navigate('/products')}
          >
            Explore Full Collection
          </LuxuryButton>
        </motion.div>
      </div>
    </section>
  )
}
