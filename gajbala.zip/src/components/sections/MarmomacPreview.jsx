import { motion } from 'framer-motion'
import { FiCalendar, FiMapPin, FiArrowRight } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'
import TiltCard from '../ui/TiltCard'

const PREVIEW_IMAGE = '/Images/marmomac/india-italy-marmomac-banner.png'

export default function MarmomacPreview() {
  const navigate = useNavigate()

  return (
    <section className="section-padding bg-white relative overflow-hidden">
      <div className="container-luxury max-w-[1400px]">
        <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 lg:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <span className="section-subtitle">India &middot; Italy</span>
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-dark leading-tight mb-4">
              GajBala Group at Marmomac Verona 2026
            </h2>
            <div className="green-divider mb-6" />
            <p className="text-light text-base sm:text-lg leading-relaxed mb-8">
              Join us at the world's leading natural stone exhibition — Verona, Italy —
              as we bring India's quality E-Ston products to a global stage.
            </p>

            <div className="flex flex-wrap items-center gap-6 text-sm text-light mb-8">
              <span className="flex items-center gap-2"><FiCalendar className="text-primary" /> September 22&ndash;25, 2026</span>
              <span className="flex items-center gap-2"><FiMapPin className="text-primary" /> Verona, Italy</span>
            </div>

            <LuxuryButton variant="primary" icon={FiArrowRight} onClick={() => navigate('/marmomac')}>
              Learn More
            </LuxuryButton>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <TiltCard strength={5} glare={false} className="image-zoom aspect-[2/1] rounded-[20px] shadow-xl shadow-black/10">
              <img
                src={PREVIEW_IMAGE}
                alt="GajBala Group at Marmomac Verona 2026"
                className="w-full h-full object-contain rounded-[20px]"
                loading="lazy"
              />
            </TiltCard>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
