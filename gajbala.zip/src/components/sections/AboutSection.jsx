import { motion } from "framer-motion";
import { FiArrowRight, FiUsers, FiGlobe } from "react-icons/fi";
import { FaLeaf } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import LuxuryButton from "../ui/LuxuryButton";
import TiltCard from "../ui/TiltCard";
import { aboutIntro, purpose, openPillars } from "../../data/companyContent";

const highlightCards = [
  {
    icon: FaLeaf,
    title: "Go Green",
    desc: "Sustainable solutions for tomorrow",
    delay: 0.2,
  },
  {
    icon: FiGlobe,
    title: "Go Global",
    desc: "India’s quality E-Ston to the world",
    delay: 0.3,
  },
];

export default function AboutSection() {
  const navigate = useNavigate();

  return (
    <section id="about" className="relative py-24 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-white" />
      <div
        className="absolute inset-0 opacity-[0.02]"
        style={{
          backgroundImage: `radial-gradient(circle at 30% 50%, #1B5E20 0%, transparent 50%)`,
        }}
      />

      <div className="relative z-10">
        <div className="text-center max-w-4xl mx-auto px-6 mb-16 lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="inline-block text-xs font-semibold tracking-[0.3em] uppercase text-primary mb-6"
          >
            Who We Are
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-playfair text-3xl md:text-4xl font-bold text-dark leading-tight mb-4"
          >
            {aboutIntro.headline}
          </motion.h2>
        </div>

        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 mb-8 lg:mb-20">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="lg:col-span-7"
            >
              <div className="relative bg-white rounded-[24px] p-8 md:p-12 shadow-xl shadow-black/5 border border-gray-100">
                <div className="relative z-10">
                  <p className="text-base md:text-lg text-light leading-relaxed mb-8">
                    Gajbala Group is an organization dedicated to developing
                    India’s top-quality E-Ston products and supplying them
                    globally, driven by a core mission of "Reaching Everywhere".
                    The organization is focused on building the world’s most
                    open, innovative, and collaborative E-Ston Industry
                    Ecosystem to empower partners, dealers, architects, and
                    builders worldwide.
                  </p>

                  <div className="rounded-[16px] bg-primary/5 border border-primary/10 p-5 mb-8">
                    <p className="text-xs font-semibold tracking-[0.2em] uppercase text-primary mb-2">
                      {purpose.title}
                    </p>
                    <p className="font-heading text-lg md:text-xl font-semibold text-dark leading-snug">
                      {purpose.statement}
                    </p>
                  </div>

                  <LuxuryButton
                    variant="primary"
                    icon={FiArrowRight}
                    onClick={() => navigate("/about")}
                  >
                    Learn More About Us
                  </LuxuryButton>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="lg:col-span-5"
            >
              <div className="grid grid-cols-2 gap-4 lg:gap-5">
                {highlightCards.map((card) => (
                  <TiltCard
                    key={card.title}
                    strength={9}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: card.delay }}
                    whileHover={{
                      y: -8,
                      scale: 1.02,
                      transition: {
                        duration: 0.7,
                        ease: [0.22, 0.61, 0.36, 1],
                      },
                    }}
                    className="premium-card p-6 lg:p-8 cursor-pointer"
                  >
                    <div className="sweep" />
                    <div className="premium-card-glow" />

                    <div className="relative z-10 h-full flex flex-col justify-between">
                      <div>
                        <div className="premium-card-icon w-12 h-12 rounded-xl bg-[#7A7A7A]/10 flex items-center justify-center mb-4">
                          <card.icon
                            className="text-xl"
                            style={{ color: "#6B7280" }}
                          />
                        </div>
                      </div>

                      <div>
                        <h4 className="premium-card-title font-heading text-base lg:text-lg font-bold mb-2">
                          {card.title}
                        </h4>
                        <p className="premium-card-description text-xs lg:text-sm leading-relaxed">
                          {card.desc}
                        </p>
                      </div>
                    </div>
                  </TiltCard>
                ))}
              </div>
            </motion.div>
          </div>

          <div className="border-t border-b border-gray-200 py-6 md:py-12 lg:py-16">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
              {openPillars.map((pillar, index) => (
                <motion.div
                  key={pillar.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.1 * (index + 1) }}
                  className="group text-center lg:text-left"
                >
                  <div className="flex flex-col lg:flex-row items-center gap-4">
                    <div className="premium-card-icon w-12 h-12 rounded-full bg-[#7A7A7A]/10 flex items-center justify-center flex-shrink-0">
                      <FiUsers
                        className="text-lg"
                        style={{ color: "#6B7280" }}
                      />
                    </div>
                    <div>
                      <h4 className="font-heading text-base font-bold text-dark mb-1">
                        {pillar.title}
                      </h4>
                      <p className="text-sm text-light">{pillar.desc}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
