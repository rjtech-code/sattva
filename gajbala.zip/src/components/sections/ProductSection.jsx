import { lazy, Suspense, useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { FiArrowUpRight, FiArrowRight, FiLayers, FiRefreshCw, FiDroplet, FiZap } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'
import TiltCard from '../ui/TiltCard'

// three.js + @react-three/fiber are a heavy dependency (~200KB+) — load them
// only when this section actually needs the 3D viewer, not in the main/Home
// bundle every visitor downloads up front.
const StoneSlab3D = lazy(() => import('../three/StoneSlab3D'))

const surfaceCards = [
  { title: 'Architectural', image: '/Images/catalog/slatera/ERA-SL-101-11.jpg' },
  { title: 'Interior & Exterior', image: '/Images/catalog/sandera/ERA-SD-101-2.jpg' },
  { title: 'Furniture', image: '/Images/catalog/bookmatch/ERA-BM-207.jpg' },
  { title: 'Doors & Cabinets', image: '/Images/catalog/jumboera/BOOKMATCH-JUMBOERA-074.jpg' },
  { title: 'Signage', image: '/Images/catalog/flexartoera/FAB-711044.jpg' },
  { title: 'Marine & RV', image: '/Images/catalog/rockoera-louver/OFF-WHITE-LOUVER.jpg' },
  { title: 'Trim & Backsplashes', image: '/Images/catalog/rockoera-decor/SQUARE-GREY.jpg' },
  { title: 'Kitchen & Bathrooms', image: '/Images/catalog/slate-translucent/BISTER.jpg' },
]

const highlights = [
  { icon: FiLayers, text: 'Real natural stone, sliced ultra-thin' },
  { icon: FiRefreshCw, text: 'Flexes around curves, corners & columns' },
  { icon: FiDroplet, text: 'Water and weather resistant' },
  { icon: FiZap, text: 'Lightweight — fast, low-cost installation' },
]

// Cycles through the surface names in the sentence below the 3D viewer
function CyclingWord({ words }) {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    const id = setInterval(() => setIndex((i) => (i + 1) % words.length), 1800)
    return () => clearInterval(id)
  }, [words.length])

  return (
    <span className="relative inline-block h-[1.3em] min-w-[10ch] overflow-hidden align-bottom text-left">
      <AnimatePresence mode="wait">
        <motion.span
          key={words[index]}
          initial={{ y: '100%', opacity: 0 }}
          animate={{ y: '0%', opacity: 1 }}
          exit={{ y: '-100%', opacity: 0 }}
          transition={{ duration: 0.45, ease: [0.22, 0.61, 0.36, 1] }}
          className="absolute left-0 top-0 whitespace-nowrap text-primary"
        >
          {words[index]}
        </motion.span>
      </AnimatePresence>
    </span>
  )
}

export default function ProductSection() {
  const navigate = useNavigate()

  const scrollCarousel = (direction) => {
    const container = document.querySelector('[data-surface-carousel]')
    if (!container) return

    const firstCard = container.querySelector('[data-surface-card]')
    if (!firstCard) return

    const gap = 24
    const scrollAmount = firstCard.getBoundingClientRect().width + gap
    container.scrollBy({ left: direction * scrollAmount, behavior: 'smooth' })
  }

  return (
    <section id="products" className="section-padding bg-bg relative overflow-hidden">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-primary/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

      <div className="container-luxury max-w-[1400px] relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="section-subtitle"
          >
            Applications
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-title mb-4"
          >
            Surfaces Built for Every Space
          </motion.h2>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="green-divider mx-auto"
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="text-light text-base sm:text-lg mt-6"
          >
            Ultra-thin slate stone veneer can be fixed to many indoor and outdoor surfaces
          </motion.p>
        </div>

        {/* Interactive 3D showcase + highlights */}
        <div className="grid lg:grid-cols-5 gap-8 lg:gap-14 items-center mb-16 lg:mb-24">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="lg:col-span-3"
          >
            <Suspense fallback={<div className="h-[320px] sm:h-[400px] lg:h-[460px] rounded-[20px] bg-[#f4f2ee]" />}>
              <StoneSlab3D
                image="/Images/drive/bookmatch-slab-showcase.jpg"
                className="h-[320px] sm:h-[400px] lg:h-[460px] shadow-xl shadow-black/10"
              />
            </Suspense>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="lg:col-span-2"
          >
            <p className="font-heading text-2xl sm:text-3xl font-bold text-dark leading-snug mb-8">
              Built for <CyclingWord words={surfaceCards.map((s) => s.title)} />
            </p>

            <ul className="space-y-4 mb-8">
              {highlights.map((h) => (
                <motion.li
                  key={h.text}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                  className="flex items-center gap-3"
                >
                  <span className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <h.icon className="text-primary text-base" />
                  </span>
                  <span className="text-sm sm:text-base text-dark/80">{h.text}</span>
                </motion.li>
              ))}
            </ul>

            <LuxuryButton variant="outline" icon={FiArrowUpRight} onClick={() => navigate('/products')}>
              Explore in 3D
            </LuxuryButton>
          </motion.div>
        </div>

        {/* Surface cards carousel */}
        <div className="mb-12">
          <div className="flex items-center justify-end gap-2 mb-6">
            <button
              type="button"
              aria-label="Previous surface card"
              onClick={() => scrollCarousel(-1)}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-primary/20 bg-white text-primary shadow-md transition hover:-translate-y-0.5 hover:border-primary hover:bg-primary hover:text-white"
            >
              ‹
            </button>
            <button
              type="button"
              aria-label="Next surface card"
              onClick={() => scrollCarousel(1)}
              className="flex h-10 w-10 items-center justify-center rounded-full border border-primary/20 bg-white text-primary shadow-md transition hover:-translate-y-0.5 hover:border-primary hover:bg-primary hover:text-white"
            >
              ›
            </button>
          </div>

          <div
            data-surface-carousel
            className="flex gap-6 overflow-x-auto pb-4 scroll-smooth snap-x snap-mandatory cursor-grab active:cursor-grabbing [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden touch-pan-x select-none"
          >
            {surfaceCards.map((surface, i) => (
              <motion.div
                key={surface.title}
                data-surface-card
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: 0.05 * (i + 1), ease: [0.25, 0.46, 0.45, 0.94] }}
                className="group min-w-[260px] md:min-w-[280px] lg:min-w-[290px] snap-center cursor-pointer"
                onClick={() => navigate('/applications')}
              >
                <TiltCard
                  strength={7}
                  whileHover={{ y: -8, scale: 1.02 }}
                  transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                  className="premium-card overflow-hidden text-center h-full flex flex-col"
                >
                  <div className="sweep" />
                  <div className="premium-card-glow" />

                  <div className="relative image-zoom overflow-hidden">
                    <img
                      src={surface.image}
                      alt={`${surface.title} - GajBala Group natural stone applications`}
                      className="w-full object-cover scale-[1.4] h-44"
                      loading="lazy"
                    />
                  </div>

                  <div className="relative z-10 p-6 flex-1 flex flex-col justify-center">
                    <h3 className="premium-card-title font-heading text-lg font-bold mb-2">
                      {surface.title}
                    </h3>
                    <span className="premium-card-description inline-flex items-center justify-center gap-1 text-xs font-semibold uppercase tracking-wider opacity-0 -translate-y-1 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
                      View Applications <FiArrowUpRight />
                    </span>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="text-center mt-12"
        >
          <LuxuryButton
            variant="primary"
            size="lg"
            icon={FiArrowRight}
            onClick={() => navigate('/products')}
          >
            Explore Full Collection
          </LuxuryButton>
        </motion.div>
      </div>
    </section>
  )
}
