import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'
import TiltCard from '../ui/TiltCard'
import { estonProduct, company } from '../../data/companyContent'

export default function EstonPreview() {
  return (
    <section className="section-padding bg-bg relative overflow-hidden">
      <div className="container-luxury max-w-[1200px] mx-auto">
        <div className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="section-subtitle"
            >
              {estonProduct.name}
            </motion.span>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="font-playfair text-3xl md:text-4xl font-bold text-dark leading-tight mb-4"
            >
              {estonProduct.tagline}
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-base md:text-lg text-light leading-relaxed mb-6"
            >
              Real slate, quartzite, or marble — reinforced ultra-thin, lightweight, water-resistant, and effortless to apply on any curve.
            </motion.p>

            <div className="grid grid-cols-2 gap-3 mb-8">
              {estonProduct.features.map((f) => (
                <div
                  key={f.title}
                  className="rounded-[14px] bg-white border border-border p-4"
                >
                  <div className="font-heading text-sm font-bold text-dark mb-1">{f.title}</div>
                  <div className="text-xs text-light leading-relaxed">{f.desc}</div>
                </div>
              ))}
            </div>

            <div className="flex gap-4 flex-wrap">
              <Link to="/eston-era">
                <LuxuryButton variant="primary" size="md">
                  Learn More
                </LuxuryButton>
              </Link>

              <Link to="/contact">
                <LuxuryButton variant="outline" size="md">
                  Contact Us
                </LuxuryButton>
              </Link>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <TiltCard strength={6} glare={false} className="image-zoom rounded-[20px] shadow-xl shadow-black/10">
              <img
                src="/Images/pdf-assets/super-thin-stone-display.png"
                alt={`${company.name} flexible stone veneer sheets`}
                className="w-full aspect-[4/5] max-h-[460px] object-cover rounded-[20px]"
                loading="lazy"
              />
            </TiltCard>
            <div className="absolute -bottom-3 left-4 right-4 md:left-auto md:right-6 md:w-64 bg-white rounded-[14px] shadow-lg p-4 border border-border">
              <p className="text-[10px] uppercase tracking-widest text-primary font-semibold mb-1">
                Brand Promise
              </p>
              <p className="text-sm font-heading font-semibold text-dark leading-snug">
                {company.brandStrip.join(' · ')}
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
