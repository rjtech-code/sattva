import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'

export default function ContactPreview() {
  const navigate = useNavigate()

  return (
    <section className="relative py-20 md:py-24 overflow-hidden">
      {/* Subtle marble texture background */}
      <div className="absolute inset-0 bg-zinc-100" />
      <div className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle at 50% 50%, #1B5E20 0%, transparent 70%)`,
        }}
      />
      
      {/* Soft green gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary-dark/5" />

      <div className="container-luxury max-w-[1400px] relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="max-w-3xl mx-auto text-center"
        >
          {/* Label */}
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="inline-block text-xs font-semibold tracking-[0.3em] uppercase text-primary mb-6"
          >
            Get In Touch
          </motion.span>

          {/* Heading */}
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="font-playfair text-3xl md:text-4xl lg:text-5xl font-bold text-dark leading-tight mb-6"
          >
            Let's Build the Future of{' '}
            <span className="text-primary">Natural Stone Architecture</span> Together
          </motion.h2>

          {/* Divider */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="w-16 h-1 bg-primary mx-auto mb-8"
          />

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-light text-base md:text-lg leading-relaxed mb-10 max-w-2xl mx-auto"
          >
            We welcome enquiries from importers, distributors, architects & builders, project
            developers, and technology collaboration partners.
          </motion.p>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <LuxuryButton
              variant="primary"
              size="lg"
              icon={FiArrowRight}
              onClick={() => navigate('/contact')}
            >
              Contact Our Team
            </LuxuryButton>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}