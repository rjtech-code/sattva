import { motion } from 'framer-motion'
import { GiStoneWall, GiFeather, GiFlexibleStar, GiThermometerCold } from 'react-icons/gi'

const stats = [
  { icon: GiFeather, value: '80%', label: 'Lighter than traditional slabs' },
  { icon: GiStoneWall, value: '1–3mm', label: 'Ultra-thin natural stone' },
  { icon: GiFlexibleStar, value: 'Flexible', label: 'Concave, convex & arched' },
  { icon: GiThermometerCold, value: 'All-Weather', label: 'Heat & cold resistant' },
]

export default function StatsSection() {
  return (
    <section className="relative overflow-hidden bg-primary-dark py-16 lg:py-0">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-24 left-1/4 w-80 h-80 rounded-full bg-primary/25 blur-[110px]" />
        <div className="absolute -bottom-24 right-1/4 w-80 h-80 rounded-full bg-primary-light/15 blur-[110px]" />
      </div>

      <div className="container-luxury max-w-[1400px] relative z-10">
        <div className="flex flex-col lg:flex-row lg:divide-x divide-white/10">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-60px' }}
              transition={{ duration: 0.6, delay: i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="group flex-1 flex items-center gap-5 py-8 lg:py-16 lg:px-8 first:pl-0 last:pr-0"
            >
              <stat.icon className="text-3xl lg:text-4xl text-primary-light flex-shrink-0 transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6" />
              <div>
                <div className="font-heading text-3xl lg:text-4xl font-semibold text-white leading-none mb-2">
                  {stat.value}
                </div>
                <div className="text-white/50 text-sm font-medium">{stat.label}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
