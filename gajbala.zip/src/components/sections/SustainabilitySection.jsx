import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import { GiRecycle } from 'react-icons/gi'
import LuxuryButton from '../ui/LuxuryButton'

export default function SustainabilitySection() {
  return (
    <section id="sustainability" className="section-padding bg-white relative overflow-hidden">
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-tl from-primary/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

      <div className="container-luxury max-w-[1400px] relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Left - Content */}
          <div>
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              Sustainability
            </motion.span>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-6"
            >
              Our Commitment to a Greener Future
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider"
            />

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.25 }}
              className="text-light text-base sm:text-lg leading-relaxed mb-8"
            >
              Sustainability drives every aspect of our operations. Our innovative thin-stone veneer 
              technology dramatically reduces material usage while preserving the natural beauty of stone. 
              We are committed to responsible sourcing and eco-conscious manufacturing.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex items-center gap-3 mb-10"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <GiRecycle className="text-lg text-primary" />
              </div>
              <div>
                <div className="font-body font-semibold text-sm text-dark">Eco-Friendly Manufacturing</div>
                <div className="text-xs text-light">Lower carbon footprint per sqft</div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <LuxuryButton
                variant="outline"
                icon={FiArrowRight}
                onClick={() => window.location.href = '/sustainability'}
              >
                Read Our Commitment
              </LuxuryButton>
            </motion.div>
          </div>

          {/* Right - Image */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="relative"
          >
            <div className="image-zoom rounded-[20px] shadow-lg shadow-black/10">
              <img
                src="/Images/drive/louver.jpg"
                alt="Sustainable eco-friendly natural stone manufacturing - GajBala Group"
                className="w-full h-[450px] lg:h-[520px] object-cover rounded-[20px]"
                loading="lazy"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-[20px] -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  )
}