import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import {
  GiFactory,
  GiStoneWall,
  GiEarthAmerica,
  GiDiamondRing,
  GiGearHammer,
  GiHandOk,
} from 'react-icons/gi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'
import TiltCard from '../ui/TiltCard'
import { partnerReasons } from '../../data/companyContent'

const icons = [GiStoneWall, GiGearHammer, GiDiamondRing, GiHandOk, GiFactory, GiEarthAmerica]

const highlights = partnerReasons.map((reason, i) => ({
  ...reason,
  icon: icons[i % icons.length],
  delay: 0.1 * (i + 1),
}))

export default function WhyChooseUs() {
  const navigate = useNavigate()

  return (
    <section id="why-choose-us" className="section-padding relative overflow-hidden">
      <div className="absolute inset-0 bg-bg z-0" />
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-primary/5 to-transparent rounded-full blur-[100px] pointer-events-none z-0" />

      <div className="container-luxury max-w-[1400px] relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="section-subtitle"
          >
            Why Partner With Us
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-title mb-4"
          >
            Why Partner With The Future Developer Of Flexible Stone Veneer In India?
          </motion.h2>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="green-divider mx-auto"
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="text-light text-base sm:text-lg mt-6"
          >
            Six reasons importers, distributors, architects and builders choose GajBala Group
          </motion.p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 max-w-6xl mx-auto">
          {highlights.map((item) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: item.delay, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="group"
            >
              <TiltCard
                strength={7}
                whileHover={{ y: -8, scale: 1.02 }}
                transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                className="premium-card p-6 lg:p-8 text-center h-full"
              >
                <div className="sweep" />
                <div className="premium-card-glow" />

                <div className="relative z-10">
                  <div className="premium-card-icon w-12 h-12 rounded-[14px] bg-[#7A7A7A]/10 flex items-center justify-center mx-auto mb-4">
                    <item.icon className="text-xl" style={{ color: '#6B7280' }} />
                  </div>

                  <h3 className="premium-card-title font-heading text-lg font-bold mb-2">
                    {item.title}
                  </h3>

                  <p className="premium-card-description text-sm leading-relaxed">{item.desc}</p>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="text-center mt-8"
        >
          <LuxuryButton variant="outline" icon={FiArrowRight} onClick={() => navigate('/partner')}>
            Become a Partner
          </LuxuryButton>
        </motion.div>
      </div>
    </section>
  )
}
