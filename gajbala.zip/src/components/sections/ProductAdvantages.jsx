import { motion } from 'framer-motion'
import { productAdvantages } from '../../data/companyContent'
import TiltCard from '../ui/TiltCard'

const advantages = productAdvantages.map((adv, i) => ({
  ...adv,
  delay: 0.05 * (i + 1),
}))

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, delay: i * 0.06, ease: [0.25, 0.46, 0.45, 0.94] },
  }),
}

export default function ProductAdvantages() {
  return (
    <section id="product-advantages" className="section-padding bg-[#FAFAF7] relative overflow-hidden">
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-gradient-to-br from-[#1B5E20]/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

      <div className="container-luxury max-w-[1400px] relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="section-subtitle"
          >
            Key Product Advantages
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-playfair text-3xl md:text-4xl font-bold text-dark leading-tight mb-4"
          >
            Why Flexible Stone Veneer Stands Apart
          </motion.h2>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="green-divider mx-auto"
          />
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.25 }}
            className="text-[#666666] text-base sm:text-lg mt-6"
          >
            Natural stone beauty engineered for modern architecture
          </motion.p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {advantages.map((adv, index) => (
            <motion.div
              key={adv.title}
              custom={index}
              variants={cardVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-50px' }}
              className="group"
            >
              <TiltCard
                strength={7}
                whileHover={{ y: -8, scale: 1.02 }}
                transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                className="premium-card overflow-hidden h-full flex flex-col"
              >
                <div className="premium-card-glow" />
                <div className="sweep" />

                <div className="relative z-10 p-6 lg:p-8 flex-1 flex flex-col">
                  <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-[#1B5E20]/10 text-xs font-bold text-[#1B5E20] mb-4">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <h3 className="premium-card-title font-playfair text-lg font-bold text-[#1B5E20] mb-2">
                    {adv.title}
                  </h3>
                  <p className="premium-card-description text-sm text-[#555555] leading-relaxed">
                    {adv.desc}
                  </p>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
