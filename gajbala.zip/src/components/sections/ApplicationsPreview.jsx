import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'

const applications = [
  {
    title: 'Residential',
    desc: 'Luxury stone finishes for premium homes and apartments.',
    image: '/Images/applications/bedroom-onyx.jpg',
    delay: 0.1,
  },
  {
    title: 'Commercial',
    desc: 'Durable stone solutions for offices and retail spaces.',
    image: '/Images/applications/office-wall.jpg',
    delay: 0.15,
  },
  {
    title: 'Hotels & Resorts',
    desc: 'Elegant stone aesthetics for hospitality projects.',
    image: '/Images/applications/rooftop-lounge.jpg',
    delay: 0.2,
  },
  {
    title: 'Luxury Villas',
    desc: 'Exclusive stone designs for high-end residences.',
    image: '/Images/applications/villa-facade.jpg',
    delay: 0.25,
  },
  {
    title: 'Retail Spaces',
    desc: 'Premium stone surfaces for flagship stores.',
    image: '/Images/applications/retail-counter.jpg',
    delay: 0.3,
  },
  {
    title: 'Hospitality',
    desc: 'Warm stone textures for restaurants and lounges.',
    image: '/Images/applications/bar-counter.jpg',
    delay: 0.35,
  },
]

export default function ApplicationsPreview() {
  const navigate = useNavigate()

  return (
    <section id="applications" className="section-padding bg-white">
      <div className="container-luxury max-w-[1400px]">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="section-subtitle"
          >
            Applications
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="section-title mb-4"
          >
            Premium Natural Stone Solutions Across Multiple Industries
          </motion.h2>
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="green-divider mx-auto"
          />
        </div>

        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {applications.map((app) => (
            <motion.div
              key={app.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.6, delay: app.delay, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="group cursor-pointer"
              onClick={() => navigate('/applications')}
            >
              <div className="premium-card">
                {/* Sweep effect */}
                <div className="sweep" />
                {/* Radial glow effect */}
                <div className="premium-card-glow" />
                
                <div className="relative z-10">
                  <div className="image-zoom relative h-[240px] overflow-hidden">
                    <img
                      src={app.image}
                      alt={`${app.title} - Natural stone by GajBala Group`}
                      className="w-full h-full object-cover transition-transform duration-700"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    <div className="absolute bottom-4 right-4 w-10 h-10 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-400 shadow-lg">
                      <FiArrowRight className="text-primary text-lg group-hover:text-white transition-colors duration-300" />
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="premium-card-title font-heading text-lg font-bold mb-2">
                      {app.title}
                    </h3>
                    <p className="premium-card-description text-sm leading-relaxed">
                      {app.desc}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="text-center mt-12"
        >
          <LuxuryButton
            variant="primary"
            size="lg"
            icon={FiArrowRight}
            onClick={() => navigate('/applications')}
          >
            Explore Applications
          </LuxuryButton>
        </motion.div>
      </div>
    </section>
  )
}