import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { productCatalog } from '../../data/productCatalog'
import { collectionsInfo } from '../../data/collectionsInfo'
import { NO_ZOOM_KEYS } from '../../data/catalogConstants'

// Kept in sync with the collection tiles on the Products page above the catalog.
const collectionKeys = ['flexoera', 'onyxoera', 'decoera', 'artoera', 'walloera', 'designoera', 'rockoera'].filter(
  (k) => productCatalog[k] && productCatalog[k].length > 0
)


const INITIAL_VISIBLE_ITEMS = 18

export default function ProductCatalog({ active: activeProp, onActiveChange, id = 'catalog' }) {
  const [activeState, setActiveState] = useState(collectionKeys[0])
  const [visibleCount, setVisibleCount] = useState(INITIAL_VISIBLE_ITEMS)
  const active = activeProp ?? activeState

  useEffect(() => {
    setVisibleCount(INITIAL_VISIBLE_ITEMS)
  }, [active])

  const setActive = (key) => {
    setActiveState(key)
    onActiveChange?.(key)
  }
  const items = productCatalog[active] || []
  const visibleItems = useMemo(() => items.slice(0, visibleCount), [items, visibleCount])
  const hasMoreItems = visibleCount < items.length

  return (
    <section id={id} className="pt-8 pb-14 lg:pt-10 lg:pb-16 bg-bg scroll-mt-28">
      <div className="container-luxury max-w-[1400px]">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="section-subtitle">Full Catalog</span>
          <h2 className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-3">Browse Every Finish, Code by Code</h2>
          <div className="green-divider mx-auto" />
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          {collectionKeys.map((key) => (
            <button
              key={key}
              onClick={() => setActive(key)}
              className={`relative isolate px-4 py-2 rounded-full text-xs sm:text-sm font-semibold uppercase tracking-wide transition-colors duration-300 border ${
                active === key
                  ? 'text-white border-primary'
                  : 'bg-white text-dark border-gray-200 hover:border-primary/50'
              }`}
            >
              {active === key && (
                <motion.span
                  layoutId="catalog-tab-pill"
                  transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  className="absolute inset-0 rounded-full bg-primary shadow-md -z-10"
                />
              )}
              {collectionsInfo[key]?.title || key} <span className="opacity-60">({productCatalog[key].length})</span>
            </button>
          ))}
        </div>

        {/* Grid */}
        <motion.div
          key={active}
          initial="hidden"
          animate="visible"
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.035 } },
          }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 md:gap-4"
        >
          {visibleItems.map((item) => (
            <motion.div
              key={item.code}
              variants={{
                hidden: { opacity: 0, y: 18, scale: 0.96 },
                visible: {
                  opacity: 1,
                  y: 0,
                  scale: 1,
                  transition: { duration: 0.45, ease: [0.22, 0.61, 0.36, 1] },
                },
              }}
              whileHover={{ y: -6 }}
            >
              <Link
                to={`/products/${active}/${encodeURIComponent(item.code)}`}
                className="group relative block rounded-[14px] overflow-hidden bg-white shadow-sm border border-gray-100 hover:shadow-xl hover:shadow-primary/10 hover:border-primary/30 transition-all duration-300"
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={item.src}
                    alt={`${collectionsInfo[active]?.title || active} ${item.code}`}
                    className={`w-full h-full object-cover transition-transform duration-500 ${
                      NO_ZOOM_KEYS.has(active)
                        ? 'group-hover:scale-110'
                        : 'scale-125 group-hover:scale-[1.35]'
                    }`}
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/75 to-transparent px-2.5 py-2">
                  <span className="text-white text-[10px] sm:text-xs font-semibold tracking-wide">
                    {item.code}
                  </span>
                </div>
                <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 group-hover:rotate-[360deg] transition-all duration-500 text-[10px] font-bold text-primary">
                  3D
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {hasMoreItems && (
          <div className="mt-8 text-center">
            <button
              type="button"
              onClick={() => setVisibleCount((count) => Math.min(count + 12, items.length))}
              className="luxury-btn luxury-btn-outline"
            >
              Load more finishes
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
