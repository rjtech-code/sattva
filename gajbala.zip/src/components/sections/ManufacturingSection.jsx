import { motion } from 'framer-motion'
import { FiArrowRight, FiCheck } from 'react-icons/fi'
import { GiFactory } from 'react-icons/gi'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'
import TiltCard from '../ui/TiltCard'
import { aboutIntro } from '../../data/companyContent'

const capabilities = [
  'Dedicated area for each production stage',
  'Superior machinery & skilled manpower',
  'Clearly defined systems and processes',
  'Multiple designs, types, colours & finishes',
]

export default function ManufacturingSection() {
  const navigate = useNavigate()

  return (
    <section id="manufacturing" className="section-padding bg-bg relative overflow-hidden">
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-tl from-primary/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

      <div className="container-luxury max-w-[1400px] relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="relative"
          >
            <TiltCard
              strength={6}
              glare={false}
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
              className="image-zoom rounded-[20px] shadow-lg shadow-black/10"
            >
              <img
                src="/Images/pdf-assets/manufacturing-process.jpg"
                alt="GajBala Group manufacturing — flexible stone veneer production"
                className="w-full h-[450px] lg:h-[520px] object-cover rounded-[20px]"
                loading="lazy"
              />
            </TiltCard>
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-[20px] -z-10" />
          </motion.div>

          <div>
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="section-subtitle"
            >
              Manufacturing Excellence
            </motion.span>

            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="section-title mb-6"
            >
              State-of-the-Art Manufacturing
            </motion.h2>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="green-divider"
            />

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.35 }}
              className="text-light text-base sm:text-lg leading-relaxed mb-8"
            >
              {aboutIntro.paragraphs[1]}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="space-y-3 mb-10"
            >
              {capabilities.map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <FiCheck className="text-sm text-primary" />
                  </div>
                  <span className="text-sm sm:text-base text-dark/80 leading-relaxed">{item}</span>
                </div>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="flex items-center gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <GiFactory className="text-lg text-primary" />
              </div>
              <LuxuryButton
                variant="outline"
                icon={FiArrowRight}
                onClick={() => navigate('/manufacturing')}
              >
                View Manufacturing
              </LuxuryButton>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
