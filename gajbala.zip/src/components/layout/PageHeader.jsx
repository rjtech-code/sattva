import { motion } from 'framer-motion'

export default function PageHeader({
  title,
  subtitle,
  bgImage,
  badge = 'GajBala Group',
}) {
  return (
    <section className="relative overflow-hidden pt-[130px] pb-16 md:pt-[150px] md:pb-20">
      {/* Background Image */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('${bgImage}')`,
            filter: 'brightness(0.45) saturate(1.1)',
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-dark/70 via-dark/40 to-dark/30" />
      </div>

      {/* Content */}
      <div className="container-luxury relative z-10 w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="max-w-3xl"
        >
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-sm text-white/50 mb-6 font-body">
            <a href="/" className="hover:text-primary transition-colors">Home</a>
            <span>/</span>
            <span className="text-white/80">{title}</span>
          </nav>

          {/* Badge */}
          {badge && (
            <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 border border-white/10 text-white/70 text-xs font-medium tracking-widest uppercase mb-5">
              {badge}
            </span>
          )}

          {/* Title */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white leading-tight [text-shadow:0_4px_24px_rgba(0,0,0,0.35)]">
            {title}
          </h1>

          {/* Subtitle */}
          {subtitle && (
            <p className="text-base md:text-lg text-white/70 mt-5 max-w-xl font-body font-light leading-relaxed">
              {subtitle}
            </p>
          )}
        </motion.div>
      </div>
    </section>
  )
}
