import { useState, useEffect, useCallback } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { IoMdClose } from 'react-icons/io'
import { HiMenuAlt3 } from 'react-icons/hi'
import { FiChevronRight } from 'react-icons/fi'
import LuxuryButton from '../ui/LuxuryButton'

const navItems = [
  { label: 'Home', path: '/' },
  { label: 'Marmomac', path: '/marmomac' },
  { label: 'E-Ston Era', path: '/eston-era' },
  { label: 'About', path: '/about' },
  { label: 'Products', path: '/products' },
  { label: 'Applications', path: '/applications' },
  { label: 'Contact', path: '/contact' },
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.2 },
  },
  exit: {
    opacity: 0,
    transition: { staggerChildren: 0.04, staggerDirection: -1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, x: 60 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] } },
  exit: { opacity: 0, x: 60, transition: { duration: 0.3 } },
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Close mobile menu on route change (covers back/forward navigation, not
  // just in-drawer link clicks which already close it themselves) — syncing
  // to an external source (browser history), not state derivable at render.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMobileOpen(false)
  }, [location.pathname])

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (mobileOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => { document.body.style.overflow = '' }
  }, [mobileOpen])

  const closeMobile = useCallback(() => setMobileOpen(false), [])

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={`
          fixed left-0 right-0 z-50
          transition-all duration-500 ease-in-out
          ${scrolled ? 'top-3 md:top-4' : 'top-0'}
        `}
      >
        <div
          className={`
            flex items-center justify-between transition-all duration-500 ease-in-out mx-auto
            ${scrolled
              ? 'nav-glass rounded-full shadow-xl shadow-black/10 px-5 md:px-7'
              : 'bg-transparent px-6'
            }
          `}
          style={{
            height: scrolled ? '68px' : '90px',
            maxWidth: scrolled ? '1220px' : '1400px',
            width: '100%',
          }}
        >
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group" aria-label="GajBala Group Home">
            <motion.div
              animate={{ scale: scrolled ? 0.9 : 1 }}
              transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="flex items-center gap-3"
            >
              <div className="relative w-10 h-10 md:w-11 md:h-11">
                <img
                  src="/Images/logo-icon.png"
                  alt="GajBala Group"
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className={`font-playfair text-lg md:text-xl font-bold leading-tight transition-colors duration-500 ${
                  scrolled ? 'text-[#222222]' : 'text-white'
                }`}>
                  GajBala
                </span>
                <span className={`text-[10px] md:text-[11px] font-medium tracking-[0.2em] uppercase leading-tight transition-colors duration-500 ${
                  scrolled ? 'text-[#1B5E20]' : 'text-white/80'
                }`}>
                  Group
                </span>
              </div>
            </motion.div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1" aria-label="Main navigation">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`
                    relative px-4 py-2 text-sm font-medium tracking-wide transition-colors duration-300
                    ${!isActive ? 'hover-underline' : ''}
                    ${isActive
                      ? scrolled
                        ? 'text-[#1B5E20]'
                        : 'text-white'
                      : scrolled
                        ? 'text-[#666666] hover:text-[#222222]'
                        : 'text-white/80 hover:text-white'
                    }
                  `}
                >
                  {item.label}
                  {isActive && (
                    <motion.span
                      layoutId="navActiveIndicator"
                      transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                      className={`absolute left-4 right-4 -bottom-0.5 h-[2px] rounded-full ${
                        scrolled ? 'bg-[#1B5E20]' : 'bg-white'
                      }`}
                    />
                  )}
                </Link>
              )
            })}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden lg:flex items-center">
            <LuxuryButton
              variant="primary"
              className="px-6 py-2.5 text-xs font-semibold"
              onClick={() => navigate('/contact')}
            >
              Get Quote
              <FiChevronRight className="text-base" />
            </LuxuryButton>
          </div>

          {/* Mobile Hamburger */}
          <button
            onClick={() => setMobileOpen(true)}
            className={`lg:hidden relative z-50 w-10 h-10 flex items-center justify-center rounded-lg transition-colors cursor-pointer ${
              scrolled ? 'text-[#222222] hover:bg-gray-100' : 'text-white hover:bg-white/10'
            }`}
            aria-label="Open navigation menu"
            aria-expanded={mobileOpen}
          >
            <HiMenuAlt3 className="text-2xl" />
          </button>
        </div>
      </motion.header>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm lg:hidden"
              onClick={closeMobile}
              aria-hidden="true"
            />

            {/* Drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="fixed top-0 right-0 bottom-0 z-[60] w-full max-w-sm bg-white shadow-2xl lg:hidden"
            >
              {/* Drawer Header */}
              <div className="flex items-center justify-between px-6 py-6 border-b border-[#ECECEC]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 flex items-center justify-center">
                    <img src="/Images/logo-icon.png" alt="GajBala Group" className="w-full h-full object-contain" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-playfair text-lg font-bold leading-tight text-[#222222]">GajBala</span>
                    <span className="text-[10px] font-medium tracking-[0.2em] uppercase leading-tight text-[#1B5E20]">Group</span>
                  </div>
                </div>
                <button
                  onClick={closeMobile}
                  className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors"
                  aria-label="Close navigation menu"
                >
                  <IoMdClose className="text-2xl text-[#222222]" />
                </button>
              </div>

              {/* Navigation Links */}
              <motion.nav
                variants={containerVariants}
                initial="hidden"
                animate="visible"
                exit="exit"
                className="px-6 py-8 space-y-1"
                aria-label="Mobile navigation"
              >
                {navItems.map((item) => (
                  <motion.div key={item.path} variants={itemVariants}>
                    <Link
                      to={item.path}
                      onClick={closeMobile}
                      className={`
                        flex items-center justify-between px-4 py-4 rounded-xl text-base font-medium transition-all duration-300
                        ${location.pathname === item.path
                          ? 'bg-[#1B5E20]/5 text-[#1B5E20]'
                          : 'text-[#666666] hover:bg-gray-50 hover:text-[#222222]'
                        }
                      `}
                    >
                      <span>{item.label}</span>
                      <FiChevronRight className={`text-lg transition-colors ${
                        location.pathname === item.path ? 'text-[#1B5E20]' : 'text-gray-300'
                      }`} />
                    </Link>
                  </motion.div>
                ))}
              </motion.nav>

              {/* Drawer CTA */}
              <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-[#ECECEC] bg-white">
                <LuxuryButton
                  variant="primary"
                  className="w-full py-4"
                  onClick={() => {
                    closeMobile()
                    navigate('/contact')
                  }}
                >
                  Get Quote
                  <FiChevronRight className="text-lg" />
                </LuxuryButton>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  )
}