import { Suspense } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { Helmet } from 'react-helmet-async'
import { AnimatePresence } from 'framer-motion'
import Navbar from './Navbar'
import Footer from './Footer'
import WhatsAppFloat from '../ui/WhatsAppFloat'
import PageTransition from '../PageTransition'
import ScrollProgress from '../ScrollProgress'
import { ORGANIZATION, SITE_NAME, SITE_URL } from '../../data/seoConfig'

// Site-wide Organization + LocalBusiness structured data — present on every
// page regardless of route, alongside each page's own <SEO> title/description.
const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': ['Organization', 'LocalBusiness'],
  name: SITE_NAME,
  legalName: ORGANIZATION.legalName,
  url: ORGANIZATION.url,
  logo: ORGANIZATION.logo,
  image: ORGANIZATION.logo,
  telephone: ORGANIZATION.telephone,
  email: ORGANIZATION.email,
  address: {
    '@type': 'PostalAddress',
    addressLocality: ORGANIZATION.addressLocality,
    addressRegion: ORGANIZATION.addressRegion,
    addressCountry: ORGANIZATION.addressCountry,
  },
  sameAs: ORGANIZATION.sameAs,
}

const websiteSchema = {
  '@context': 'https://schema.org',
  '@type': 'WebSite',
  name: SITE_NAME,
  url: SITE_URL,
  description: 'GajBala Group manufactures ultra-thin flexible natural stone veneer, stone surfaces, and architectural materials for global projects.',
  inLanguage: 'en-IN',
  potentialAction: {
    '@type': 'SearchAction',
    target: `${SITE_URL}/products?q={search_term_string}`,
    'query-input': 'required name=search_term_string',
  },
}

export default function Layout() {
  const location = useLocation()

  return (
    <>
      <Helmet>
        <script type="application/ld+json">{JSON.stringify(organizationSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(websiteSchema)}</script>
      </Helmet>
      <ScrollProgress />
      <Navbar />
      <main>
        <AnimatePresence mode="wait" initial={false}>
          <PageTransition key={location.pathname}>
            <Suspense fallback={<div className="min-h-screen" aria-hidden="true" />}>
              <Outlet />
            </Suspense>
          </PageTransition>
        </AnimatePresence>
      </main>
      <Footer />
      <WhatsAppFloat />
    </>
  )
}
