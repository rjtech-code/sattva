import { motion } from 'framer-motion'
import { FiArrowRight, FiPhone, FiMail, FiMapPin, FiGlobe } from 'react-icons/fi'
import { FaLinkedinIn, FaFacebookF, FaInstagram, FaWhatsapp } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'
import LuxuryButton from '../ui/LuxuryButton'

// ─── Data ──────────────────────────────────────────────────────
const quickLinks = [
  { label: 'Home', href: '/' },
  { label: 'E-Ston Era', href: '/eston-era' },
  { label: 'About', href: '/about' },
  { label: 'Products', href: '/products' },
  { label: 'Applications', href: '/applications' },
  { label: 'Manufacturing', href: '/manufacturing' },
  { label: 'Sustainability', href: '/sustainability' },
  { label: 'Partner With Us', href: '/partner' },
  { label: 'Contact', href: '/contact' },
]

const contactInfo = [
  { icon: FiMapPin, label: 'Company', value: 'GajBala Universe Pvt Ltd' },
  { icon: FiPhone, label: 'Phone / WhatsApp', value: '+91 81406 79999' },
  { icon: FiMail, label: 'Email', value: 'office@gajbalagroup.com' },
  { icon: FiGlobe, label: 'Website', value: 'www.gajbalagroup.com' },
]

const socialLinks = [
  { icon: FaLinkedinIn, href: 'https://www.linkedin.com/company/gajbala-group/', label: 'LinkedIn' },
  { icon: FaFacebookF, href: 'https://facebook.com/gajbalagroup', label: 'Facebook' },
  { icon: FaInstagram, href: 'https://www.instagram.com/gajbala_group', label: 'Instagram' },
  { icon: FaWhatsapp, href: 'https://wa.me/918140679999', label: 'WhatsApp' },
]

// ─── Stagger Container ─────────────────────────────────────
const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.08, delayChildren: 0.2 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.25, 0.46, 0.45, 0.94] },
  },
}

const linkVariants = {
  hidden: { opacity: 0, x: -10 },
  visible: (i) => ({
    opacity: 1,
    x: 0,
    transition: { delay: 0.3 + i * 0.04, duration: 0.4, ease: 'easeOut' },
  }),
}

// ─── Main Component ─────────────────────────────────────────
export default function Footer() {
  const navigate = useNavigate()

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const handleNav = (href) => {
    if (href.startsWith('/')) {
      navigate(href)
      scrollToTop()
    } else {
      const target = document.querySelector(href)
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' })
      }
    }
  }

  return (
    <footer role="contentinfo" aria-label="Site footer">
      {/* ═══════════════════════════════════════════════════════
          MAIN FOOTER
          ═══════════════════════════════════════════════════════ */}
      <div className="relative bg-[#1F2D1F] overflow-hidden pt-32 md:pt-36 pb-20">
        {/* Background Effects */}
        <div className="absolute inset-0">
          {/* Marble texture */}
          <div className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `
                radial-gradient(ellipse at 20% 30%, rgba(255,255,255,0.06) 0%, transparent 50%),
                radial-gradient(ellipse at 80% 20%, rgba(255,255,255,0.04) 0%, transparent 50%),
                radial-gradient(ellipse at 50% 80%, rgba(255,255,255,0.03) 0%, transparent 50%)
              `,
            }}
          />
          {/* Floating glows */}
          <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-primary/8 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
        </div>

        <div className="container-luxury max-w-[1400px] relative z-10">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: '-50px' }}
            variants={containerVariants}
          >
            {/* 3-Column Grid */}
            <div className="grid md:grid-cols-3 gap-12 lg:gap-16">
              {/* ─── COLUMN 1: Branding ────────────────── */}
              <motion.div variants={itemVariants}>
                {/* Logo */}
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-white/95 flex items-center justify-center shadow-lg shadow-primary/20 p-1.5">
                    <img src="/Images/logo-icon.png" alt="GajBala Group" className="w-full h-full object-contain" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-heading font-bold text-xl md:text-2xl leading-tight text-white">
                      GajBala
                    </span>
                    <span className="text-[10px] md:text-xs font-body font-medium tracking-[0.2em] uppercase text-white/50">
                      Flexible Stone Veneer
                    </span>
                  </div>
                </div>

                {/* Description */}
                <p className="text-white/60 text-sm leading-relaxed mb-6 max-w-xs">
                  Opening the future of the global E-Ston industry with ultra-thin flexible stone veneer —
                  delivering flawless performance through operational excellence.
                </p>

                {/* Social Icons */}
                <div className="flex items-center gap-3" role="list" aria-label="Social media links">
                  {socialLinks.map((social) => (
                    <motion.a
                      key={social.label}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={social.label}
                      role="listitem"
                      whileHover={{ scale: 1.15, y: -3 }}
                      whileTap={{ scale: 0.95 }}
                      className="w-9 h-9 rounded-full bg-white/8 border border-white/10 flex items-center justify-center
                                text-white/60 hover:bg-primary hover:text-white hover:border-primary
                                transition-all duration-300"
                    >
                      <social.icon size={14} />
                    </motion.a>
                  ))}
                </div>
              </motion.div>

              {/* ─── COLUMN 2: Quick Links ────────────── */}
              <motion.div variants={itemVariants}>
                <div className="font-heading text-lg font-bold text-white mb-6 font-serif">Quick Links</div>
                <ul className="space-y-3" role="list">
                  {quickLinks.map((link, i) => (
                    <motion.li
                      key={link.label}
                      custom={i}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true }}
                      variants={linkVariants}
                    >
                      <button
                        onClick={() => handleNav(link.href)}
                        className="group flex items-center gap-2 text-white/60 hover:text-white transition-colors duration-300 text-sm"
                        aria-label={`Navigate to ${link.label}`}
                      >
                        <span className="w-0 group-hover:w-4 h-[1px] bg-primary transition-all duration-300" />
                        <span className="group-hover:translate-x-1 transition-transform duration-300">
                          {link.label}
                        </span>
                      </button>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>

              {/* ─── COLUMN 3: Contact ────────────────── */}
              <motion.div variants={itemVariants}>
                <div className="font-heading text-lg font-bold text-white mb-6 font-serif">Contact</div>
                <ul className="space-y-4" role="list">
                  {contactInfo.map((item) => (
                    <li key={item.label}>
                      <div className="flex items-start gap-3">
                        <div className="w-8 h-8 rounded-lg bg-white/80 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <item.icon className="text-gray-600 font-bold text-sm" />
                        </div>
                        <div>
                          <div className="text-white/40 text-[11px] font-medium uppercase tracking-wider">
                            {item.label}
                          </div>
                          <div className="text-white/80 text-sm mt-0.5">
                            {item.value}
                          </div>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>

                {/* Get Quote Button */}
                <div className="mt-8">
                  <LuxuryButton
                    variant="primary"
                    size="sm"
                    icon={FiArrowRight}
                    onClick={() => { navigate('/contact'); scrollToTop(); }}
                    className="!bg-primary hover:!bg-[#43A047] !shadow-lg !shadow-primary/20"
                  >
                    Get Quote
                  </LuxuryButton>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>

        {/* ═══════════════════════════════════════════════════════
            BOTTOM BAR
            ═══════════════════════════════════════════════════════ */}
        <div className="relative z-10 mt-16 pt-8 border-t border-white/8">
          <div className="container-luxury max-w-[1400px]">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left">
              {/* Left */}
              <motion.p
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="text-white/40 text-xs font-body"
              >
                &copy; {new Date().getFullYear()} GajBala Group. All Rights Reserved.
              </motion.p>

              {/* Right */}
              <motion.div
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="flex items-center gap-4"
              >
                <button
                  onClick={() => handleNav('/contact')}
                  className="text-white/40 hover:text-white text-xs transition-colors duration-300 relative group"
                  aria-label="Privacy Policy"
                >
                  Privacy Policy
                  <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-primary group-hover:w-full transition-all duration-300" />
                </button>
                <span className="text-white/20 text-xs">|</span>
                <button
                  onClick={() => handleNav('/contact')}
                  className="text-white/40 hover:text-white text-xs transition-colors duration-300 relative group"
                  aria-label="Terms and Conditions"
                >
                  Terms & Conditions
                  <span className="absolute -bottom-0.5 left-0 w-0 h-[1px] bg-primary group-hover:w-full transition-all duration-300" />
                </button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}