import { Helmet } from 'react-helmet-async'
import {
  SITE_URL,
  SITE_NAME,
  SITE_DEFAULT_DESCRIPTION,
  DEFAULT_OG_IMAGE,
  DEFAULT_OG_IMAGE_ALT,
  TWITTER_HANDLE,
} from '../data/seoConfig'

/**
 * Per-page SEO: title, meta description, canonical URL, Open Graph / Twitter
 * Card tags, and optional JSON-LD structured data. Drop one of these near the
 * top of every routed page so each URL gets its own accurate metadata instead
 * of every route sharing index.html's single static <title>/<meta>.
 *
 * `jsonLd` accepts a single schema object or an array of them.
 */
export default function SEO({ title, description, canonical, image = DEFAULT_OG_IMAGE, jsonLd }) {
  const fullTitle = title.includes(SITE_NAME) ? title : `${title} | ${SITE_NAME}`
  const pageDescription = description || SITE_DEFAULT_DESCRIPTION
  const url = canonical ? `${SITE_URL}${canonical}` : undefined
  const absoluteImage = image?.startsWith('http') ? image : `${SITE_URL}${image}`
  const schemas = jsonLd ? (Array.isArray(jsonLd) ? jsonLd : [jsonLd]) : []

  return (
    <Helmet>
      <title>{fullTitle}</title>
      <meta name="description" content={pageDescription} />
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      {url && <link rel="canonical" href={url} />}

      {/* Open Graph */}
      <meta property="og:type" content="website" />
      <meta property="og:locale" content="en_IN" />
      <meta property="og:site_name" content={SITE_NAME} />
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={pageDescription} />
      {url && <meta property="og:url" content={url} />}
      <meta property="og:image" content={absoluteImage} />
      <meta property="og:image:alt" content={DEFAULT_OG_IMAGE_ALT} />

      {/* Twitter Card */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content={TWITTER_HANDLE} />
      <meta name="twitter:creator" content={TWITTER_HANDLE} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={pageDescription} />
      <meta name="twitter:image" content={absoluteImage} />
      <meta name="twitter:image:alt" content={DEFAULT_OG_IMAGE_ALT} />

      {schemas.map((schema, i) => (
        <script key={i} type="application/ld+json">
          {JSON.stringify(schema)}
        </script>
      ))}
    </Helmet>
  )
}
