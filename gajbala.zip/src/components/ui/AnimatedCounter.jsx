import { useEffect, useMemo, useRef, useState } from 'react'
import { useInView } from 'framer-motion'

/**
 * Counts up from 0 to the numeric part of `value` (e.g. "25+", "500K", "1000+")
 * once it scrolls into view. Prefix/suffix text around the number is preserved.
 */
export default function AnimatedCounter({ value, duration = 1.6, className = '' }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  // Memoized so it's a stable reference across renders (only recomputed if
  // `value` changes) — otherwise a new match array on every render would
  // re-trigger the effect below on every animation frame.
  const match = useMemo(() => String(value).match(/[\d.]+/), [value])
  const [display, setDisplay] = useState(match ? null : value)

  useEffect(() => {
    if (!isInView || !match) return

    const target = parseFloat(match[0])
    const prefix = value.slice(0, match.index)
    const suffix = value.slice(match.index + match[0].length)
    const isInt = Number.isInteger(target)
    let raf
    let start = null

    const step = (timestamp) => {
      if (start === null) start = timestamp
      const progress = Math.min((timestamp - start) / (duration * 1000), 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      const current = target * eased
      setDisplay(`${prefix}${isInt ? Math.round(current) : current.toFixed(1)}${suffix}`)
      if (progress < 1) raf = requestAnimationFrame(step)
    }

    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [isInView, value, duration, match])

  return (
    <span ref={ref} className={className}>
      {display ?? value.replace(/[\d.]/g, '0')}
    </span>
  )
}
