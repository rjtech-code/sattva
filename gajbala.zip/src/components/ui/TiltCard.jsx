import { useRef, useState } from 'react'
import { motion } from 'framer-motion'
import useTilt from '../../hooks/useTilt'

/**
 * Drop-in replacement for a `premium-card` div/motion.div that adds a
 * pointer-tracked 3D tilt and a soft moving glare. Keeps all existing
 * premium-card CSS (sweep, glow, hover styles) untouched — just pass the
 * same className and children through.
 */
export default function TiltCard({
  children,
  className = '',
  strength = 8,
  glare = true,
  style,
  onMouseMove,
  onMouseLeave,
  ...props
}) {
  const ref = useRef(null)
  const tilt = useTilt(strength)
  const [hovered, setHovered] = useState(false)

  const handleMove = (e) => {
    tilt.onMouseMove(e, ref.current)
    onMouseMove?.(e)
  }
  const handleLeave = (e) => {
    tilt.onMouseLeave()
    setHovered(false)
    onMouseLeave?.(e)
  }

  return (
    <motion.div
      ref={ref}
      className={className}
      style={{ rotateX: tilt.rotateX, rotateY: tilt.rotateY, transformPerspective: 1000, ...style }}
      onMouseMove={handleMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleLeave}
      {...props}
    >
      {children}
      {glare && (
        <motion.div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 z-20"
          animate={{ opacity: hovered ? 1 : 0 }}
          transition={{ duration: 0.4 }}
          style={{
            background: `radial-gradient(circle 180px at ${tilt.glareX} ${tilt.glareY}, rgba(255,255,255,0.25), transparent 70%)`,
            mixBlendMode: 'overlay',
          }}
        />
      )}
    </motion.div>
  )
}
