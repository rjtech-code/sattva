import { motion } from 'framer-motion'
import { FaWhatsapp } from 'react-icons/fa'

export default function WhatsAppFloat() {
  return (
    <motion.a
      href="https://wa.me/918140679999"
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      initial={{ opacity: 0, scale: 0, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay: 1.2, duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 group"
    >
      <motion.span
        initial={{ opacity: 0, x: 10 }}
        className="hidden md:group-hover:flex items-center bg-[#1F2D1F] text-white text-sm font-medium px-4 py-2 rounded-full shadow-lg whitespace-nowrap"
      >
        Chat with us
      </motion.span>
      <span className="relative flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] shadow-xl shadow-[#25D366]/40">
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-40" />
        <FaWhatsapp className="relative text-white text-2xl md:text-3xl" />
      </span>
    </motion.a>
  )
}
