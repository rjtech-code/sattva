import { useRef, useCallback } from 'react'
import { motion } from 'framer-motion'

const variants = {
  primary: 'luxury-btn luxury-btn-primary',
  secondary: 'luxury-btn luxury-btn-secondary',
  outline: 'luxury-btn luxury-btn-outline',
}

const sizes = {
  md: '',
  lg: 'text-base px-8 py-4',
}

export default function LuxuryButton({
  children,
  variant = 'primary',
  size = 'md',
  icon: Icon,
  className = '',
  onClick,
  type = 'button',
  href,
  ...props
}) {
  const btnRef = useRef(null)

  const handleMouseMove = useCallback((e) => {
    const btn = btnRef.current
    if (!btn) return
    const rect = btn.getBoundingClientRect()
    const x = ((e.clientX - rect.left) / rect.width) * 100
    const y = ((e.clientY - rect.top) / rect.height) * 100
    btn.style.setProperty('--x', `${x}%`)
    btn.style.setProperty('--y', `${y}%`)
  }, [])

  const Component = href ? 'a' : motion.button
  const motionProps = href
    ? { href, target: href.startsWith('http') ? '_blank' : undefined, rel: href.startsWith('http') ? 'noopener noreferrer' : undefined }
    : {
        whileHover: { scale: 1.02 },
        whileTap: { scale: 0.98 },
      }

  return (
    <Component
      ref={btnRef}
      type={href ? undefined : type}
      className={`${variants[variant]} ${sizes[size] || ''} ripple flex items-center gap-2 ${className}`}
      onMouseMove={handleMouseMove}
      onClick={onClick}
      {...motionProps}
      {...props}
    >
      {children}
      {Icon && <Icon />}
    </Component>
  )
}