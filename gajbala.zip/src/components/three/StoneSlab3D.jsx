import { Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Environment } from '@react-three/drei'
import { TextureLoader, BoxGeometry, SRGBColorSpace } from 'three'

// Slab proportions: the longer side is fixed, the shorter side follows each
// photo's own aspect ratio (set once it loads) so the full image is shown
// undistorted instead of being cropped/stretched to a fixed frame.
const MAX_SPAN = 2.4
const DEPTH = 0.018
const WIDTH_SEGMENTS = 32
const EDGE_COLOR = '#2e2e2e'

// How the panel gently flexes — a slow, continuous wave across its width
const WAVE_AMPLITUDE = 0.07
const WAVE_FREQUENCY = 1.6
const WAVE_SPEED = 0.95

function Slab({ image }) {
  const meshRef = useRef(null)
  const [texture, setTexture] = useState(null)
  const [size, setSize] = useState({ width: MAX_SPAN, height: MAX_SPAN * 0.6 })

  // Subdivided box (not a plain 1-segment box) so the front/back faces can
  // bend smoothly into a wave instead of just flexing at the 8 corners.
  // Sized to the loaded photo's own aspect ratio — recreated whenever that changes.
  const geometry = useMemo(
    () => new BoxGeometry(size.width, size.height, DEPTH, WIDTH_SEGMENTS, 1, 1),
    [size]
  )
  // Flat (un-waved) vertex positions, kept so the wave offset is always
  // computed from the original shape rather than compounding frame over frame.
  const basePositions = useMemo(
    () => geometry.attributes.position.array.slice(),
    [geometry]
  )

  useEffect(() => {
    let cancelled = false
    const loader = new TextureLoader()
    loader.load(image, (loaded) => {
      // Photos are authored as sRGB (like any normal JPEG/PNG) — without this,
      // three.js treats the pixel data as linear and re-encodes it, which is
      // what washes the stone out lighter/flatter than the original photo.
      loaded.colorSpace = SRGBColorSpace
      loaded.anisotropy = 8
      // Show the photo exactly as shot — no crop/zoom — the slab's own shape
      // (below) matches its aspect ratio instead, so nothing is cut off or squashed.
      if (cancelled) return
      const aspect = loaded.image.width / loaded.image.height
      setSize(
        aspect >= 1
          ? { width: MAX_SPAN, height: MAX_SPAN / aspect }
          : { width: MAX_SPAN * aspect, height: MAX_SPAN }
      )
      setTexture(loaded)
    })
    return () => {
      cancelled = true
    }
  }, [image])

  /* eslint-disable react-hooks/immutability -- r3f's standard per-frame
     vertex-animation pattern: the geometry's buffer is mutated in place every
     frame for performance; recreating it would defeat the point of useMemo. */
  useFrame(({ clock }) => {
    const pos = geometry.attributes.position
    const t = clock.getElapsedTime() * WAVE_SPEED
    for (let i = 0; i < pos.count; i++) {
      const x = basePositions[i * 3]
      const z = basePositions[i * 3 + 2]
      const wave = Math.sin(x * WAVE_FREQUENCY + t) * WAVE_AMPLITUDE
      pos.setZ(i, z + wave)
    }
    pos.needsUpdate = true
    geometry.computeVertexNormals()
  })
  /* eslint-enable react-hooks/immutability */

  if (!texture) return null

  return (
    <mesh ref={meshRef} geometry={geometry} rotation={[0, 0.5, 0]} castShadow receiveShadow>
      {/* Materials order: +x, -x, +y, -y, +z (front, visible face), -z (back) */}
      <meshStandardMaterial attach="material-0" color={EDGE_COLOR} roughness={0.7} />
      <meshStandardMaterial attach="material-1" color={EDGE_COLOR} roughness={0.7} />
      <meshStandardMaterial attach="material-2" color={EDGE_COLOR} roughness={0.7} />
      <meshStandardMaterial attach="material-3" color={EDGE_COLOR} roughness={0.7} />
      {/* Unlit on purpose: the stone photo should render exactly as shot, not
          brightened/washed out by scene lights, environment or tone mapping. */}
      <meshBasicMaterial attach="material-4" map={texture} toneMapped={false} />
      <meshStandardMaterial attach="material-5" color={EDGE_COLOR} roughness={0.7} />
    </mesh>
  )
}

export default function StoneSlab3D({ image, className = '' }) {
  return (
    <div className={`relative min-w-0 rounded-[20px] overflow-hidden bg-gradient-to-br from-[#f4f2ee] to-[#e6e2da] ${className}`}>
      <Canvas shadows camera={{ position: [0, 0, 3.4], fov: 40 }} style={{ width: '100%', height: '100%' }}>
        <ambientLight intensity={0.7} />
        <directionalLight position={[3, 4, 5]} intensity={1.1} castShadow />
        <directionalLight position={[-3, -2, -4]} intensity={0.3} />
        <Slab image={image} />
        <Suspense fallback={null}>
          <Environment preset="apartment" />
        </Suspense>
        <OrbitControls
          enablePan={false}
          minDistance={1.8}
          maxDistance={5}
          autoRotate
          autoRotateSpeed={1.4}
        />
      </Canvas>
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-[11px] text-dark/50 font-medium tracking-wide bg-white/70 backdrop-blur-sm px-3 py-1.5 rounded-full pointer-events-none">
        Hold to Rotate · Scroll to Zoom
      </div>
    </div>
  )
}
