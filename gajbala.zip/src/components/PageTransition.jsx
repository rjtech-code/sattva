import { motion } from 'framer-motion'

// Wraps every routed page so navigation feels like a designed transition
// instead of an instant hard-cut — clip-path wipe + fade/slide combo.
const variants = {
  initial: {
    opacity: 0,
    y: 24,
    clipPath: 'inset(8% 0% 8% 0% round 12px)',
  },
  animate: {
    opacity: 1,
    y: 0,
    clipPath: 'inset(0% 0% 0% 0% round 0px)',
    transition: {
      duration: 0.65,
      ease: [0.16, 1, 0.3, 1],
      clipPath: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
    },
  },
  exit: {
    opacity: 0,
    y: -16,
    transition: { duration: 0.3, ease: [0.4, 0, 1, 1] },
  },
}

export default function PageTransition({ children }) {
  return (
    <motion.div
      variants={variants}
      initial="initial"
      animate="animate"
      exit="exit"
      style={{ willChange: 'clip-path, opacity, transform' }}
    >
      {children}
    </motion.div>
  )
}
