import { motion } from 'framer-motion'
import { FiCalendar, FiMapPin, FiArrowRight, FiUsers, FiGlobe, FiTrendingUp, FiHash, FiCompass } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import TiltCard from '../components/ui/TiltCard'
import { productCatalog } from '../data/productCatalog'
import { collectionsInfo } from '../data/collectionsInfo'

// Kept in sync with the collection tiles on the Products page.
const showcaseKeys = ['flexoera', 'onyxoera', 'decoera', 'artoera', 'walloera', 'designoera']

const highlights = [
  { icon: FiUsers, label: 'Global Buyers', desc: 'Importers, distributors & architects under one roof' },
  { icon: FiTrendingUp, label: 'Live Demos', desc: 'Flexible stone veneer flexibility & finish showcase' },
  { icon: FiGlobe, label: 'India · Italy', desc: 'Two stone traditions, one growing partnership' },
]

const standDetails = [
  { icon: FiHash, label: 'Hall', value: 'Hall 11' },
  { icon: FiMapPin, label: 'Stand', value: 'D1-A' },
  { icon: FiCompass, label: 'Nearest Avenue', value: 'Avenue E' },
  {
    icon: FiGlobe,
    label: 'Nearby Landmarks',
    value: '"The Bedrock" & Hall 12 (north), Area I (south), Hall 9 / Area D directly across Avenue E',
  },
]

export default function Marmomac() {
  const navigate = useNavigate()

  return (
    <>
      <SEO
        title="GajBala Group at Marmomac Verona 2026 | Natural Stone Exhibition"
        description="Meet GajBala Group at Marmomac, Verona — Hall 11, Stand D1-A. See our Flexoera, Onyxoera, Decoera, Artoera, Walloera and Designoera flexible stone veneer collections live, September 22–25, 2026."
        canonical="/marmomac"
      />
      <PageHeader
        title="Marmomac Verona 2026"
        subtitle="GajBala Group at the world's leading natural stone exhibition — Verona, Italy."
        bgImage="/Images/marmomac/expo-hall.jpg"
      />

      {/* Find Us at the Show — hall & stand location */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="max-w-2xl mx-auto text-center mb-12">
            <span className="section-subtitle mx-auto">Find Us at the Show</span>
            <h2 className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4">
              GajBala Group — Hall 11, Stand D1-A
            </h2>
            <div className="green-divider mx-auto mb-6" />
            <p className="text-light text-base leading-relaxed">
              Look for us in Hall 11, right along Avenue E — between &ldquo;The Bedrock&rdquo; and
              Hall 12 to the north, and Area I to the south, directly opposite Hall 9 and Area D.
            </p>
          </div>

          <div className="grid lg:grid-cols-[1fr_1.3fr] gap-10 lg:gap-14 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="space-y-4"
            >
              {standDetails.map((item) => (
                <div
                  key={item.label}
                  className="flex items-start gap-4 rounded-[16px] bg-bg border border-border p-5"
                >
                  <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center flex-shrink-0">
                    <item.icon />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold tracking-[0.15em] uppercase text-primary mb-1">
                      {item.label}
                    </div>
                    <div className="text-sm md:text-base font-medium text-dark leading-relaxed">
                      {item.value}
                    </div>
                  </div>
                </div>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7, delay: 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="relative"
            >
              <TiltCard strength={4} glare={false} className="rounded-[20px] overflow-hidden shadow-xl shadow-black/10 border border-border bg-white">
                <img
                  src="/Images/marmomac/hall-11-floor-plan.png"
                  alt="Veronafiere floor plan — GajBala Group at Hall 11, Stand D1-A"
                  className="w-full h-auto object-contain"
                  loading="lazy"
                />
              </TiltCard>
              <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-primary text-white text-xs font-semibold tracking-wide px-4 py-2 rounded-full shadow-lg whitespace-nowrap">
                Hall 11 · Stand D1-A
              </span>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="max-w-3xl mx-auto text-center mb-14">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="section-subtitle mx-auto"
            >
              India &middot; Italy &middot; Stronger Together
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="font-playfair text-3xl md:text-4xl font-bold text-dark leading-tight mb-4"
            >
              GajBala Group is Exhibiting at Marmomac
            </motion.h2>
            <div className="green-divider mx-auto mb-6" />
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-light text-base sm:text-lg leading-relaxed"
            >
              GajBala Group is heading to Marmomac, Verona — the global stage for natural stone —
              from September 22&ndash;25, 2026, bringing India's E-Ston flexible stone veneer
              collections to a worldwide audience of architects, builders and distributors.
            </motion.p>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto mb-16">
            {highlights.map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="rounded-[16px] bg-bg border border-border p-6 text-center"
              >
                <item.icon className="text-2xl text-primary mx-auto mb-3" />
                <div className="text-sm font-bold text-dark mb-1">{item.label}</div>
                <div className="text-xs text-light leading-relaxed">{item.desc}</div>
              </motion.div>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-light text-sm mb-4">
            <span className="flex items-center gap-2"><FiCalendar className="text-primary" /> September 22&ndash;25, 2026</span>
            <span className="flex items-center gap-2"><FiMapPin className="text-primary" /> Veronafiere, Verona, Italy</span>
          </div>
        </div>
      </section>

      {/* Collections on display */}
      <section className="section-padding bg-bg">
        <div className="container-luxury max-w-[1400px]">
          <div className="max-w-2xl mx-auto text-center mb-12">
            <span className="section-subtitle mx-auto">On Display</span>
            <h2 className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4">
              Our Collections at the Show
            </h2>
            <div className="green-divider mx-auto mb-6" />
            <p className="text-light text-base leading-relaxed">
              A curated line-up of GajBala's flexible stone veneer collections will be showcased
              live on our Marmomac booth.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-5 lg:gap-6">
            {showcaseKeys.map((key, i) => {
              const info = collectionsInfo[key]
              const thumb = productCatalog[key]?.[0]?.src
              if (!info || !thumb) return null
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                >
                  <TiltCard
                    strength={6}
                    glare={false}
                    className="image-zoom rounded-[16px] overflow-hidden shadow-md shadow-black/5 cursor-pointer"
                    onClick={() => navigate('/products')}
                  >
                    <img
                      src={thumb}
                      alt={`${info.title} - GajBala Group natural stone veneer`}
                      className="w-full h-36 object-cover"
                      loading="lazy"
                    />
                    <div className="p-3 bg-white">
                      <div className="text-sm font-bold text-dark">{info.title}</div>
                      <div className="text-[11px] text-light">{info.tagline}</div>
                    </div>
                  </TiltCard>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* GajBala x Marmomac banner */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-center rounded-[24px] bg-primary-dark p-8 md:p-12 lg:p-16 relative overflow-hidden">
            <div className="absolute inset-0 marble-texture opacity-10 z-0" />
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative z-10"
            >
              <img src="/Images/logo-full.png" alt="GajBala Group" className="h-12 md:h-14 mb-6 brightness-0 invert" />
              <h3 className="font-playfair text-2xl md:text-3xl font-bold text-white leading-tight mb-4">
                From India to Verona — Reaching Everywhere
              </h3>
              <p className="text-white/70 leading-relaxed mb-8">
                Marmomac is where GajBala Group connects with the global stone community —
                meet us on the floor to discuss distribution, projects and partnerships.
              </p>
              <LuxuryButton variant="primary" icon={FiArrowRight} onClick={() => navigate('/contact')}>
                Schedule a Meeting at Marmomac
              </LuxuryButton>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative z-10"
            >
              <TiltCard strength={5} glare={false} className="rounded-[20px] overflow-hidden shadow-xl shadow-black/30">
                <img
                  src="/Images/stock/airplane-global.jpg"
                  alt="GajBala Group global reach"
                  className="w-full h-[280px] md:h-[320px] object-cover"
                  loading="lazy"
                />
              </TiltCard>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  )
}
