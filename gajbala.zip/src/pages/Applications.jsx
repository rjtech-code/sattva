import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import TiltCard from '../components/ui/TiltCard'
import { applications } from '../data/applications'

export default function Applications() {
  const navigate = useNavigate()

  return (
    <>
      <SEO
        title="Flexible Stone Veneer Applications | Cladding, Walls & Curved Surfaces"
        description="See how GajBala Group's ultra-thin flexible stone veneer is used across hospitality lobbies, residential feature walls, outdoor cladding and curved architectural surfaces worldwide."
        canonical="/applications"
      />
      <PageHeader
        title="Applications"
        subtitle="Discover how our natural stone solutions enhance diverse architectural projects."
        bgImage="/Images/drive/bookmatch.jpg"
      />

      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          {/* Section Header */}
          <div className="text-center max-w-2xl mx-auto mb-16 lg:mb-20">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              Industry Applications
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-4"
            >
              Built for Every Architectural Project
            </motion.h2>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto"
            />
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.25 }}
              className="text-light text-base sm:text-lg mt-6"
            >
              From private residences to hospitality landmarks, GajBala natural stone surfaces adapt
              to every project scale and design vision.
            </motion.p>
          </div>

          {/* Applications Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {applications.map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: (i % 3) * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
              >
                <TiltCard
                  strength={5}
                  whileHover={{ y: -6 }}
                  transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                  className="group premium-card overflow-hidden h-full flex flex-col cursor-pointer"
                  onClick={() => navigate(`/applications/${item.slug}`)}
                >
                  <div className="sweep" />
                  <div className="premium-card-glow" />
                  {/* Image */}
                  <div className="relative image-zoom overflow-hidden">
                    <img
                      src={item.image}
                      alt={`${item.title} - GajBala Group natural stone applications`}
                      className="w-full h-56 object-cover"
                      loading="lazy"
                    />
                    <span className="absolute top-5 left-5 inline-flex items-center justify-center px-3 py-1 rounded-full bg-black/40 backdrop-blur-sm border border-white/30 text-white text-xs uppercase tracking-[0.2em] font-bold">
                      {item.number}
                    </span>
                  </div>

                  {/* Content */}
                  <div className="relative z-10 p-8 flex flex-col gap-3 flex-1">
                    <div className="green-divider !my-0 !mb-1" />
                    <h3 className="premium-card-title font-playfair text-xl font-bold text-dark">
                      {item.title}
                    </h3>
                    <p className="premium-card-description text-sm text-light leading-relaxed flex-1">
                      {item.desc}
                    </p>
                    <span className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-[0.08em] text-primary transition-all duration-300 group-hover:gap-3">
                      View Details <FiArrowRight />
                    </span>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-center mt-16"
          >
            <LuxuryButton
              variant="primary"
              size="lg"
              icon={FiArrowRight}
              onClick={() => navigate('/contact')}
            >
              Discuss Your Project
            </LuxuryButton>
          </motion.div>
        </div>
      </section>
    </>
  )
}
