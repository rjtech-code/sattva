import { motion } from "framer-motion";
import {
  FiArrowRight,
  FiTarget,
  FiEye,
  FiAward,
  FiShield,
  FiUsers,
  FiGlobe,
  FiTool,
  FiBox,
  FiDroplet,
  FiCheck,
} from "react-icons/fi";
import { GiEcology, GiFlexibleStar } from "react-icons/gi";
import { useNavigate } from "react-router-dom";
import SEO from "../components/SEO";
import LuxuryButton from "../components/ui/LuxuryButton";
import TiltCard from "../components/ui/TiltCard";
import {
  aboutIntro,
  purpose,
  goals,
  partnerReasons,
  company,
} from "../data/companyContent";


const values = [
  {
    icon: FiAward,
    title: "Unmatched Quality",
    desc: "Unrivalled product quality and craftsmanship across every design, type, colour and finish.",
    image: "/Images/stock/welding-craftsmanship.jpg",
  },
  {
    icon: GiFlexibleStar,
    title: "Open Innovation",
    desc: "Continuous investment in R&D to develop cutting-edge stone technologies and manufacturing processes.",
    image: "/Images/stock/lab-research.jpg",
  },
  {
    icon: FiShield,
    title: "Integrity",
    desc: "Transparent business practices, ethical sourcing, and honest relationships with clients and partners.",
    image: "/Images/stock/handshake.jpg",
  },
  {
    icon: GiEcology,
    title: "Open Future",
    desc: "Sustainable solutions for tomorrow — Go Global, Go Green, Go Gajbala.",
    image: "/Images/stock/leaf-1.jpg",
  },
  {
    icon: FiUsers,
    title: "Honest Service",
    desc: "Flawless execution and honest customer service that brings delight to customers and their projects.",
    image: "/Images/stock/team-collaboration.jpg",
  },
  {
    icon: FiGlobe,
    title: "Global Standards",
    desc: "Adhering to international quality benchmarks and compliance standards for global market leadership.",
    image: "/Images/stock/airplane-global.jpg",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  visible: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      delay: i * 0.1,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  }),
};

export default function About() {
  const navigate = useNavigate();

  return (
    <>
      <SEO
        title="About GajBala Group | Natural Stone Veneer Manufacturer India"
        description="Since 2003, GajBala Group has grown into a 500,000 sq. ft. flexible stone veneer manufacturing facility in Jaipur, India — led by Chairman Mr. Shyam Somani with a mission to reach every corner of the globe."
        canonical="/about"
      />
      <section className="relative overflow-hidden pt-[130px] pb-16 md:pt-[150px] md:pb-20">
        <div className="absolute inset-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url('/Images/pdf-assets/veneer-rolls.jpg')`,
              filter: "brightness(0.45) saturate(1.1)",
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-dark/70 via-dark/40 to-dark/30" />
        </div>

        <div className="container-luxury relative z-10 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-3xl"
          >
            <nav className="flex items-center gap-2 text-sm text-white/50 mb-6 font-body">
              <a
                href="/"
                className="hover:text-primary-light transition-colors"
              >
                Home
              </a>
              <span>/</span>
              <span className="text-white/80">About Us</span>
            </nav>

            <span className="inline-block px-4 py-1.5 rounded-full bg-white/10 border border-white/10 text-white/70 text-xs font-medium tracking-widest uppercase mb-5">
              GajBala Group
            </span>

            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-[0.95] [text-shadow:0_4px_24px_rgba(0,0,0,0.35)]">
              {aboutIntro.headline}
            </h1>

            <p className="text-base md:text-lg text-white/70 mt-4 max-w-xl font-body font-light leading-relaxed">
              {company.industryTagline}. Led by {company.chairman.name} with a
              mission — Reaching Everywhere.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Who We Are */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="relative"
            >
              <TiltCard
                strength={5}
                glare={false}
                className="image-zoom rounded-[20px] shadow-lg shadow-black/10"
              >
                <img
                  src="/Images/pdf-assets/quarry.jpg"
                  alt="GajBala Group — natural stone sourcing"
                  className="w-full h-[500px] lg:h-[580px] object-cover rounded-[20px]"
                  loading="lazy"
                />
              </TiltCard>
            </motion.div>

            <div>
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="section-subtitle"
              >
                Who We Are
              </motion.span>

              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4"
              >
                Opening the Future of the Global E-Ston Industry
              </motion.h2>

              <div className="green-divider" />

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-light text-base sm:text-lg leading-relaxed mb-5"
              >
                Since 2014, GajBala Group has grown into a 500,000 sq. ft.
                manufacturing powerhouse — delivering unmatched quality and
                craftsmanship to clients worldwide.
              </motion.p>

              <LuxuryButton
                variant="primary"
                size="lg"
                icon={FiArrowRight}
                onClick={() => navigate("/products")}
              >
                Explore Our Products
              </LuxuryButton>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="section-padding bg-primary-dark relative overflow-hidden">
        <div className="absolute inset-0 marble-texture opacity-10 z-0" />
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <span className="section-subtitle !text-primary-light">
              Leading the Open Era
            </span>
            <h2 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
              Vision to Reach Everywhere
            </h2>
            <div className="green-divider mx-auto mb-6" />
            <p className="text-base md:text-lg text-white/75 leading-relaxed">
              {company.chairman.vision}
            </p>
          </div>
        </div>
      </section>

      {/* Purpose & Goals */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-12">
            <TiltCard strength={6} className="premium-card h-full p-10 lg:p-12">
              <div className="premium-card-glow" />
              <div className="relative z-10">
                <div className="premium-card-icon w-16 h-16 rounded-[16px] bg-[#7A7A7A]/10 flex items-center justify-center mb-6">
                  <FiTarget className="text-2xl" style={{ color: "#7A7A7A" }} />
                </div>
                <h3 className="premium-card-title font-heading text-2xl font-bold text-[#1B5E20] mb-4">
                  {purpose.title}
                </h3>
                <p className="premium-card-description text-base text-[#555555] leading-relaxed">
                  {purpose.statement}
                </p>
              </div>
            </TiltCard>

            <TiltCard strength={6} className="premium-card h-full p-10 lg:p-12">
              <div className="premium-card-glow" />
              <div className="relative z-10">
                <div className="premium-card-icon w-16 h-16 rounded-[16px] bg-[#7A7A7A]/10 flex items-center justify-center mb-6">
                  <FiEye className="text-2xl" style={{ color: "#7A7A7A" }} />
                </div>
                <h3 className="premium-card-title font-heading text-2xl font-bold text-[#1B5E20] mb-4">
                  Our Goals
                </h3>
                <ul className="space-y-3">
                  {goals.map((g) => (
                    <li key={g.title} className="flex items-start gap-3">
                      <FiCheck className="text-primary mt-1 flex-shrink-0" />
                      <div>
                        <div className="font-semibold text-dark">{g.title}</div>
                        <div className="text-sm text-[#555555]">{g.desc}</div>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </TiltCard>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-padding bg-bg relative overflow-hidden">
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="section-subtitle">Our Values</span>
            <h2 className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4">
              The Principles That Guide Us
            </h2>
            <div className="green-divider mx-auto" />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {values.map((val, i) => (
              <motion.div
                key={val.title}
                custom={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                className="group"
              >
                <TiltCard
                  strength={7}
                  className="premium-card overflow-hidden h-full flex flex-col"
                >
                  <div className="premium-card-glow" />
                  <div className="sweep" />
                  <div className="relative image-zoom overflow-hidden">
                    <img
                      src={val.image}
                      alt={`${val.title} - GajBala Group`}
                      className="w-full h-32 object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="relative z-10 p-6 lg:p-8 flex-1 flex flex-col">
                    <div className="premium-card-icon w-12 h-12 rounded-[14px] bg-[#7A7A7A]/10 flex items-center justify-center -mt-10 mb-4 bg-white shadow-md">
                      <val.icon
                        className="text-xl"
                        style={{ color: "#7A7A7A" }}
                      />
                    </div>
                    <h3 className="premium-card-title font-heading text-xl font-bold text-[#1B5E20] mb-3">
                      {val.title}
                    </h3>
                    <p className="premium-card-description text-sm text-[#555555] leading-relaxed">
                      {val.desc}
                    </p>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Partner */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="section-subtitle">Why Clients Trust Us</span>
            <h2 className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4">
              Why Partner With The Future Developer Of Flexible Stone Veneer In
              India?
            </h2>
            <div className="green-divider mx-auto" />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 lg:gap-4">
            {partnerReasons.map((card, i) => (
              <motion.div
                key={card.title}
                custom={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
              >
                <TiltCard
                  strength={7}
                  className="premium-card h-full p-4 text-center"
                >
                  <div className="premium-card-glow" />
                  <div className="sweep" />
                  <div className="relative z-10">
                    <h3 className="premium-card-title font-heading text-xs sm:text-sm font-bold text-[#1B5E20] leading-snug">
                      {card.title}
                    </h3>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Manufacturing overview */}
      <section className="section-padding bg-bg relative overflow-hidden">
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <TiltCard
              strength={5}
              glare={false}
              className="image-zoom rounded-[20px] shadow-lg shadow-black/10"
            >
              <img
                src="/Images/pdf-assets/manufacturing-process.jpg"
                alt="GajBala manufacturing facility"
                className="w-full h-[450px] lg:h-[520px] object-cover rounded-[20px]"
                loading="lazy"
              />
            </TiltCard>

            <div>
              <span className="section-subtitle">Manufacturing Overview</span>
              <h2 className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4">
                Where Craftsmanship Meets Process Excellence
              </h2>
              <div className="green-divider" />
              <p className="text-light text-base sm:text-lg leading-relaxed mb-8">
                Gajbala Group is an organization dedicated to developing India’s
                top-quality E-Ston products and supplying them globally, driven
                by a core mission of "Reaching Everywhere". The organization is
                focused on building the world’s most open, innovative, and
                collaborative E-Ston Industry Ecosystem to empower partners,
                dealers, architects, and builders worldwide.
              </p>

              <div className="grid grid-cols-2 gap-4 mb-10">
                {[
                  {
                    icon: FiTool,
                    label: "Superior Machinery",
                    sub: "Dedicated process stages",
                  },
                  {
                    icon: FiCheck,
                    label: "Defined Systems",
                    sub: "Quality at every step",
                  },
                  {
                    icon: FiBox,
                    label: "Custom Orders",
                    sub: "Designs, colours & finishes",
                  },
                  {
                    icon: FiDroplet,
                    label: "Skilled Manpower",
                    sub: "Craftsmanship & care",
                  },
                ].map((item) => (
                  <div
                    key={item.label}
                    className="flex items-center gap-3 p-4 rounded-[14px] bg-white border border-border"
                  >
                    <div className="w-9 h-9 rounded-[10px] bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <item.icon className="text-sm text-primary" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-dark">
                        {item.label}
                      </div>
                      <div className="text-[11px] text-light">{item.sub}</div>
                    </div>
                  </div>
                ))}
              </div>

              <LuxuryButton
                variant="outline"
                icon={FiArrowRight}
                onClick={() => navigate("/manufacturing")}
              >
                Explore Manufacturing
              </LuxuryButton>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
