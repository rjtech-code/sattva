import SEO from "../components/SEO";
import Hero from "../components/sections/Hero";
import MarmomacPreview from "../components/sections/MarmomacPreview";
import EstonPreview from "../components/sections/EstonPreview";
import AboutSection from "../components/sections/AboutSection";
import OurBusinesses from "../components/sections/OurBusinesses";
import WhyChooseUs from "../components/sections/WhyChooseUs";
import ProductAdvantages from "../components/sections/ProductAdvantages";
import ProductSection from "../components/sections/ProductSection";
import ContactPreview from "../components/sections/ContactPreview";

export default function Home() {
  return (
    <>
      <SEO
        title="Flexible Stone Veneer Manufacturer & Exporter in India"
        description="GajBala Group manufactures and exports ultra-thin flexible natural stone veneer (E-Ston) from Jaipur, India — Flexoera, Onyxoera, Decoera, Artoera, Walloera & Designoera collections for architects, builders and distributors worldwide."
        canonical="/"
      />
      <Hero />
      <MarmomacPreview />
      <EstonPreview />
      <AboutSection />
      <OurBusinesses />
      <WhyChooseUs />
      <ProductSection />
      <ProductAdvantages />
      <ContactPreview />
    </>
  );
}
