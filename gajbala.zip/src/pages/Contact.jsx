import { useState } from 'react'
import { motion } from 'framer-motion'
import { FiMapPin, FiPhone, FiMail, FiGlobe, FiArrowRight, FiCheck } from 'react-icons/fi'
import { FaLinkedinIn, FaFacebookF, FaInstagram, FaWhatsapp, FaYoutube } from 'react-icons/fa'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'

const initialFormState = {
  name: '',
  company: '',
  email: '',
  phone: '',
  subject: '',
  message: '',
}

const contactInfo = [
  {
    icon: FiMapPin,
    title: 'Company',
    info: 'GajBala Universe Pvt Ltd — Global Export Division',
    link: '#',
  },
  {
    icon: FiPhone,
    title: 'Phone Number',
    info: '+91 81406 79999',
    link: 'tel:+918140679999',
  },
  {
    icon: FaWhatsapp,
    title: 'WhatsApp',
    info: '+91 81406 79999',
    link: 'https://wa.me/918140679999',
  },
  {
    icon: FiMail,
    title: 'Email Address',
    info: 'office@gajbalagroup.com',
    link: 'mailto:office@gajbalagroup.com',
  },
  {
    icon: FiGlobe,
    title: 'Website',
    info: 'www.gajbalagroup.com',
    link: 'https://www.gajbalagroup.com',
  },
]

const businessHours = [
  { day: 'Monday - Friday', time: '9:00 AM - 6:00 PM' },
  { day: 'Saturday', time: '9:00 AM - 2:00 PM' },
  { day: 'Sunday', time: 'Closed' },
]

export default function Contact() {
  const [formData, setFormData] = useState(initialFormState)
  const [status, setStatus] = useState('idle') // idle | submitting | success | error

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('submitting')
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })
      if (!res.ok) throw new Error('Request failed')
      setStatus('success')
      setFormData(initialFormState)
    } catch {
      setStatus('error')
    }
  }

  return (
    <>
      <SEO
        title="Contact GajBala Group | Stone Veneer Manufacturer in Jaipur, India"
        description="Get in touch with GajBala Group for flexible stone veneer enquiries — importers, distributors, architects, builders and project developers welcome. Manufacturing & export from Jaipur, Rajasthan, India."
        canonical="/contact"
      />
      {/* Hero Banner */}
      <section className="relative overflow-hidden pt-[150px] pb-16 md:pt-[170px] md:pb-20 flex items-center">
        {/* Background Image */}
        <div className="absolute inset-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url('/Images/drive/app5.jpg')`,
            }}
          />
          {/* Dark overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-black/70 via-black/60 to-black/70" />
        </div>

        {/* Breadcrumb */}
        <div className="absolute top-24 left-0 right-0 z-20">
          <div className="container-luxury max-w-[1400px]">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex items-center gap-2 text-sm"
            >
              <a href="/" className="text-white/70 hover:text-white transition-colors">Home</a>
              <span className="text-white/50">/</span>
              <span className="text-white">Contact</span>
            </motion.div>
          </div>
        </div>

        {/* Hero Content */}
        <div className="relative z-10 w-full">
          <div className="container-luxury max-w-[1400px]">
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="max-w-3xl"
            >
              {/* Label */}
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="inline-block text-xs font-semibold tracking-[0.3em] uppercase text-primary mb-6"
              >
                Contact Us
              </motion.span>

              {/* Heading */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.4 }}
                className="font-playfair text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight mb-6 [text-shadow:0_4px_24px_rgba(0,0,0,0.35)]"
              >
                Let's Connect
              </motion.h1>

              {/* Divider */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.5 }}
                className="w-16 h-1 bg-primary mb-6"
              />

              {/* Description */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="text-white/80 text-lg md:text-xl leading-relaxed max-w-2xl"
              >
                Have a question or want to discuss a project? We welcome enquiries from importers,
                distributors, architects & builders, project developers, and technology partners.
              </motion.p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Main Contact Layout */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            {/* Left Column - Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
              <h2 className="font-playfair text-3xl md:text-4xl font-bold text-dark mb-4">
                Contact Information
              </h2>
              <div className="w-16 h-1 bg-primary mb-8" />
              <p className="text-light text-base leading-relaxed mb-10">
                Reach out to us through any of the following channels. We strive to respond to all inquiries within 24 hours.
              </p>

              {/* Contact Cards Grid */}
              <div className="grid sm:grid-cols-2 gap-6">
                {contactInfo.map((item, index) => (
                  <motion.a
                    key={item.title}
                    href={item.link}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ 
                      y: -6,
                      transition: { duration: 0.3, ease: 'easeOut' }
                    }}
                    className="group relative bg-white rounded-2xl p-6 shadow-md shadow-black/5 
                              border border-gray-100 hover:shadow-xl hover:shadow-primary/10 
                              hover:border-primary/20 transition-all duration-500"
                  >
                    <div className="relative z-10">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4
                                  group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                        <item.icon className="text-primary text-xl group-hover:text-white transition-colors duration-300" />
                      </div>
                      <h3 className="font-heading text-base font-bold text-dark mb-2 group-hover:text-primary transition-colors duration-300">
                        {item.title}
                      </h3>
                      <p className="text-sm text-light leading-relaxed">
                        {item.info}
                      </p>
                    </div>
                  </motion.a>
                ))}
              </div>

              {/* Social Links */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.6 }}
                className="mt-10"
              >
                <h3 className="font-heading text-lg font-bold text-dark mb-4">Follow Us</h3>
                <div className="flex items-center gap-3">
                  {[
                    { icon: FaLinkedinIn, label: 'LinkedIn', href: '#' },
                    { icon: FaFacebookF, label: 'Facebook', href: '#' },
                    { icon: FaInstagram, label: 'Instagram', href: '#' },
                    { icon: FaYoutube, label: 'YouTube', href: '#' },
                  ].map((social) => (
                    <a
                      key={social.label}
                      href={social.href}
                      aria-label={social.label}
                      className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center
                                text-primary hover:bg-primary hover:text-white transition-all duration-300"
                    >
                      <social.icon size={16} />
                    </a>
                  ))}
                </div>
              </motion.div>
            </motion.div>

            {/* Right Column - Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
              <div className="bg-white rounded-[24px] p-8 md:p-10 shadow-xl shadow-black/5 border border-gray-100">
                <h2 className="font-playfair text-3xl font-bold text-dark mb-2">
                  Send Us a Message
                </h2>
                <div className="w-16 h-1 bg-primary mb-6" />
                <p className="text-light text-base mb-8">
                  Fill out the form below and we'll get back to you shortly.
                </p>

                {status === 'success' ? (
                  <div className="rounded-2xl bg-primary/5 border border-primary/20 p-8 text-center">
                    <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <FiCheck className="text-2xl text-primary" />
                    </div>
                    <h3 className="font-heading text-xl font-bold text-dark mb-2">Message Sent</h3>
                    <p className="text-light text-sm leading-relaxed mb-6">
                      Thanks for reaching out — our team will get back to you shortly.
                    </p>
                    <LuxuryButton variant="outline" onClick={() => setStatus('idle')}>
                      Send Another Message
                    </LuxuryButton>
                  </div>
                ) : (
                <form className="space-y-6" onSubmit={handleSubmit}>
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-dark mb-2">
                        Full Name <span className="text-primary">*</span>
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                  focus:ring-primary/20 outline-none transition-all duration-300"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-dark mb-2">
                        Company Name
                      </label>
                      <input
                        type="text"
                        name="company"
                        value={formData.company}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                  focus:ring-primary/20 outline-none transition-all duration-300"
                        placeholder="Your Company"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-dark mb-2">
                        Email Address <span className="text-primary">*</span>
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                  focus:ring-primary/20 outline-none transition-all duration-300"
                        placeholder="you@example.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-dark mb-2">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                  focus:ring-primary/20 outline-none transition-all duration-300"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-dark mb-2">
                      Subject <span className="text-primary">*</span>
                    </label>
                    <input
                      type="text"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                focus:ring-primary/20 outline-none transition-all duration-300"
                      placeholder="How can we help you?"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-dark mb-2">
                      Message <span className="text-primary">*</span>
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      required
                      rows="5"
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                focus:ring-primary/20 outline-none transition-all duration-300 resize-none"
                      placeholder="Tell us about your project or inquiry..."
                    />
                  </div>

                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      id="agree"
                      required
                      className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
                    />
                    <label htmlFor="agree" className="text-sm text-light leading-relaxed">
                      I agree to be contacted regarding my inquiry and accept the privacy policy.
                    </label>
                  </div>

                  {status === 'error' && (
                    <p className="text-sm text-red-600">
                      Something went wrong sending your message. Please try again.
                    </p>
                  )}

                  <LuxuryButton
                    variant="primary"
                    size="lg"
                    icon={FiArrowRight}
                    type="submit"
                    disabled={status === 'submitting'}
                    className="w-full sm:w-auto"
                  >
                    {status === 'submitting' ? 'Sending...' : 'Send Inquiry'}
                  </LuxuryButton>
                </form>
                )}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Map & Business Info Section */}
      <section className="section-padding bg-bg">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Map Placeholder */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="bg-white rounded-[20px] shadow-lg shadow-black/5 border border-gray-100 overflow-hidden h-[400px]"
            >
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4096.431074306638!2d75.76548770824955!3d26.88970854707642!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db56e20d6b34f%3A0x5a82592f93402a8a!2sGajBala%20Eco%20Friendly%20Pvt%20Ltd!5e0!3m2!1sen!2sin!4v1789199705685!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="strict-origin-when-cross-origin"
                title="GajBala Group location on Google Maps"
                className="w-full h-full"
              />
            </motion.div>

            {/* Business Info Cards */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="flex flex-col justify-center gap-6"
            >
              {[
                {
                  title: 'Business Hours',
                  content: (
                    <ul className="space-y-2">
                      {businessHours.map((schedule) => (
                        <li key={schedule.day} className="flex justify-between text-sm">
                          <span className="text-light">{schedule.day}</span>
                          <span className="text-dark font-medium">{schedule.time}</span>
                        </li>
                      ))}
                    </ul>
                  ),
                },
                {
                  title: 'Quick Response Time',
                  content: (
                    <p className="text-sm text-light leading-relaxed">
                      We aim to respond to all inquiries within 24 hours during business days. 
                      Urgent inquiries are prioritized for faster response.
                    </p>
                  ),
                },
                {
                  title: 'Export Support',
                  content: (
                    <p className="text-sm text-light leading-relaxed">
                      Dedicated export inquiry channel for international clients. 
                      Support for documentation, shipping, and logistics coordination.
                    </p>
                  ),
                },
              ].map((info) => (
                <div
                  key={info.title}
                  className="bg-white rounded-2xl p-6 shadow-md shadow-black/5 border border-gray-100"
                >
                  <h3 className="font-heading text-lg font-bold text-dark mb-3">
                    {info.title}
                  </h3>
                  {info.content}
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="relative py-20 md:py-24 overflow-hidden">
        {/* Subtle marble texture background */}
        <div className="absolute inset-0 bg-white" />
        <div className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `radial-gradient(circle at 50% 50%, #1B5E20 0%, transparent 70%)`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary-dark/5" />

        <div className="container-luxury max-w-[1400px] relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="max-w-3xl mx-auto text-center"
          >
            <h2 className="font-playfair text-3xl md:text-4xl font-bold text-dark leading-tight mb-6">
              Have a Project or Business Inquiry?
            </h2>
            <div className="w-16 h-1 bg-primary mx-auto mb-8" />
            <p className="text-light text-base md:text-lg leading-relaxed mb-10 max-w-2xl mx-auto">
              Our team of experts is ready to discuss your requirements and provide tailored solutions 
              for your business needs.
            </p>
            <LuxuryButton
              variant="primary"
              size="lg"
              icon={FiArrowRight}
              onClick={() => window.location.href = '/contact'}
            >
              Contact Our Team
            </LuxuryButton>
          </motion.div>
        </div>
      </section>
    </>
  )
}