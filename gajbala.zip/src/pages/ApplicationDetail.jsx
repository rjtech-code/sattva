import { useParams, useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiArrowLeft, FiArrowRight, FiCheck } from 'react-icons/fi'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import { applications } from '../data/applications'
import { collectionsInfo } from '../data/collectionsInfo'
import { productCatalog } from '../data/productCatalog'
import { SITE_URL } from '../data/seoConfig'

export default function ApplicationDetail() {
  const { slug } = useParams()
  const navigate = useNavigate()

  const index = applications.findIndex((a) => a.slug === slug)
  const app = applications[index]

  if (!app) {
    return (
      <div className="section-padding text-center pt-32">
        <h2 className="section-title mb-4">Application not found</h2>
        <LuxuryButton variant="primary" onClick={() => navigate('/applications')}>
          Back to Applications
        </LuxuryButton>
      </div>
    )
  }

  const prev = applications[(index - 1 + applications.length) % applications.length]
  const next = applications[(index + 1) % applications.length]
  const more = applications.filter((a) => a.slug !== app.slug).slice(0, 3)

  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
      { '@type': 'ListItem', position: 2, name: 'Applications', item: `${SITE_URL}/applications` },
      { '@type': 'ListItem', position: 3, name: app.title, item: `${SITE_URL}/applications/${app.slug}` },
    ],
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={`${app.title} | Flexible Stone Veneer Application`}
        description={(app.longDesc || app.desc || '').slice(0, 157)}
        canonical={`/applications/${app.slug}`}
        image={app.image}
        jsonLd={breadcrumbSchema}
      />
      {/* Breadcrumb bar */}
      <div className="border-b border-gray-100 bg-bg pt-24">
        <div className="container-luxury max-w-[1300px] py-4 flex items-center gap-4">
          <button
            onClick={() => (window.history.length > 2 ? navigate(-1) : navigate('/applications'))}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-dark hover:text-primary transition-colors flex-shrink-0"
          >
            <FiArrowLeft /> Back
          </button>
          <span className="text-gray-200">|</span>
          <nav className="flex items-center flex-wrap gap-2 text-xs sm:text-sm text-light">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <span>/</span>
            <Link to="/applications" className="hover:text-primary transition-colors">Applications</Link>
            <span>/</span>
            <span className="text-primary font-semibold">{app.title}</span>
          </nav>
        </div>
      </div>

      {/* Hero: image + info */}
      <section className="section-padding !pb-8">
        <div className="container-luxury max-w-[1300px]">
          <div className="grid lg:grid-cols-[1.15fr_1fr] gap-10 lg:gap-16 items-start">
            {/* Image */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="min-w-0"
            >
              <div className="relative rounded-[20px] overflow-hidden shadow-xl shadow-black/10">
                <img
                  src={app.image}
                  alt={`${app.title} - GajBala Group natural stone applications`}
                  className="w-full h-[380px] sm:h-[460px] lg:h-[560px] object-cover"
                />
                <span className="absolute top-5 left-5 inline-flex items-center justify-center px-3 py-1 rounded-full bg-black/40 backdrop-blur-sm border border-white/30 text-white text-xs uppercase tracking-[0.2em] font-bold">
                  {app.number}
                </span>
              </div>

              {/* Prev/Next */}
              <div className="flex items-center justify-between mt-4">
                <Link
                  to={`/applications/${prev.slug}`}
                  className="text-xs sm:text-sm text-light hover:text-primary transition-colors flex items-center gap-1"
                >
                  <FiArrowLeft /> {prev.title}
                </Link>
                <span className="text-xs text-light/60">
                  {index + 1} / {applications.length}
                </span>
                <Link
                  to={`/applications/${next.slug}`}
                  className="text-xs sm:text-sm text-light hover:text-primary transition-colors flex items-center gap-1"
                >
                  {next.title} <FiArrowRight />
                </Link>
              </div>
            </motion.div>

            {/* Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <span className="section-subtitle">Application</span>
              <h1 className="font-playfair text-3xl md:text-4xl font-bold text-dark mt-2 mb-4">
                {app.title}
              </h1>
              <div className="green-divider mb-6" />
              <p className="text-light text-base md:text-lg leading-relaxed mb-8">
                {app.longDesc || app.desc}
              </p>

              {app.highlights && app.highlights.length > 0 && (
                <ul className="space-y-3 mb-8">
                  {app.highlights.map((line) => (
                    <li key={line} className="flex items-start gap-2 text-sm text-light">
                      <FiCheck className="text-primary flex-shrink-0 mt-0.5" /> {line}
                    </li>
                  ))}
                </ul>
              )}

              <div className="flex flex-wrap gap-4">
                <LuxuryButton variant="primary" size="lg" onClick={() => navigate('/contact')}>
                  Discuss Your Project
                </LuxuryButton>
                <LuxuryButton variant="outline" size="lg" onClick={() => navigate('/applications')}>
                  View All Applications
                </LuxuryButton>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Recommended finishes */}
      {app.recommended && app.recommended.length > 0 && (
        <section className="section-padding bg-bg">
          <div className="container-luxury max-w-[1300px]">
            <div className="text-center max-w-xl mx-auto mb-10">
              <span className="section-subtitle">Recommended Finishes</span>
              <h2 className="section-title mb-4">Collections That Work Here</h2>
              <div className="green-divider mx-auto" />
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
              {app.recommended.map((key, i) => {
                const info = collectionsInfo[key]
                const items = productCatalog[key] || []
                const thumb = items[0]?.src
                if (!info || !thumb) return null
                return (
                  <motion.div
                    key={key}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: '-50px' }}
                    transition={{ duration: 0.5, delay: i * 0.08 }}
                    className="group relative rounded-[16px] overflow-hidden h-[200px] cursor-pointer"
                    onClick={() => navigate('/products')}
                  >
                    <img
                      src={thumb}
                      alt={info.title}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent flex items-end p-4">
                      <div>
                        <span className="text-white text-sm font-semibold block">{info.title}</span>
                        <span className="text-white/70 text-xs">{info.tagline}</span>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>
      )}

      {/* More applications */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1300px]">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="section-subtitle">Explore More</span>
            <h2 className="section-title mb-4">More Applications</h2>
            <div className="green-divider mx-auto" />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {more.map((item, i) => (
              <motion.div
                key={item.slug}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group relative rounded-[16px] overflow-hidden h-[220px] cursor-pointer"
                onClick={() => navigate(`/applications/${item.slug}`)}
              >
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent flex items-end p-4">
                  <span className="text-white text-sm font-semibold">{item.title}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
