import { motion } from 'framer-motion'
import { FiCheck, FiArrowRight } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import TiltCard from '../components/ui/TiltCard'
import {
  aboutIntro,
  installationSteps,
  backingInfo,
  productProperties,
} from '../data/companyContent'

export default function ManufacturingPage() {
  const navigate = useNavigate()

  return (
    <>
      <SEO
        title="Manufacturing Process | Flexible Stone Veneer Production India"
        description="Inside GajBala Group's flexible stone veneer manufacturing facility in Jaipur, India — from raw stone extraction and ultra-thin slicing to fiberglass-resin backing and quality-controlled finishing."
        canonical="/manufacturing"
      />
      <PageHeader
        title="Manufacturing"
        subtitle="State-of-the-art production with dedicated stages, superior machinery, and clearly defined systems."
        bgImage="/Images/pdf-assets/manufacturing-process.jpg"
      />

      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <span className="section-subtitle">Operational Excellence</span>
              <h2 className="section-title mb-6">Our Manufacturing Plant</h2>
              <div className="green-divider" />
              <p className="text-light text-lg leading-relaxed mb-5">{aboutIntro.paragraphs[1]}</p>
              <p className="text-light text-lg leading-relaxed mb-8">{aboutIntro.paragraphs[2]}</p>
              <LuxuryButton variant="primary" icon={FiArrowRight} onClick={() => navigate('/partner')}>
                Schedule a Factory Visit
              </LuxuryButton>
            </motion.div>

            <div className="grid grid-cols-2 gap-4">
              <img
                src="/Images/pdf-assets/manufacturing-process.jpg"
                alt="Flexible stone veneer manufacturing"
                className="rounded-[20px] h-56 object-cover w-full shadow-md"
                loading="lazy"
              />
              <img
                src="/Images/pdf-assets/flexible-demo.jpg"
                alt="Flexible stone veneer demonstration"
                className="rounded-[20px] h-56 object-cover w-full shadow-md mt-8"
                loading="lazy"
              />
              <img
                src="/Images/pdf-assets/veneer-rolls.jpg"
                alt="Natural stone veneer rolls"
                className="rounded-[20px] h-56 object-cover w-full shadow-md col-span-2"
                loading="lazy"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-bg">
        <div className="container-luxury max-w-[1400px]">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="section-subtitle">Product Properties</span>
            <h2 className="section-title mb-4">Engineered for Performance</h2>
            <div className="green-divider mx-auto" />
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {productProperties.map((prop) => (
              <TiltCard key={prop.title} className="premium-card p-8 h-full">
                <div className="premium-card-glow" />
                <div className="relative z-10">
                  <h3 className="premium-card-title font-heading text-xl font-bold mb-3">{prop.title}</h3>
                  <p className="premium-card-description text-sm leading-relaxed">{prop.desc}</p>
                </div>
              </TiltCard>
            ))}
          </div>
        </div>
      </section>

      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <span className="section-subtitle">Backing Options</span>
              <h2 className="section-title mb-6">Compatible Substrates</h2>
              <div className="green-divider" />
              <p className="text-light leading-relaxed mb-6">
                Our natural stone veneer laminates come in several finishes like{' '}
                {backingInfo.finishes.join(', ')}. Thin slate stone can be applied to a wide range of
                substrates.
              </p>
              <div className="flex flex-wrap gap-2">
                {backingInfo.substrates.map((s) => (
                  <span
                    key={s}
                    className="px-3 py-1.5 rounded-full bg-primary/5 border border-primary/10 text-sm text-dark"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <span className="section-subtitle">Buyer Advantage</span>
              <h2 className="section-title mb-6">See It First-Hand</h2>
              <div className="green-divider" />
              <p className="text-light leading-relaxed mb-4">
                Factory visits are welcome — we encourage buyers to see our operations first-hand.
                You also get complete after-sales support and installation support.
              </p>
              <ul className="space-y-3">
                {[
                  'Dedicated production stages for every process',
                  'Superior machinery with skilled manpower',
                  'Multiple designs, types, colours and finishes',
                  'After-sales & installation guidance',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-dark/80">
                    <FiCheck className="text-primary mt-1 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section-padding bg-bg">
        <div className="container-luxury max-w-[1400px]">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="section-subtitle">Installation Guidance</span>
            <h2 className="section-title mb-4">From Prep to Seal</h2>
            <div className="green-divider mx-auto" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {installationSteps.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
                className="rounded-[20px] bg-white border border-border p-7 shadow-sm"
              >
                <div className="text-xs font-bold tracking-[0.2em] uppercase text-primary mb-3">
                  Step {String(i + 1).padStart(2, '0')}
                </div>
                <h3 className="font-heading text-xl font-bold text-dark mb-4">{step.title}</h3>
                <ul className="space-y-3">
                  {step.points.map((point) => (
                    <li key={point.slice(0, 40)} className="text-sm text-light leading-relaxed flex gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
