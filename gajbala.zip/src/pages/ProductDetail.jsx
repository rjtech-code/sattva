import { lazy, Suspense, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FiArrowLeft, FiArrowRight, FiBox, FiImage, FiCheck } from 'react-icons/fi'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import { productCatalog } from '../data/productCatalog'
import { collectionsInfo } from '../data/collectionsInfo'
import { NO_ZOOM_KEYS } from '../data/catalogConstants'
import { SITE_URL, ORGANIZATION } from '../data/seoConfig'

const StoneSlab3D = lazy(() => import('../components/three/StoneSlab3D'))

const applications = [
  { title: 'Hospitality Lobbies', image: '/Images/drive/app5.jpg' },
  { title: 'Residential Feature Walls', image: '/Images/drive/app3.jpg' },
  { title: 'Outdoor & Poolside', image: '/Images/drive/app1.jpg' },
  { title: 'Living Spaces', image: '/Images/drive/app2.jpg' },
]

const SHOW_3D_TOGGLE = true
// "Where This Finish Works" applications section — temporarily hidden, flip
// to true to bring it back.
const SHOW_APPLICATIONS_SECTION = false

export default function ProductDetail() {
  const { collection, code } = useParams()
  const navigate = useNavigate()
  const [mode, setMode] = useState('3d') // '3d' | 'photo'

  const items = productCatalog[collection] || []
  const decodedCode = decodeURIComponent(code || '')
  const index = items.findIndex((i) => i.code === decodedCode)
  const product = items[index]
  const info = collectionsInfo[collection]

  if (!product) {
    return (
      <div className="section-padding text-center">
        <h2 className="section-title mb-4">Product not found</h2>
        <LuxuryButton variant="primary" onClick={() => navigate('/products')}>
          Back to Products
        </LuxuryButton>
      </div>
    )
  }

  const prev = items[(index - 1 + items.length) % items.length]
  const next = items[(index + 1) % items.length]

  const collectionTitle = info?.title || collection
  const canonicalPath = `/products/${collection}/${encodeURIComponent(product.code)}`
  const productSchema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: `${collectionTitle} ${product.code}`,
    sku: product.code,
    category: collectionTitle,
    description: info?.desc || `${collectionTitle} flexible stone veneer finish ${product.code} by GajBala Group.`,
    image: `${SITE_URL}${product.src}`,
    url: `${SITE_URL}${canonicalPath}`,
    brand: { '@type': 'Brand', name: 'GajBala Group' },
    manufacturer: { '@type': 'Organization', name: ORGANIZATION.legalName, url: ORGANIZATION.url },
  }
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
      { '@type': 'ListItem', position: 2, name: 'Products', item: `${SITE_URL}/products` },
      { '@type': 'ListItem', position: 3, name: collectionTitle, item: `${SITE_URL}/products/${collection}` },
      { '@type': 'ListItem', position: 4, name: product.code, item: `${SITE_URL}${canonicalPath}` },
    ],
  }

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title={`${product.code} — ${collectionTitle} Flexible Stone Veneer`}
        description={`${product.code} finish from the ${collectionTitle} collection — ${info?.tagline || 'flexible natural stone veneer'} by GajBala Group. ${info?.format || ''} ${info?.finish ? `· ${info.finish}` : ''}`.trim()}
        canonical={canonicalPath}
        image={product.src}
        jsonLd={[productSchema, breadcrumbSchema]}
      />
      {/* Breadcrumb bar */}
      <div className="border-b border-gray-100 bg-bg pt-24">
        <div className="container-luxury max-w-[1300px] py-4 flex items-center gap-4">
          <button
            onClick={() => (window.history.length > 2 ? navigate(-1) : navigate('/products'))}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-dark hover:text-primary transition-colors flex-shrink-0"
          >
            <FiArrowLeft /> Back
          </button>
          <span className="text-gray-200">|</span>
          <nav className="flex items-center flex-wrap gap-2 text-xs sm:text-sm text-light">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <span>/</span>
            <Link to="/products" className="hover:text-primary transition-colors">Products</Link>
            <span>/</span>
            <span className="text-dark font-medium">{info?.title || collection}</span>
            <span>/</span>
            <span className="text-primary font-semibold">{product.code}</span>
          </nav>
        </div>
      </div>

      {/* Hero: viewer + info */}
      <section className="section-padding !pb-8">
        <div className="container-luxury max-w-[1300px]">
          <div className="grid lg:grid-cols-[1.15fr_1fr] gap-10 lg:gap-16 items-start">
            {/* Viewer */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="min-w-0"
            >
              <div className="relative min-w-0">
                {mode === '3d' ? (
                  <Suspense
                    fallback={
                      <div className="w-full h-[380px] sm:h-[460px] lg:h-[560px] rounded-[20px] overflow-hidden shadow-xl shadow-black/10 bg-gradient-to-br from-[#f4f2ee] to-[#e6e2da] animate-pulse" aria-label="Loading 3D product viewer" />
                    }
                  >
                    <StoneSlab3D image={product.src} className="w-full h-[380px] sm:h-[460px] lg:h-[560px]" />
                  </Suspense>
                ) : (
                  <div className="w-full h-[380px] sm:h-[460px] lg:h-[560px] rounded-[20px] overflow-hidden shadow-xl shadow-black/10">
                    <img
                      src={product.src}
                      alt={`${info?.title || collection} ${product.code}`}
                      className="w-full h-full object-cover"
                      loading="eager"
                      decoding="async"
                      width={1200}
                      height={900}
                    />
                  </div>
                )}

                {SHOW_3D_TOGGLE && (
                  <>
                    {/* Mode toggle */}
                    <div className="absolute top-4 right-4 flex gap-2 bg-white/90 backdrop-blur-sm rounded-full p-1 shadow-md z-10">
                      <button
                        onClick={() => setMode('3d')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                          mode === '3d' ? 'bg-primary text-white' : 'text-dark hover:bg-gray-100'
                        }`}
                      >
                        <FiBox /> 3D View
                      </button>
                      <button
                        onClick={() => setMode('photo')}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                          mode === 'photo' ? 'bg-primary text-white' : 'text-dark hover:bg-gray-100'
                        }`}
                      >
                        <FiImage /> Photo
                      </button>
                    </div>

                    {/* Playful 3D prompt, only in 3D mode */}
                    {mode === '3d' && (
                      <motion.div
                        initial={{ opacity: 0, y: -8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                        className="absolute top-4 left-4 bg-primary text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-md z-10"
                      >
                        Drag to rotate ✨
                      </motion.div>
                    )}
                  </>
                )}
              </div>

              {/* Prev/Next within collection */}
              <div className="flex items-center justify-between mt-4">
                <Link
                  to={`/products/${collection}/${encodeURIComponent(prev.code)}`}
                  className="text-xs sm:text-sm text-light hover:text-primary transition-colors flex items-center gap-1"
                >
                  <FiArrowLeft /> {prev.code}
                </Link>
                <span className="text-xs text-light/60">
                  {index + 1} / {items.length}
                </span>
                <Link
                  to={`/products/${collection}/${encodeURIComponent(next.code)}`}
                  className="text-xs sm:text-sm text-light hover:text-primary transition-colors flex items-center gap-1"
                >
                  {next.code} <FiArrowRight />
                </Link>
              </div>

              {/* Thumbnail strip: more from this collection */}
              {items.length > 1 && (
                <div className="mt-6">
                  <p className="text-xs font-semibold uppercase tracking-wider text-light mb-3">
                    More from {info?.title || collection}
                  </p>
                  <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 scrollbar-thin">
                    {items.map((item) => (
                      <Link
                        key={item.code}
                        to={`/products/${collection}/${encodeURIComponent(item.code)}`}
                        className={`flex-shrink-0 w-16 h-16 rounded-[10px] overflow-hidden border-2 transition-all ${
                          item.code === product.code
                            ? 'border-primary shadow-md scale-105'
                            : 'border-transparent opacity-70 hover:opacity-100'
                        }`}
                      >
                        <img
                          src={item.src}
                          alt={item.code}
                          className={`w-full h-full object-cover ${NO_ZOOM_KEYS.has(collection) ? '' : 'scale-[1.4]'}`}
                        />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>

            {/* Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
            >
              <span className="section-subtitle">{info?.title || collection}</span>
              <h1 className="font-playfair text-3xl md:text-4xl font-bold text-dark mt-2 mb-1">
                {product.code}
              </h1>
              {info?.tagline && (
                <p className="text-primary text-sm font-semibold uppercase tracking-wide mb-4">
                  {info.tagline}
                </p>
              )}
              <div className="green-divider mb-6" />
              <p className="text-light text-base md:text-lg leading-relaxed mb-6">
                {info?.desc ||
                  `A genuine finish from our ${info?.title || collection} collection, photographed from our live production catalog.`}
              </p>

              {/* Spec chips */}
              {(info?.format || info?.finish) && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  {info?.format && (
                    <div className="premium-card p-4">
                      <div className="text-[10px] uppercase tracking-wider text-light mb-1">Format</div>
                      <div className="text-sm font-semibold text-dark">{info.format}</div>
                    </div>
                  )}
                  {info?.finish && (
                    <div className="premium-card p-4">
                      <div className="text-[10px] uppercase tracking-wider text-light mb-1">Finish</div>
                      <div className="text-sm font-semibold text-dark">{info.finish}</div>
                    </div>
                  )}
                </div>
              )}

              <ul className="space-y-2 mb-8">
                {['Genuine product photo — not a stock image', 'Interactive 3D slab preview', 'Custom sizing available on request'].map((line) => (
                  <li key={line} className="flex items-center gap-2 text-sm text-light">
                    <FiCheck className="text-primary flex-shrink-0" /> {line}
                  </li>
                ))}
              </ul>

              <div className="flex flex-wrap gap-4">
                <LuxuryButton variant="primary" size="lg" onClick={() => navigate('/contact')}>
                  Enquire About This Finish
                </LuxuryButton>
                <LuxuryButton variant="outline" size="lg" onClick={() => navigate('/products')}>
                  View Full Collection
                </LuxuryButton>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Where this works */}
      {SHOW_APPLICATIONS_SECTION && (
        <section className="section-padding bg-bg">
          <div className="container-luxury max-w-[1300px]">
            <div className="text-center max-w-xl mx-auto mb-10">
              <span className="section-subtitle">Applications</span>
              <h2 className="section-title mb-4">Where This Finish Works</h2>
              <div className="green-divider mx-auto" />
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {applications.map((app, i) => (
                <motion.div
                  key={app.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  className="group relative rounded-[16px] overflow-hidden h-[180px] cursor-pointer"
                  onClick={() => navigate('/applications')}
                >
                  <img
                    src={app.image}
                    alt={app.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent flex items-end p-4">
                    <span className="text-white text-sm font-semibold">{app.title}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  )
}
