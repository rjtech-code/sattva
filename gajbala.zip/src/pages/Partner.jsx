import { useState } from 'react'
import { motion } from 'framer-motion'
import { FiArrowRight, FiCheck } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import TiltCard from '../components/ui/TiltCard'
import { partnerReasons, company } from '../data/companyContent'

const initialFormState = {
  name: '',
  company: '',
  email: '',
  phone: '',
  subject: '',
  message: '',
}

export default function Partner() {
  const navigate = useNavigate()

  const [formData, setFormData] = useState(initialFormState)
  const [status, setStatus] = useState('idle') // idle | submitting | success | error

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setStatus('submitting')
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })
      if (!res.ok) throw new Error('Request failed')
      setStatus('success')
      setFormData(initialFormState)
    } catch {
      setStatus('error')
    }
  }

  return (
    <>
      <SEO
        title="Partner With Us | Flexible Stone Veneer Distributor & Export Partnerships"
        description="Become a GajBala Group distribution or export partner — flexible stone veneer wholesale supply for importers, distributors, architects, builders and project developers worldwide."
        canonical="/partner"
      />
      <PageHeader
        title="Partner With Us"
        subtitle="Why partner with the future developer of flexible stone veneer in India?"
        bgImage="/Images/pdf-assets/quarry.jpg"
      />

      {/* Partner Inquiry Form — duplicated from the Contact page form */}
      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[800px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <div className="bg-white rounded-[24px] p-8 md:p-10 shadow-xl shadow-black/5 border border-gray-100">
              <h2 className="font-playfair text-3xl font-bold text-dark mb-2">
                Send Us a Message
              </h2>
              <div className="w-16 h-1 bg-primary mb-6" />
              <p className="text-light text-base mb-8">
                Fill out the form below and we'll get back to you shortly.
              </p>

              {status === 'success' ? (
                <div className="rounded-2xl bg-primary/5 border border-primary/20 p-8 text-center">
                  <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <FiCheck className="text-2xl text-primary" />
                  </div>
                  <h3 className="font-heading text-xl font-bold text-dark mb-2">Message Sent</h3>
                  <p className="text-light text-sm leading-relaxed mb-6">
                    Thanks for reaching out — our team will get back to you shortly.
                  </p>
                  <LuxuryButton variant="outline" onClick={() => setStatus('idle')}>
                    Send Another Message
                  </LuxuryButton>
                </div>
              ) : (
              <form className="space-y-6" onSubmit={handleSubmit}>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-dark mb-2">
                      Full Name <span className="text-primary">*</span>
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                focus:ring-primary/20 outline-none transition-all duration-300"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-dark mb-2">
                      Company Name
                    </label>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                focus:ring-primary/20 outline-none transition-all duration-300"
                      placeholder="Your Company"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-dark mb-2">
                      Email Address <span className="text-primary">*</span>
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                focus:ring-primary/20 outline-none transition-all duration-300"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-dark mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                                focus:ring-primary/20 outline-none transition-all duration-300"
                      placeholder="+91 98765 43210"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark mb-2">
                    Subject <span className="text-primary">*</span>
                  </label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                              focus:ring-primary/20 outline-none transition-all duration-300"
                    placeholder="How can we help you?"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark mb-2">
                    Message <span className="text-primary">*</span>
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows="5"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:border-primary focus:ring-2
                              focus:ring-primary/20 outline-none transition-all duration-300 resize-none"
                    placeholder="Tell us about your project or inquiry..."
                  />
                </div>

                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    id="partner-agree"
                    required
                    className="mt-1 w-4 h-4 text-primary border-gray-300 rounded focus:ring-primary"
                  />
                  <label htmlFor="partner-agree" className="text-sm text-light leading-relaxed">
                    I agree to be contacted regarding my inquiry and accept the privacy policy.
                  </label>
                </div>

                {status === 'error' && (
                  <p className="text-sm text-red-600">
                    Something went wrong sending your message. Please try again.
                  </p>
                )}

                <LuxuryButton
                  variant="primary"
                  size="lg"
                  icon={FiArrowRight}
                  type="submit"
                  disabled={status === 'submitting'}
                  className="w-full sm:w-auto"
                >
                  {status === 'submitting' ? 'Sending...' : 'Send Inquiry'}
                </LuxuryButton>
              </form>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section-padding bg-bg">
        <div className="container-luxury max-w-[1400px]">
          <div className="max-w-3xl mx-auto text-center mb-14">
            <h2 className="section-title mb-6">Partnership Opportunities</h2>
            <div className="green-divider mx-auto" />
            <p className="text-light text-lg leading-relaxed mt-6">
              We welcome enquiries from {company.enquiryAudiences.join(', ').toLowerCase()}.
              Let&apos;s build the future of natural stone architecture together.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 mb-16">
            {partnerReasons.map((reason, i) => (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
              >
                <TiltCard className="premium-card h-full p-8">
                  <div className="premium-card-glow" />
                  <div className="relative z-10">
                    <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold mb-4">
                      {String(i + 1).padStart(2, '0')}
                    </div>
                    <h3 className="premium-card-title font-heading text-xl font-bold mb-3">
                      {reason.title}
                    </h3>
                    <p className="premium-card-description text-sm leading-relaxed">{reason.desc}</p>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-10 items-center rounded-[24px] bg-white border border-border p-8 lg:p-12">
            <div>
              <h3 className="font-heading text-2xl md:text-3xl font-bold text-dark mb-4">
                {company.legalName}
              </h3>
              <p className="text-primary font-medium mb-2">{company.division}</p>
              <p className="text-light leading-relaxed mb-6">
                International Trade & Distribution — connecting importers, distributors, architects,
                builders, project developers and technology partners worldwide.
              </p>
              <ul className="space-y-3 mb-8">
                {company.enquiryAudiences.map((a) => (
                  <li key={a} className="flex items-center gap-3 text-dark/80">
                    <FiCheck className="text-primary" />
                    {a}
                  </li>
                ))}
              </ul>
              <LuxuryButton
                variant="primary"
                icon={FiArrowRight}
                onClick={() => navigate('/contact')}
              >
                Start a Conversation
              </LuxuryButton>
            </div>
            <img
              src="/Images/pdf-assets/flexible-sheets.jpg"
              alt="GajBala flexible stone veneer"
              className="rounded-[20px] w-full h-80 object-cover shadow-lg"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </>
  )
}
