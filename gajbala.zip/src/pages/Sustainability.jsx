import { motion } from 'framer-motion'
import { FiArrowRight } from 'react-icons/fi'
import { FaLeaf } from 'react-icons/fa'
import { GiRecycle, GiEarthAmerica, GiFeather } from 'react-icons/gi'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/layout/PageHeader'
import SEO from '../components/SEO'
import LuxuryButton from '../components/ui/LuxuryButton'
import TiltCard from '../components/ui/TiltCard'
import { company, openPillars, estonProduct } from '../data/companyContent'

const pillars = [
  {
    icon: GiFeather,
    title: 'Ultra-Thin & Lightweight',
    desc: 'Extracting ultra-thin layers from authentic natural stone reduces material mass versus traditional slabs — up to 80% lighter.',
  },
  {
    icon: GiRecycle,
    title: 'Open Future',
    desc: 'Sustainable solutions for tomorrow, aligned with our Open Future pillar and Go Green commitment.',
  },
  {
    icon: GiEarthAmerica,
    title: 'Go Global, Go Green',
    desc: `${company.brandStrip.join(' · ')} — bringing India’s quality E-Ston products to the world responsibly.`,
  },
  {
    icon: FaLeaf,
    title: 'Weather-Ready Longevity',
    desc: 'Weather-resistant veneers for interior and exterior use help extend design life across climates.',
  },
]

export default function Sustainability() {
  const navigate = useNavigate()

  return (
    <>
      <SEO
        title="Sustainability | Eco-Friendly Natural Stone Veneer Manufacturing"
        description="Go Global, Go Green, Go GajBala — how GajBala Group's ultra-thin flexible stone veneer reduces material waste, transport weight and environmental impact versus traditional slab stone."
        canonical="/sustainability"
      />
      <PageHeader
        title="Sustainability"
        subtitle="Go Global · Go Green · Go Gajbala — sustainable solutions for tomorrow."
        bgImage="/Images/drive/louver.jpg"
      />

      <section className="section-padding bg-white">
        <div className="container-luxury max-w-[1400px]">
          <div className="max-w-3xl mx-auto text-center mb-14">
            <h2 className="section-title mb-6">Our Sustainability Journey</h2>
            <div className="green-divider mx-auto" />
            <p className="text-light text-lg leading-relaxed mt-6">
              {estonProduct.description}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 lg:gap-8 mb-16">
            {pillars.map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <TiltCard className="premium-card h-full p-8">
                  <div className="premium-card-glow" />
                  <div className="relative z-10 flex gap-5">
                    <div className="w-14 h-14 rounded-[16px] bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <item.icon className="text-2xl text-primary" />
                    </div>
                    <div>
                      <h3 className="premium-card-title font-heading text-xl font-bold mb-2">
                        {item.title}
                      </h3>
                      <p className="premium-card-description text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>

          <div className="rounded-[24px] bg-primary-dark text-white p-8 lg:p-12">
            <h3 className="font-heading text-2xl md:text-3xl font-bold mb-6">Open Ecosystem Commitments</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {openPillars.map((p) => (
                <div key={p.title}>
                  <div className="text-primary-light font-semibold mb-2">{p.title}</div>
                  <p className="text-white/70 text-sm leading-relaxed">{p.desc}</p>
                </div>
              ))}
            </div>
            <LuxuryButton variant="primary" icon={FiArrowRight} onClick={() => navigate('/eston-era')}>
              Explore the E-Ston Era
            </LuxuryButton>
          </div>
        </div>
      </section>
    </>
  )
}
