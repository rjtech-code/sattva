import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import PageHeader from '../components/layout/PageHeader'
import SEO from '../components/SEO'
import TiltCard from '../components/ui/TiltCard'
import ProductCatalog from '../components/sections/ProductCatalog'
import { productCatalog } from '../data/productCatalog'
import { collectionsInfo } from '../data/collectionsInfo'
import { SITE_URL } from '../data/seoConfig'

const collectionKeys = ['flexoera', 'onyxoera', 'decoera', 'artoera', 'walloera', 'designoera', 'rockoera']

export default function Products() {
  // Keep the active collection local so category clicks filter the catalog
  // without changing the URL or resetting the page position.
  const { collection } = useParams()
  const [isPageLoading, setIsPageLoading] = useState(true)
  const [activeCatalog, setActiveCatalogState] = useState(
    collectionKeys.includes(collection) ? collection : collectionKeys[0],
  )

  useEffect(() => {
    let timerId

    const finishLoading = () => setIsPageLoading(false)

    if (document.readyState === 'complete') {
      finishLoading()
      return undefined
    }

    window.addEventListener('load', finishLoading, { once: true })
    timerId = window.setTimeout(finishLoading, 4000)

    return () => {
      window.removeEventListener('load', finishLoading)
      window.clearTimeout(timerId)
    }
  }, [])

  useEffect(() => {
    if (collectionKeys.includes(collection)) {
      setActiveCatalogState(collection)
    }
  }, [collection])

  useEffect(() => {
    if (!collection) {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' })
    }
  }, [collection])

  const setActiveCatalog = (key) => {
    setActiveCatalogState(key)
  }

  const handleCollectionClick = (key) => {
    setActiveCatalogState(key)
    document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  const activeInfo = collectionsInfo[activeCatalog]
  const hasCollectionPath = collectionKeys.includes(collection)
  const canonicalPath = hasCollectionPath ? `/products/${activeCatalog}` : '/products'

  const itemListSchema = {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    itemListElement: collectionKeys
      .filter((key) => collectionsInfo[key] && productCatalog[key]?.length)
      .map((key, i) => ({
        '@type': 'ListItem',
        position: i + 1,
        item: {
          '@type': 'Product',
          name: collectionsInfo[key].title,
          description: collectionsInfo[key].desc,
          category: collectionsInfo[key].tagline,
          image: `${SITE_URL}${productCatalog[key][0].src}`,
          url: `${SITE_URL}/products/${key}`,
          brand: { '@type': 'Brand', name: 'GajBala Group' },
        },
      })),
  }
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: SITE_URL },
      { '@type': 'ListItem', position: 2, name: 'Products', item: `${SITE_URL}/products` },
      ...(hasCollectionPath
        ? [{ '@type': 'ListItem', position: 3, name: activeInfo?.title, item: `${SITE_URL}${canonicalPath}` }]
        : []),
    ],
  }

  return (
    <>
      {isPageLoading && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[#f8f6f2]">
          <div className="flex flex-col items-center gap-4">
            <div className="relative h-16 w-16">
              <div className="absolute inset-0 rounded-full border-4 border-[#dfe7df] border-t-[#1B5E20] animate-spin" />
              <div className="absolute inset-3 rounded-full border-2 border-[#1B5E20]/20" />
            </div>
            <div className="flex flex-col items-center gap-2 text-center">
              <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#1B5E20]">Loading catalog</p>
              <div className="h-1.5 w-40 overflow-hidden rounded-full bg-[#e5ebdf]">
                <div className="h-full w-1/2 rounded-full bg-[#1B5E20] animate-[pulse_1.2s_ease-in-out_infinite]" />
              </div>
            </div>
          </div>
        </div>
      )}

      <SEO
        title={`${activeInfo?.title || 'Our Products'} | Flexible Stone Veneer Collections`}
        description={`Browse GajBala Group's ${activeInfo?.title || 'flexible stone veneer'} collection — ${activeInfo?.desc || 'ultra-thin natural stone veneer sheets for architects, builders and distributors, manufactured and exported from Jaipur, India.'}`}
        canonical={canonicalPath}
        jsonLd={[itemListSchema, breadcrumbSchema]}
      />
      <PageHeader
        title="Our Products"
        subtitle="Explore our complete range of premium natural stone solutions."
        bgImage="/Images/drive/app5.jpg"
      />

      <section className="pt-8 pb-14 lg:pt-10 lg:pb-16 bg-white">
        <div className="container-luxury max-w-[1400px]">
          {/* Section Header */}
          <div className="text-center max-w-2xl mx-auto mb-8 lg:mb-10">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              Our Collections
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-playfair text-2xl md:text-3xl font-bold text-dark leading-tight mb-4"
            >
              Our Flexible Stone Veneer Collections
            </motion.h2>
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto"
            />
          </div>

          {/* Collections — static grid on the products page; carousel stays on the home page below the 3D model section */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-5 max-w-4xl mx-auto">
            {collectionKeys.map((key, i) => {
              const info = collectionsInfo[key]
              const thumb = productCatalog[key]?.[0]?.src
              if (!info || !thumb) return null
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ duration: 0.5, delay: (i % 4) * 0.06, ease: [0.25, 0.46, 0.45, 0.94] }}
                  onClick={() => handleCollectionClick(key)}
                  className="cursor-pointer"
                >
                  <TiltCard
                    strength={6}
                    whileHover={{ y: -6, scale: 1.02 }}
                    transition={{ duration: 0.4, ease: [0.22, 0.61, 0.36, 1] }}
                    className="premium-card overflow-hidden cursor-pointer"
                  >
                    <div className="relative overflow-hidden">
                      <img
                        src={thumb}
                        alt={`${info.title} - GajBala Group natural stone veneer`}
                        className="w-full h-28 sm:h-32 object-cover scale-[1.4]"
                        loading="lazy"
                      />
                    </div>
                    <div className="relative z-10 p-3 text-center">
                      <h3 className="premium-card-title font-playfair text-sm sm:text-base font-bold text-dark">
                        {info.title}
                      </h3>
                    </div>
                  </TiltCard>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      <ProductCatalog active={activeCatalog} onActiveChange={setActiveCatalog} />
    </>
  )
}
