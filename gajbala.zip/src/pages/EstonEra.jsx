import { motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'
import { FiAward, FiGlobe, FiTrendingUp, FiLayers, FiBox, FiTool, FiUsers, FiZap, FiCheck, FiStar, FiArrowRight } from 'react-icons/fi'
import { GiFactory, GiStoneWall, GiEarthAmerica, GiDiamondRing, GiRecycle, GiMining, GiFeather, GiThermometerCold } from 'react-icons/gi'
import { FaLeaf, FaShieldAlt } from "react-icons/fa";
import SEO from '../components/SEO'
import TiltCard from '../components/ui/TiltCard'
import LuxuryButton from '../components/ui/LuxuryButton'

const pillars = [
  {
    icon: GiRecycle,
    title: 'Open Future',
    desc: 'Sustainable solutions for tomorrow',
    image: '/Images/stock/leaf-1.jpg',
  },
  {
    icon: FiTrendingUp,
    title: 'Lightweight Innovation',
    desc: 'Up to 80% lighter than traditional stone slabs',
    image: '/Images/stock/feather.jpg',
  },
  {
    icon: FiGlobe,
    title: 'Open Opportunities',
    desc: 'For partners, dealers, architects and builders worldwide',
    image: '/Images/stock/airplane-global.jpg',
  },
  {
    icon: FiZap,
    title: 'Open Innovation',
    desc: 'Continuous research and new ideas',
    image: '/Images/stock/lab-research.jpg',
  },
  {
    icon: FiUsers,
    title: 'Open Industry',
    desc: 'Empowering the entire E-Ston ecosystem',
    image: '/Images/stock/team-collaboration.jpg',
  },
  {
    icon: GiDiamondRing,
    title: 'Operational Excellence',
    desc: 'Flawless execution and honest customer service',
    image: '/Images/stock/welding-craftsmanship.jpg',
  },
]

const veneerSpecs = [
  { icon: FiLayers, title: 'Just 1–2mm Thick', desc: 'Extracted thin sheets from natural stone, 100% eco-friendly.' },
  { icon: GiFeather, title: 'Lightweight', desc: 'Easy to handle, transport and install.' },
  { icon: FiTrendingUp, title: 'Flexible', desc: 'Can be bent in concave, convex, arched or radial forms.' },
  { icon: GiThermometerCold, title: 'Weather-Resistant', desc: 'Withstands extreme heat and cold.' },
  { icon: FaShieldAlt, title: 'Easy Application', desc: 'Ideal for both internal and external surfaces.' },
]

const stakeholders = [
  { icon: GiMining, label: 'Quarry Owners' },
  { icon: GiStoneWall, label: 'Stone Processors' },
  { icon: GiFactory, label: 'Veneer Manufacturers' },
  { icon: FiTool, label: 'Machinery & Tech' },
  { icon: FaLeaf, label: 'Chemical Suppliers' },
  { icon: FiAward, label: 'Architects & Designers' },
  { icon: FiBox, label: 'Builders & Developers' },
  { icon: FiGlobe, label: 'Importers & Exporters' },
  { icon: FiStar, label: 'Research Institutions' },
  { icon: GiRecycle, label: 'Sustainability Partners' },
]

export default function EstonEra() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen bg-white">
      <SEO
        title="E-Ston Era | The Future of Flexible Stone Veneer Industry"
        description="GajBala Group opens the E-Ston Era — a sustainable, lightweight, globally accessible vision for the natural stone industry, built on flexible stone veneer innovation from Jaipur, India."
        canonical="/eston-era"
      />
      {/* Hero Section */}
      <section className="relative overflow-hidden pt-[150px] pb-20 md:pt-[170px] md:pb-28 flex items-center justify-center">
        <div className="absolute inset-0">
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: `url('/Images/drive/app4.jpg')`,
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/70 to-black/60" />
        </div>

        <div className="relative z-10 container-luxury text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-block px-5 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white/90 text-sm font-medium tracking-widest uppercase mb-6"
            >
              GajBala Group Presents
            </motion.span>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-4xl md:text-5xl lg:text-7xl font-heading font-bold mb-6 leading-tight [text-shadow:0_4px_24px_rgba(0,0,0,0.35)]"
            >
              <span className="text-white">GajBala Group Opens the<br />E-Ston Era</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
              className="text-lg md:text-xl text-white/80 max-w-3xl mx-auto leading-relaxed"
            >
              Opening the Future of the Global E-Ston Industry
            </motion.p>
          </motion.div>
        </div>
      </section>

      {/* Section 1: A New Era Begins */}
      <section className="section-padding bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-gradient-to-bl from-primary/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="relative"
            >
              <TiltCard strength={5} glare={false} className="image-zoom rounded-[20px] shadow-xl shadow-black/10">
                <img
                  src="/Images/applications/lounge-marble-bar.jpg"
                  alt="Premium natural stone installation - E-Ston Era"
                  className="w-full h-[400px] lg:h-[520px] object-cover rounded-[20px]"
                  loading="lazy"
                />
              </TiltCard>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-[20px] -z-10" />
            </motion.div>

            <div>
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="section-subtitle"
              >
                A New Era Begins
              </motion.span>

              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="section-title mb-6"
              >
                Redefining Natural Stone for Future Generations
              </motion.h2>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="green-divider mb-6"
              />

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="space-y-4 text-base md:text-lg text-light leading-relaxed"
              >
                <p>
                  For centuries, natural stone has been one of humanity's most enduring construction materials. 
                  Today, as the world moves toward sustainable development, lightweight architecture, circular 
                  manufacturing, and greener construction practices, the industry stands at the beginning of a 
                  new chapter.
                </p>
                <p className="text-[#1B5E20] font-medium text-lg">
                  GajBala Group proudly introduces this new chapter as the E-Ston Era.
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 1b: Who We Are — Leadership */}
      <section className="section-padding bg-primary-dark relative overflow-hidden">
        <div className="absolute inset-0 marble-texture opacity-10 z-0" />
        <div className="absolute top-1/2 left-0 w-[400px] h-[400px] -translate-y-1/2 bg-gradient-to-r from-primary-light/10 to-transparent rounded-full blur-[100px] pointer-events-none" />

        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <div>
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="section-subtitle !text-primary-light"
              >
                Who We Are
              </motion.span>
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight"
              >
                Led by Vision, Built for the World
              </motion.h2>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="green-divider mx-auto mb-6"
              />
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="space-y-4 text-base md:text-lg text-white/75 leading-relaxed mb-8"
              >
                <p>
                  GajBala Group is led by Mr. Shyam Somani, whose vision is to develop India&apos;s
                  quality E-Ston products and supply them to the world with a mission — Reaching
                  Everywhere. We deliver flawless performance through operational excellence across
                  every stage of manufacturing.
                </p>
                <p>
                  Crafted by extracting ultra-thin layers from authentic natural stone, our flexible
                  stone veneer sheets are reinforced with a fiberglass-polymer resin backing —
                  opening the future of the global E-Ston industry.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="grid grid-cols-3 gap-4"
              >
                {[
                  { icon: FiAward, value: 'E-Ston', label: 'Industry Ecosystem' },
                  { icon: FiUsers, value: 'Open', label: 'Innovation & Industry' },
                  { icon: FiGlobe, value: 'Global', label: 'Mission — Reach Everywhere' },
                ].map((stat) => (
                  <div key={stat.label} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-[16px] p-4 lg:p-5 text-center">
                    <stat.icon className="text-2xl text-primary-light mx-auto mb-2" />
                    <div className="font-heading text-xl lg:text-2xl font-bold text-white mb-1">{stat.value}</div>
                    <div className="text-[11px] lg:text-xs text-white/60 leading-tight">{stat.label}</div>
                  </div>
                ))}
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 1c: Ultra-Thin Stone Veneer Specs */}
      <section className="section-padding bg-white relative overflow-hidden">
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              The Artistry of Thin Stone Veneers
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-6"
            >
              Our Revolutionary Ultra-Thin Stone Veneers
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto"
            />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6 lg:gap-6">
            {veneerSpecs.map((spec, i) => (
              <motion.div
                key={spec.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="group"
              >
                <TiltCard
                  strength={7}
                  whileHover={{ y: -8, scale: 1.02 }}
                  transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                  className="premium-card h-full p-6 text-center"
                >
                  <div className="premium-card-glow" />
                  <div className="relative z-10">
                    <div className="premium-card-icon w-14 h-14 rounded-[16px] bg-[#7A7A7A]/10 flex items-center justify-center mx-auto mb-4">
                      <spec.icon
                        className="text-2xl transition-colors duration-700 ease-[cubic-bezier(.22,.61,.36,1)] group-hover:text-[#A5D6A7]"
                        style={{ color: '#7A7A7A' }}
                      />
                    </div>
                    <h3 className="premium-card-title font-heading text-base font-bold text-[#1B5E20] mb-2">
                      {spec.title}
                    </h3>
                    <p className="text-sm premium-card-description leading-relaxed">
                      {spec.desc}
                    </p>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 2: What is the E-Ston Era? */}
      <section className="section-padding bg-bg relative overflow-hidden">
        <div className="absolute inset-0 marble-texture opacity-20 z-0" />

        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16 lg:mb-20">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              What is the E-Ston Era?
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-6"
            >
              A Vision for Global Transformation
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto mb-6"
            />
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-lg text-light leading-relaxed"
            >
              The E-Ston Era is not simply a product category—it is a comprehensive vision for transforming 
              the global stone industry into an ecosystem that is sustainable, accessible, and innovative.
            </motion.p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 lg:gap-8">
            {[
              { icon: GiRecycle, title: 'Eco-Friendly', desc: 'Sustainable practices for environmental stewardship', image: '/Images/stock/leaf-1.jpg' },
              { icon: FiTrendingUp, title: 'Economic', desc: 'Cost-effective solutions without compromising quality', image: '/Images/stock/growth-chart.jpg' },
              { icon: FiGlobe, title: 'Easy to Access', desc: 'Democratizing premium stone globally', image: '/Images/stock/airplane-global.jpg' },
              { icon: GiEarthAmerica, title: 'Environment Friendly', desc: 'Responsible sourcing and manufacturing', image: '/Images/stock/leaf-2.jpg' },
              { icon: GiRecycle, title: 'Ecological', desc: 'Preserving nature while building futures', image: '/Images/stock/leaf-3.jpg' },
              { icon: FiZap, title: 'Efficient', desc: 'Optimized processes for maximum productivity', image: '/Images/stock/feather.jpg' },
              { icon: FiGlobe, title: 'Export-Oriented', desc: 'Global reach with local presence', image: '/Images/stock/shipping-containers.jpg' },
            ].map((principle, i) => (
              <motion.div
                key={principle.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: i * 0.08, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="group"
              >
                <TiltCard
                  strength={7}
                  whileHover={{ y: -8, scale: 1.02 }}
                  transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                  className="premium-card overflow-hidden h-full flex flex-col text-center"
                >
                  <div className="premium-card-glow" />
                  <div className="relative image-zoom overflow-hidden">
                    <img
                      src={principle.image}
                      alt={`${principle.title} - GajBala Group E-Ston Era`}
                      className="w-full h-28 object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="relative z-10 p-6 flex-1 flex flex-col">
                    <div className="premium-card-icon w-12 h-12 rounded-[14px] bg-[#7A7A7A]/10 flex items-center justify-center mx-auto -mt-10 mb-4 bg-white shadow-md">
                      <principle.icon
                        className="text-xl transition-colors duration-700 ease-[cubic-bezier(.22,.61,.36,1)] group-hover:text-[#A5D6A7]"
                        style={{ color: '#7A7A7A' }}
                      />
                    </div>
                    <h3 className="premium-card-title font-heading text-lg font-bold text-[#1B5E20] mb-2">
                      {principle.title}
                    </h3>
                    <p className="text-sm premium-card-description leading-relaxed">
                      {principle.desc}
                    </p>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 3: From Stone Industry to E-Ston Industry */}
      <section className="section-padding bg-white relative overflow-hidden">
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              The Evolution
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-6"
            >
              From Stone Industry to E-Ston Industry
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto"
            />
          </div>

          <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-12">
            <TiltCard
              strength={5}
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.7 }}
              whileHover={{ y: -6 }}
              className="premium-card p-8 lg:p-10 bg-gradient-to-br from-gray-50 to-white"
            >
              <div className="premium-card-glow" />
              <div className="relative z-10 premium-card-description">
                <h3 className="premium-card-text text-2xl font-bold mb-4">
                  Traditional Stone Industry
                </h3>
                <p className="text-light leading-relaxed mb-4">
                  Heavy, difficult to transport, limited application possibilities, and high environmental impact.
                  Natural stone was once a luxury accessible only to large-scale projects.
                </p>
                <ul className="space-y-2">
                  {['Heavy & bulky', 'Limited flexibility', 'High transportation costs', 'Environmental impact'].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm text-light">
                      <div className="w-1.5 h-1.5 rounded-full bg-gray-400" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </TiltCard>

            <TiltCard
              strength={5}
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.7, delay: 0.2 }}
              whileHover={{ y: -6 }}
              className="premium-card !bg-primary-dark !border-primary-dark p-8 lg:p-10"
            >
              <div className="premium-card-glow" />
              <div className="relative z-10">
                <h3 className="font-heading text-2xl font-bold text-white mb-4">
                  The E-Ston Industry
                </h3>
                <p className="text-white/75 leading-relaxed mb-4">
                  Lighter, smarter, sustainable, and globally accessible. Modern architecture demands solutions
                  that preserve the timeless beauty of natural stone while embracing innovation.
                </p>
                <ul className="space-y-2">
                  {['Ultra-lightweight', 'Flexible & adaptable', 'Cost-efficient', 'Eco-conscious'].map((item) => (
                    <li key={item} className="flex items-center gap-2 text-sm text-white/75">
                      <FiCheck className="text-primary-light" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </TiltCard>
          </div>
        </div>
      </section>

      {/* Section 4: An Invitation to the Global Industry */}
      <section className="section-padding bg-bg relative overflow-hidden">
        <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-gradient-to-tr from-primary/5 to-transparent rounded-full blur-[100px] pointer-events-none" />

        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="section-subtitle"
              >
                Global Collaboration
              </motion.span>
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="section-title mb-6"
              >
                An Invitation to the Global Industry
              </motion.h2>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="green-divider mb-6"
              />
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="text-base md:text-lg text-light leading-relaxed mb-6"
              >
                The E-Ston Era is built on collaboration, not competition. GajBala Group invites quarry owners, 
                manufacturers, processors, architects, and industry leaders to join us in building an ecosystem 
                that benefits everyone.
              </motion.p>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="text-base text-light leading-relaxed"
              >
                Together, we can transform the global stone industry into a more sustainable, accessible, and 
                innovative sector that serves humanity and respects our planet.
              </motion.p>
            </div>

            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="relative"
            >
              <TiltCard strength={5} glare={false} className="image-zoom rounded-[20px] shadow-xl shadow-black/10">
                <img
                  src="/Images/drive/global-stone-producer-map.png"
                  alt="India is a top global stone producer — export reach map"
                  className="w-full h-[400px] lg:h-[500px] object-cover object-top rounded-[20px]"
                  loading="lazy"
                />
              </TiltCard>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Section 5: Pillars of the E-Ston Era */}
      <section className="section-padding bg-white relative overflow-hidden">
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              Foundation
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-6"
            >
              The Pillars of the E-Ston Era
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto"
            />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {pillars.map((pillar, i) => (
              <motion.div
                key={pillar.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: i * 0.1, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="group"
              >
                <TiltCard
                  strength={7}
                  whileHover={{ y: -8, scale: 1.02 }}
                  transition={{ duration: 0.5, ease: [0.22, 0.61, 0.36, 1] }}
                  className="premium-card overflow-hidden h-full flex flex-col"
                >
                  <div className="premium-card-glow" />
                  <div className="relative image-zoom overflow-hidden">
                    <img
                      src={pillar.image}
                      alt={`${pillar.title} - GajBala Group E-Ston Era`}
                      className="w-full h-32 object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="relative z-10 p-6 lg:p-8 flex-1 flex flex-col">
                    <div className="premium-card-icon w-14 h-14 rounded-[16px] bg-[#7A7A7A]/10 flex items-center justify-center -mt-12 mb-5 bg-white shadow-md">
                      <pillar.icon
                        className="text-2xl transition-colors duration-700 ease-[cubic-bezier(.22,.61,.36,1)] group-hover:text-[#A5D6A7]"
                        style={{ color: '#7A7A7A' }}
                      />
                    </div>
                    <h3 className="premium-card-title font-heading text-xl font-bold text-[#1B5E20] mb-3">
                      {pillar.title}
                    </h3>
                    <p className="text-sm premium-card-description leading-relaxed">
                      {pillar.desc}
                    </p>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 6: Building an Industry Ecosystem */}
      <section className="section-padding bg-bg relative overflow-hidden">
        <div className="absolute inset-0 marble-texture opacity-20 z-0" />

        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="section-subtitle"
            >
              Ecosystem
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="section-title mb-6"
            >
              Building an Industry Ecosystem
            </motion.h2>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="green-divider mx-auto mb-6"
            />
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="text-lg text-light leading-relaxed"
            >
              Every stakeholder in the natural stone industry is connected as part of one global ecosystem. 
              Together, we create value, drive innovation, and build a sustainable future.
            </motion.p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 lg:gap-6">
            {stakeholders.map((stakeholder, i) => (
              <motion.div
                key={stakeholder.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: i * 0.05 }}
                className="group"
              >
                <TiltCard
                  strength={9}
                  whileHover={{ y: -6, scale: 1.04 }}
                  transition={{ duration: 0.4, ease: [0.22, 0.61, 0.36, 1] }}
                  className="premium-card p-4 lg:p-6 text-center h-full"
                >
                  <div className="premium-card-glow" />
                  <div className="relative z-10">
                    <div className="premium-card-icon w-12 h-12 rounded-xl bg-[#7A7A7A]/10 flex items-center justify-center mx-auto mb-3">
                      <stakeholder.icon
                        className="text-xl transition-colors duration-700 ease-[cubic-bezier(.22,.61,.36,1)] group-hover:text-[#A5D6A7]"
                        style={{ color: '#7A7A7A' }}
                      />
                    </div>
                    <div className="text-xs md:text-sm font-medium premium-card-description leading-tight">
                      {stakeholder.label}
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 7: Meet Us at Marmomac Verona 2026 */}
      <section className="section-padding bg-white relative overflow-hidden">
        <div className="container-luxury max-w-[1400px] relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="relative"
            >
              <TiltCard strength={5} glare={false} className="image-zoom rounded-[20px] shadow-xl shadow-black/10">
                <img
                  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnZmhwtOpeJf7GGs6wcVzvSCtlOqTerXGm8oRWq86GOg&s=10"
                  alt="Marmomac International Stone Exhibition Verona Italy"
                  className="w-full h-[400px] lg:h-[520px] object-cover rounded-[20px]"
                  loading="lazy"
                />
              </TiltCard>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-[20px] -z-10" />
            </motion.div>

            <div>
              <motion.span
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="section-subtitle"
              >
                Event Showcase
              </motion.span>
              <motion.h2
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="section-title mb-6"
              >
                Meet Us at Marmomac Verona 2026
              </motion.h2>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="green-divider mb-6"
              />
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="text-base md:text-lg text-light leading-relaxed mb-8"
              >
                Join GajBala Group at the world's leading natural stone exhibition in Verona, Italy. 
                Experience the future of natural stone innovation, sustainability, and design excellence. 
                Discover how the E-Ston Era is reshaping the global industry.
              </motion.p>

              {/* Event Info Card */}
              <TiltCard
                strength={5}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.4 }}
                whileHover={{ y: -4 }}
                className="premium-card p-6 lg:p-8"
              >
                <div className="premium-card-glow" />
                <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center gap-6">
                  <div className="flex-shrink-0 w-16 h-16 rounded-[16px] bg-white/20 flex items-center justify-center">
                    <FiGlobe className="text-3xl text-[#A5D6A7]" />
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-heading text-xl font-bold text-white mb-1">
                      Marmomac Verona 2026
                    </h3>
                    <p className="premium-card-description text-sm mb-2">Global Natural Stone Exhibition</p>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div className="flex items-center gap-2 premium-card-description">
                        <FiAward className="text-primary" />
                        <span>Verona, Italy</span>
                      </div>
                      <div className="flex items-center gap-2 premium-card-description">
                        <FiStar className="text-primary" />
                        <span>Premium Exhibition Hall</span>
                      </div>
                    </div>
                  </div>
                </div>
              </TiltCard>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: 0.5 }}
                className="mt-8"
              >
                <LuxuryButton variant="primary" icon={FiArrowRight} onClick={() => navigate('/marmomac')}>
                  Learn More About Marmomac
                </LuxuryButton>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

    </div>
  )
}