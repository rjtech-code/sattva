import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import contactApi from './vite-plugins/contact-api.js'

export default defineConfig({
  plugins: [react(), tailwindcss(), contactApi()],
})
